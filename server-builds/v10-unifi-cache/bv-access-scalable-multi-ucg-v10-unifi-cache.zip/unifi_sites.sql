begin;

create table if not exists public.unifi_sites (
  id uuid primary key default gen_random_uuid(),
  site_code text not null unique,
  display_name text,
  controller_name text,
  unifi_host text not null,
  unifi_site text not null default 'default',
  unifi_username text,
  unifi_password text,
  verify_ssl boolean not null default false,
  vpn_type text,
  vpn_address text,
  active boolean not null default true,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists unifi_sites_active_idx
  on public.unifi_sites(active);

create index if not exists unifi_sites_site_code_idx
  on public.unifi_sites(site_code);

alter table public.unifi_sites enable row level security;

drop policy if exists "unifi sites admin read" on public.unifi_sites;
drop policy if exists "unifi sites admin manage" on public.unifi_sites;

create policy "unifi sites admin read"
  on public.unifi_sites
  for select
  to authenticated
  using (
    exists (
      select 1
      from public.user_profiles up
      where up.user_id = auth.uid()
        and up.role = 'admin'
        and coalesce(up.active, true) = true
    )
  );

create policy "unifi sites admin manage"
  on public.unifi_sites
  for all
  to authenticated
  using (
    exists (
      select 1
      from public.user_profiles up
      where up.user_id = auth.uid()
        and up.role = 'admin'
        and coalesce(up.active, true) = true
    )
  )
  with check (
    exists (
      select 1
      from public.user_profiles up
      where up.user_id = auth.uid()
        and up.role = 'admin'
        and coalesce(up.active, true) = true
    )
  );

comment on table public.unifi_sites is
  'Maps each B&V Access site_code to the UniFi controller/UCG reachable by the central mini-PC.';

comment on column public.unifi_sites.site_code is
  'B&V Access site code, for example SITE-FORTLIBERTE, SITE-CAP, SITE-MILOT.';

comment on column public.unifi_sites.unifi_host is
  'Base URL reachable from the central mini-PC, for example https://10.50.1.1 or https://192.168.1.1 over VPN.';

comment on column public.unifi_sites.unifi_site is
  'UniFi Network site name inside the controller. Usually default.';

comment on column public.unifi_sites.unifi_username is
  'UniFi API username. Keep this table protected; server uses Supabase service role.';

comment on column public.unifi_sites.unifi_password is
  'UniFi API password. Keep this table protected; server uses Supabase service role.';

comment on column public.unifi_sites.verify_ssl is
  'Set true only when the UCG certificate is trusted by Node.js on the mini-PC.';

comment on column public.unifi_sites.vpn_type is
  'Suggested values: unifi_site_magic, wireguard, tailscale, ipsec, local.';

commit;

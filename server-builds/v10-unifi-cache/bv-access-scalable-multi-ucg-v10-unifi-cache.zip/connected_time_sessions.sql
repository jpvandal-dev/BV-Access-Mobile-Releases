begin;

alter table if exists public.access_sessions
  add column if not exists last_seen_at timestamptz,
  add column if not exists last_accounted_at timestamptz,
  add column if not exists paused_at timestamptz,
  add column if not exists seconds_consumed integer not null default 0,
  add column if not exists billing_mode text not null default 'connected_usage',
  add column if not exists expires_at timestamptz,
  add column if not exists unifi_connected boolean,
  add column if not exists unifi_authorized boolean;

do $$
begin
  if not exists (
    select 1
    from information_schema.table_constraints
    where table_schema = 'public'
      and table_name = 'access_sessions'
      and constraint_name = 'access_sessions_billing_mode_check'
  ) then
    alter table public.access_sessions
      add constraint access_sessions_billing_mode_check
      check (billing_mode in ('connected_usage', 'fixed_window'))
      not valid;
  end if;

  alter table public.access_sessions
    validate constraint access_sessions_billing_mode_check;
exception
  when duplicate_object then null;
end $$;

create index if not exists access_sessions_status_billing_idx
  on public.access_sessions(status, billing_mode);

create index if not exists access_sessions_mac_status_idx
  on public.access_sessions(mac_address, status);

create index if not exists access_sessions_expires_at_idx
  on public.access_sessions(expires_at)
  where expires_at is not null;

comment on column public.access_sessions.last_seen_at is
  'Last time UniFi reported the client MAC as visible.';

comment on column public.access_sessions.last_accounted_at is
  'Last time BV Access charged connected usage time for this session.';

comment on column public.access_sessions.paused_at is
  'Time when the session was paused because the client was no longer visible.';

comment on column public.access_sessions.seconds_consumed is
  'Precise connected-time counter used before converting to remaining minutes.';

comment on column public.access_sessions.billing_mode is
  'connected_usage for normal plans, fixed_window for Plan Nuit.';

comment on column public.access_sessions.expires_at is
  'Fixed expiration timestamp, used mainly by Plan Nuit.';

comment on column public.access_sessions.unifi_connected is
  'Latest observed client connectivity state from UniFi.';

comment on column public.access_sessions.unifi_authorized is
  'Latest observed guest authorization state from UniFi.';

commit;

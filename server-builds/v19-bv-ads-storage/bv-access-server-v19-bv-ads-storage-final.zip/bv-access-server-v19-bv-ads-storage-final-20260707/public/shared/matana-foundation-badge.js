(function () {
  const template = document.createElement("template");

  template.innerHTML = `
    <style>
      :host {
        display: block;
        font-family: Arial, sans-serif;
      }

      .badge {
        align-items: center;
        display: inline-flex;
        flex-direction: column;
        gap: 8px;
        max-width: 100%;
        width: 100%;
      }

      .logo-row {
        align-items: center;
        display: flex;
        gap: var(--brand-logo-gap, 16px);
        justify-content: center;
        max-width: 100%;
        width: 100%;
      }

      .bv-logo {
        color: var(--bv-logo-color, #0a1f33);
        font-size: var(--bv-logo-size, 64px);
        font-weight: 900;
        letter-spacing: 0;
        line-height: 1;
        white-space: nowrap;
      }

      .bv-logo span {
        color: #69b72e;
      }

      .bv-image {
        display: none;
        height: var(--bv-logo-image-height, var(--bv-logo-size, 64px));
        max-width: var(--bv-logo-image-max-width, calc(var(--bv-logo-size, 64px) * 1.9));
        object-fit: contain;
        width: auto;
      }

      .logo-divider {
        align-self: stretch;
        background: var(--brand-divider-color, #d1d5db);
        display: block;
        min-height: var(--brand-divider-height, 72px);
        width: 1px;
      }

      .matana-logo {
        display: block;
        height: var(--matana-logo-height, var(--bv-logo-size, 64px));
        max-width: var(--matana-logo-max-width, calc(var(--bv-logo-size, 64px) * 2.3));
        object-fit: contain;
        width: auto;
      }

      .caption {
        color: var(--matana-caption-color, #64748b);
        font-size: var(--matana-caption-size, 13px);
        font-weight: 700;
        line-height: 1.3;
        max-width: 100%;
        text-align: center;
      }

      :host([theme="dark"]) {
        --bv-logo-color: #f8fafc;
        --matana-caption-color: #cbd5e1;
      }

      :host([compact]) {
        --bv-logo-size: 42px;
        --matana-logo-height: 42px;
        --matana-logo-max-width: 112px;
        --brand-divider-height: 48px;
        --matana-caption-size: 11px;
      }

      @media (max-width: 520px) {
        :host {
          --bv-logo-size: var(--mobile-bv-logo-size, 60px);
          --bv-logo-image-height: var(--mobile-bv-logo-image-height, var(--mobile-bv-logo-size, 60px));
          --bv-logo-image-max-width: var(--mobile-bv-logo-image-max-width, calc(var(--mobile-bv-logo-size, 60px) * 1.9));
          --matana-logo-height: var(--mobile-matana-logo-height, 60px);
          --matana-logo-max-width: var(--mobile-matana-logo-max-width, 140px);
          --brand-divider-height: var(--mobile-brand-divider-height, 62px);
          --matana-caption-size: 11px;
        }

        .logo-row {
          gap: var(--mobile-brand-logo-gap, 12px);
        }
      }
    </style>

    <div class="badge">
      <div class="logo-row" aria-label="B&V et Fondation Matana">
        <div class="bv-logo">B<span>V</span></div>
        <img class="bv-image" alt="Logo B&V" />
        <span class="logo-divider" aria-hidden="true"></span>
        <img class="matana-logo" alt="Fondation Matana – Gift of God" />
      </div>
      <div class="caption"></div>
    </div>
  `;

  class MatanaFoundationBadge extends HTMLElement {
    connectedCallback() {
      if (!this.shadowRoot) {
        this.attachShadow({ mode: "open" }).appendChild(
          template.content.cloneNode(true)
        );
      }

      const logo = this.shadowRoot.querySelector(".matana-logo");
      const bvTextLogo = this.shadowRoot.querySelector(".bv-logo");
      const bvImageLogo = this.shadowRoot.querySelector(".bv-image");
      const caption = this.shadowRoot.querySelector(".caption");
      const bvAssetPath = this.getAttribute("bv-asset-path");
      const assetPath = this.getAttribute("asset-path") || "/assets/matana-logo.jpg";
      const captionText =
        this.getAttribute("caption") ||
        (this.hasAttribute("powered")
          ? "Powered by Fondation Matana – Gift of God"
          : "Fondation Matana – Gift of God");

      if (bvAssetPath) {
        bvImageLogo.setAttribute("src", bvAssetPath);
        bvImageLogo.style.display = "block";
        bvTextLogo.style.display = "none";
      } else {
        bvImageLogo.removeAttribute("src");
        bvImageLogo.style.display = "none";
        bvTextLogo.style.display = "block";
      }

      logo.setAttribute("src", assetPath);
      caption.textContent = captionText;
    }
  }

  if (!customElements.get("matana-foundation-badge")) {
    customElements.define("matana-foundation-badge", MatanaFoundationBadge);
  }
})();

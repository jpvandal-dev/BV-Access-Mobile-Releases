// Global state
let currentSection = 'dashboard';
let allData = {
    dashboard: {},
    sales: [],
    accessCodes: [],
    posDevices: [],
    posStats: [],
    agents: []
};

// Section titles
const sectionTitles = {
    dashboard: 'Dashboard',
    sales: 'Sales',
    'access-codes': 'Access Codes',
    'pos-devices': 'POS Devices',
    agents: 'Agents'
};

// Utility functions
function formatCurrency(amount) {
    return `${amount} GDES`;
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleString('fr-FR', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function createStatusBadge(status) {
    const badge = document.createElement('span');
    badge.className = `status-badge status-${status}`;
    badge.textContent = status;
    return badge;
}

// Navigation
function switchSection(section) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(el => el.classList.remove('active'));
    
    // Show active section
    document.getElementById(`${section}-section`).classList.add('active');
    
    // Update menu active state
    document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`[data-section="${section}"]`).classList.add('active');
    
    // Update title
    document.getElementById('section-title').textContent = sectionTitles[section] || section;
    
    currentSection = section;
    
    // Load section data if not already loaded
    if (section === 'dashboard') {
        loadDashboard();
    } else if (section === 'sales') {
        loadSales();
    } else if (section === 'access-codes') {
        loadAccessCodes();
    } else if (section === 'pos-devices') {
        loadPosDevices();
    } else if (section === 'agents') {
        loadAgents();
    }
}

// Load data functions
async function loadDashboard() {
    try {
        const [dashRes, posRes, agentRes] = await Promise.all([
            fetch('/dashboard'),
            fetch('/stats/pos'),
            fetch('/stats/agents')
        ]);

        const [dash, pos, agent] = await Promise.all([
            dashRes.json(),
            posRes.json(),
            agentRes.json()
        ]);

        if (dash.success) allData.dashboard = dash.data;
        if (pos.success) allData.posStats = pos.data;
        if (agent.success) allData.agents = agent.data;

        updateDashboard();
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

async function loadSales() {
    try {
        const res = await fetch('/sales');
        const data = await res.json();
        if (data.success) {
            allData.sales = data.data;
            updateSalesTable();
        }
    } catch (error) {
        console.error('Error loading sales:', error);
    }
}

async function loadAccessCodes() {
    try {
        const res = await fetch('/access-codes');
        const data = await res.json();
        if (data.success) {
            allData.accessCodes = data.data;
            updateAccessCodesTable();
        }
    } catch (error) {
        console.error('Error loading access codes:', error);
    }
}

async function loadPosDevices() {
    try {
        const [devicesRes, statsRes] = await Promise.all([
            fetch('/pos-devices'),
            fetch('/stats/pos')
        ]);

        const [devices, stats] = await Promise.all([
            devicesRes.json(),
            statsRes.json()
        ]);

        if (devices.success) allData.posDevices = devices.data;
        if (stats.success) allData.posStats = stats.data;

        updatePosDevicesTable();
        updatePosStatsTable();
    } catch (error) {
        console.error('Error loading POS devices:', error);
    }
}

async function loadAgents() {
    try {
        const res = await fetch('/stats/agents');
        const data = await res.json();
        if (data.success) {
            allData.agents = data.data;
            updateAgentsTable();
        }
    } catch (error) {
        console.error('Error loading agents:', error);
    }
}

// Update UI functions
function updateDashboard() {
    const dash = allData.dashboard;

    // KPI Cards
    document.getElementById('total-sales').textContent = dash.total_sales;
    document.getElementById('total-revenue').textContent = formatCurrency(dash.total_revenue_gdes);
    document.getElementById('total-codes').textContent = dash.total_codes;
    document.getElementById('active-codes').textContent = dash.active_codes;
    document.getElementById('used-codes').textContent = dash.used_codes;
    document.getElementById('expired-codes').textContent = dash.expired_codes;
    document.getElementById('active-pos').textContent = dash.active_pos;
    document.getElementById('total-agents').textContent = dash.total_agents;

    // Insights
    const topPos = allData.posStats.reduce((max, pos) => pos.sales_count > max.sales_count ? pos : max, allData.posStats[0]);
    document.getElementById('top-pos').textContent = topPos ? `${topPos.name}` : 'N/A';

    const topAgent = allData.agents.reduce((max, agent) => parseInt(agent.sales_count) > parseInt(max.sales_count) ? agent : max, allData.agents[0]);
    document.getElementById('top-agent').textContent = topAgent ? topAgent.agent_name : 'N/A';

    const revenuePerSale = dash.total_sales > 0 ?
        (parseFloat(dash.total_revenue_gdes) / parseInt(dash.total_sales)).toFixed(2) : 0;
    document.getElementById('revenue-per-sale').textContent = formatCurrency(revenuePerSale);

    const activeRate = dash.total_codes > 0 ?
        ((parseInt(dash.active_codes) / parseInt(dash.total_codes)) * 100).toFixed(1) : 0;
    document.getElementById('active-code-rate').textContent = `${activeRate}%`;

    createCharts();
}

function updateSalesTable() {
    document.getElementById('sales-loading').style.display = 'none';
    document.getElementById('sales-table').style.display = 'table';

    const tbody = document.getElementById('sales-body');
    tbody.innerHTML = '';

    allData.sales.forEach(sale => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = sale.id;
        row.insertCell(1).textContent = formatDate(sale.created_at);
        row.insertCell(2).textContent = sale.voucher_code;
        row.insertCell(3).textContent = sale.plan_key;
        row.insertCell(4).textContent = formatCurrency(sale.price_gdes);
        row.insertCell(5).textContent = `${sale.duration_minutes} min`;
        const statusCell = row.insertCell(6);
        statusCell.appendChild(createStatusBadge(sale.status));
        row.insertCell(7).textContent = sale.agent_name;
        row.insertCell(8).textContent = sale.pos_id;
    });
}

function updateAccessCodesTable() {
    document.getElementById('access-codes-loading').style.display = 'none';
    document.getElementById('access-codes-table').style.display = 'table';

    const tbody = document.getElementById('access-codes-body');
    tbody.innerHTML = '';

    allData.accessCodes.forEach(code => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = code.id;
        row.insertCell(1).textContent = code.code;
        row.insertCell(2).textContent = code.plan_code;
        row.insertCell(3).textContent = `${code.duration_minutes} min`;
        const statusCell = row.insertCell(4);
        statusCell.appendChild(createStatusBadge(code.status));
        row.insertCell(5).textContent = formatDate(code.created_at);
        row.insertCell(6).textContent = formatDate(code.used_at);
        row.insertCell(7).textContent = code.sale_id || '-';
    });
}

function updatePosDevicesTable() {
    document.getElementById('pos-devices-loading').style.display = 'none';
    document.getElementById('pos-devices-table').style.display = 'table';

    const tbody = document.getElementById('pos-devices-body');
    tbody.innerHTML = '';

    allData.posDevices.forEach(device => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = device.id;
        row.insertCell(1).textContent = device.name;
        row.insertCell(2).textContent = device.location;
        const statusCell = row.insertCell(3);
        statusCell.appendChild(createStatusBadge(device.status));
        row.insertCell(4).textContent = formatDate(device.created_at);
    });
}

function updatePosStatsTable() {
    document.getElementById('pos-stats-loading').style.display = 'none';
    document.getElementById('pos-stats-table').style.display = 'table';

    const tbody = document.getElementById('pos-stats-body');
    tbody.innerHTML = '';

    allData.posStats.forEach(pos => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = pos.name;
        row.insertCell(1).textContent = pos.location;
        const statusCell = row.insertCell(2);
        statusCell.appendChild(createStatusBadge(pos.status));
        row.insertCell(3).textContent = pos.sales_count;
        row.insertCell(4).textContent = formatCurrency(pos.total_revenue_gdes);
    });
}

function updateAgentsTable() {
    document.getElementById('agents-loading').style.display = 'none';
    document.getElementById('agents-table').style.display = 'table';

    const tbody = document.getElementById('agents-body');
    tbody.innerHTML = '';

    allData.agents.forEach(agent => {
        const row = tbody.insertRow();
        row.insertCell(0).textContent = agent.agent_name;
        row.insertCell(1).textContent = agent.sales_count;
        row.insertCell(2).textContent = formatCurrency(agent.total_revenue_gdes);
    });
}

// Filter functions
function filterTable(tableId, bodyId, searchInputId) {
    const searchText = document.getElementById(searchInputId).value.toLowerCase();
    const rows = document.querySelectorAll(`#${bodyId} tr`);

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchText) ? '' : 'none';
    });
}

// Chart creation
let charts = {};

function createCharts() {
    const dash = allData.dashboard;

    // Destroy existing charts if any
    Object.values(charts).forEach(chart => chart && chart.destroy());
    charts = {};

    // Revenue by POS
    if (document.getElementById('pos-revenue-chart')) {
        const ctx = document.getElementById('pos-revenue-chart').getContext('2d');
        charts.posRevenue = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: allData.posStats.map(pos => pos.name),
                datasets: [{
                    label: 'Revenue (GDES)',
                    data: allData.posStats.map(pos => parseFloat(pos.total_revenue_gdes)),
                    backgroundColor: 'rgba(52, 152, 219, 0.6)',
                    borderColor: 'rgba(52, 152, 219, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Sales by Agent
    if (document.getElementById('agent-sales-chart')) {
        const ctx = document.getElementById('agent-sales-chart').getContext('2d');
        charts.agentSales = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: allData.agents.map(agent => agent.agent_name),
                datasets: [{
                    label: 'Sales Count',
                    data: allData.agents.map(agent => parseInt(agent.sales_count)),
                    backgroundColor: 'rgba(155, 89, 182, 0.6)',
                    borderColor: 'rgba(155, 89, 182, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    // Code Status
    if (document.getElementById('code-status-chart')) {
        const ctx = document.getElementById('code-status-chart').getContext('2d');
        charts.codeStatus = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Active', 'Used', 'Expired'],
                datasets: [{
                    data: [
                        parseInt(dash.active_codes),
                        parseInt(dash.used_codes),
                        parseInt(dash.expired_codes)
                    ],
                    backgroundColor: [
                        'rgba(46, 204, 113, 0.8)',
                        'rgba(52, 152, 219, 0.8)',
                        'rgba(231, 76, 60, 0.8)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    // Menu navigation
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            switchSection(section);
        });
    });

    // Search/filter listeners
    document.getElementById('sales-search').addEventListener('input', () => {
        filterTable('sales-table', 'sales-body', 'sales-search');
    });

    document.getElementById('codes-search').addEventListener('input', () => {
        filterTable('access-codes-table', 'access-codes-body', 'codes-search');
    });

    document.getElementById('agents-search').addEventListener('input', () => {
        filterTable('agents-table', 'agents-body', 'agents-search');
    });

    // Refresh button
    document.getElementById('btn-refresh').addEventListener('click', () => {
        if (currentSection === 'dashboard') {
            loadDashboard();
        } else if (currentSection === 'sales') {
            loadSales();
        } else if (currentSection === 'access-codes') {
            loadAccessCodes();
        } else if (currentSection === 'pos-devices') {
            loadPosDevices();
        } else if (currentSection === 'agents') {
            loadAgents();
        }
    });

    // Load initial dashboard
    loadDashboard();
});
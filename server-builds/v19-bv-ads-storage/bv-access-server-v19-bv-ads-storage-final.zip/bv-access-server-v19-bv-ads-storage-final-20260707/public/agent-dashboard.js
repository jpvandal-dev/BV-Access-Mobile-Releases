const INTERNAL_TOKEN_KEY = "bv_access_internal_token";

function getInternalToken() {
  return localStorage.getItem(INTERNAL_TOKEN_KEY) || "";
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderQrCell(sale) {
  if (!sale.qr_code_url) return "";

  const qrUrl = escapeHtml(sale.qr_code_url);
  const portalUrl = escapeHtml(sale.portal_url || sale.qr_code_url);

  return `<a href="${portalUrl}" target="_blank" rel="noopener"><img class="qr-img" src="${qrUrl}" alt="QR voucher" /></a>`;
}

function renderAnnouncementBar(announcement) {
  const bar = document.getElementById("announcementBar");
  if (!bar) return;

  if (!announcement) {
    bar.style.display = "none";
    bar.innerHTML = "";
    return;
  }

  const actionUrl =
    announcement.link_url ||
    (announcement.whatsapp
      ? `https://wa.me/${String(announcement.whatsapp).replace(/[^\d]/g, "")}`
      : announcement.phone
        ? `tel:${announcement.phone}`
        : "");

  bar.innerHTML = `
    ${announcement.title ? `<strong>${escapeHtml(announcement.title)}</strong>` : ""}
    ${escapeHtml(announcement.message)}
    ${actionUrl ? `<br><a href="${escapeHtml(actionUrl)}" target="_blank" rel="noopener">Ouvrir</a>` : ""}
  `;
  bar.style.display = "block";
}

async function loadAnnouncementBar() {
  try {
    const response = await fetch(
      "/api/announcements?placement=dashboard_agent&site_code=SITE-FORTLIBERTE&limit=1",
      { cache: "no-store" }
    );
    const data = await response.json();
    renderAnnouncementBar(data.announcements?.[0] || null);
  } catch (error) {
    console.warn("Agent announcement unavailable:", error);
    renderAnnouncementBar(null);
  }
}

async function secureFetch(url, options = {}) {
  const headers = {
    ...(options.headers || {}),
  };
  const token = getInternalToken();

  if (token) {
    headers["X-BV-Access-Token"] = token;
  }

  let response = await fetch(url, {
    ...options,
    headers,
  });

  if (response.status === 401 || response.status === 403) {
    const nextToken = window.prompt("Token interne B&V Access");

    if (nextToken) {
      localStorage.setItem(INTERNAL_TOKEN_KEY, nextToken.trim());
      response = await fetch(url, {
        ...options,
        headers: {
          ...(options.headers || {}),
          "X-BV-Access-Token": nextToken.trim(),
        },
      });
    }
  }

  return response;
}

async function loadAgentDashboard() {
  const agentCode = "BV-AGENT-001";
  const apiUrl = `http://localhost:3000/agent-dashboard/${agentCode}`;

  try {
    const response = await secureFetch(apiUrl);
    const data = await response.json();

    if (!data.success) {
      document.getElementById("errorBox").textContent =
        data.error || "Erreur de chargement du dashboard agent.";
      return;
    }

    const agent = data.agent || {};
    const stats = data.stats || {};

    document.getElementById("agentName").textContent =
      agent.full_name || "Agent B&V";

    document.getElementById("agentCode").textContent =
      agent.agent_code || agentCode;

    document.getElementById("agentCity").textContent =
      agent.city || "-";

    document.getElementById("totalSalesCount").textContent =
      stats.total_sales_count || 0;

    document.getElementById("todaySalesCount").textContent =
      stats.today_sales_count || 0;

    document.getElementById("totalSalesAmount").textContent =
      `${stats.total_sales_amount || 0} GDES`;

    document.getElementById("todaySalesAmount").textContent =
      `${stats.today_sales_amount || 0} GDES`;

    document.getElementById("totalCommissionAmount").textContent =
      `${stats.total_commission_amount || 0} GDES`;

    document.getElementById("pendingCommissionAmount").textContent =
      `${stats.pending_commission_amount || 0} GDES`;

    const salesTable = document.getElementById("salesTable");
    salesTable.innerHTML = "";

    (data.recent_sales || []).forEach((sale) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${sale.created_at || ""}</td>
        <td>${sale.voucher_code || ""}</td>
        <td class="qr-cell">${renderQrCell(sale)}</td>
        <td>${sale.product_name || ""}</td>
        <td>${sale.amount || 0}</td>
        <td>${sale.payment_method || ""}</td>
        <td>${sale.customer_name || ""}</td>
      `;

      salesTable.appendChild(row);
    });

    const commissionsTable = document.getElementById("commissionsTable");
    commissionsTable.innerHTML = "";

    (data.recent_commissions || []).forEach((commission) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${commission.created_at || ""}</td>
        <td>${commission.commission_type || ""}</td>
        <td>${commission.commission_amount || 0}</td>
        <td>${commission.status || ""}</td>
      `;

      commissionsTable.appendChild(row);
    });

  } catch (error) {
    console.error("Agent dashboard load failed:", error);

    document.getElementById("errorBox").textContent =
      "Erreur de connexion au serveur.";
  }
}

loadAgentDashboard();
loadAnnouncementBar();

setInterval(loadAgentDashboard, 10000);
setInterval(loadAnnouncementBar, 60000);

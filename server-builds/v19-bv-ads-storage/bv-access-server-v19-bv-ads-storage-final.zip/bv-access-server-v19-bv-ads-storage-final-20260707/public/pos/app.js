// POS Frontend App - Fully functional with real API integration
// Endpoints used: POST /pos/login, POST /sales/create-with-code, POST /access-codes/validate, POST /access-codes/use

// ============ CONFIG ============
const API_BASE = '';
const DEFAULT_PLANS = [
    { key: 'PLAN30', name: '30 minutes', price_gdes: 500, duration_minutes: 30 },
    { key: 'PLAN60', name: '1 heure', price_gdes: 900, duration_minutes: 60 },
    { key: 'PLAN90', name: '1h30', price_gdes: 1200, duration_minutes: 90 }
];

let plans = [];
let plansFallbackActive = false;
let lastRetryAction = null;

// ============ STATE ===========
let state = {
    sessionToken: null,
    deviceId: null,
    selectedPlan: null,
    dailySales: 0,
    dailyRevenue: 0,
    currentValidationCode: null
};

// ============ ROUTING ============
function showView(viewName) {
    document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
    const view = document.getElementById(`${viewName}-view`);
    if (view) view.classList.add('active');
}

function goToLogin() {
    state.sessionToken = null;
    sessionStorage.removeItem('pos_session');
    localStorage.removeItem('pos_device');
    showView('login');
}

function goToDashboard() {
    showView('dashboard');
    loadDashboardStats();
}

function goToSale() {
    state.selectedPlan = null;
    renderPlans();
    showView('sale');
}

function goToValidate() {
    document.getElementById('validate-code-input').value = '';
    showView('validate');
    document.getElementById('validate-code-input').focus();
}

async function loadPlans() {
    try {
        const result = await apiCall('/plans');
        if (result && result.success && Array.isArray(result.data) && result.data.length > 0) {
            plans = result.data;
            hideNetworkError();
        } else {
            plans = DEFAULT_PLANS;
        }
    } catch (error) {
        plans = DEFAULT_PLANS;
        plansFallbackActive = true;
        showToast('Plans serveur indisponibles, fallback local activé.', 'warning');
        if (isNetworkError(error)) {
            showNetworkError('Impossible de charger les plans. Vérifiez la connexion et réessayez.', loadPlans);
        } else {
            showError('sale', 'Plans non disponibles sur le serveur. Fallback local activé.');
        }
    }
    renderPlans();
}

// ============ API CALLS ============
async function apiCall(endpoint, method = 'GET', body = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'x-api-key': state.deviceId || 'POS_DEVICE_KEY_001'
        }
    };

    if (body) options.body = JSON.stringify(body);

    try {
        const response = await fetch(API_BASE + endpoint, options);
        const text = await response.text();
        let data = null;

        try {
            data = text ? JSON.parse(text) : null;
        } catch (parsingError) {
            data = { message: text };
        }

        if (!response.ok) {
            const errorMessage = data?.error || data?.message || `HTTP ${response.status}`;
            const error = new Error(errorMessage);
            error.status = response.status;
            throw error;
        }

        if (data && data.success === false) {
            const errorMessage = data.error || data.message || 'Erreur API';
            const error = new Error(errorMessage);
            error.status = 400;
            throw error;
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        if (error instanceof TypeError || error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
            error.status = 0;
            error.message = 'Erreur réseau ou serveur indisponible';
        }
        throw error;
    }
}

async function loginPOS(deviceKey) {
    try {
        showLoading('login');
        const result = await apiCall('/pos/login', 'POST', { device_api_key: deviceKey });
        
        if (result.success) {
            state.sessionToken = deviceKey;
            state.deviceId = deviceKey;
            sessionStorage.setItem('pos_session', deviceKey);
            localStorage.setItem('pos_device', deviceKey);
            
            hideLoading('login');
            hideError('login');
            showToast('Connexion POS réussie', 'success');
            goToDashboard();
            return true;
        } else {
            throw new Error(result.error || 'Login failed');
        }
    } catch (error) {
        hideLoading('login');
        showError('login', error.message);
        return false;
    }
}

async function createSale(planKey, voucherCode, agentName) {
    try {
        showLoading('sale');
        
        const plan = plans.find(p => p.key === planKey);
        if (!plan) throw new Error('Plan non trouvé');

        const result = await apiCall('/sales/create-with-code', 'POST', {
            voucher_code: voucherCode,
            plan_key: planKey,
            price_gdes: plan.price_gdes,
            duration_minutes: plan.duration_minutes,
            agent_name: agentName
        });

        if (result.success) {
            hideNetworkError();
            hideError('sale');
            hideLoading('sale');
            
            state.dailySales++;
            state.dailyRevenue += plan.price_gdes;
            
            showCodeGenerated(
                result.access_code.code,
                planKey,
                plan.price_gdes,
                plan.duration_minutes
            );
            return true;
        } else {
            throw new Error(result.error || 'Sale creation failed');
        }
    } catch (error) {
        hideLoading('sale');
        if (isNetworkError(error)) {
            showNetworkError('Impossible de créer la vente. Vérifiez votre connexion.', () => createSale(planKey, voucherCode, agentName));
        } else {
            showError('sale', error.message);
        }
        return false;
    }
}

async function validateAccessCode(code) {
    try {
        showLoading('validate');
        
        const result = await apiCall('/access-codes/validate', 'POST', { code });

        if (result.success) {
            hideNetworkError();
            hideError('validate');
            hideLoading('validate');
            
            state.currentValidationCode = result.data;
            showValidationResult(result.data, result.valid);
            return true;
        } else {
            throw new Error(result.error || 'Validation failed');
        }
    } catch (error) {
        hideLoading('validate');
        if (isNetworkError(error)) {
            showNetworkError('Impossible de valider le code. Vérifiez votre connexion.', () => validateAccessCode(code));
        } else {
            showError('validate', error.message);
        }
        return false;
    }
}

async function useAccessCode(code) {
    const button = document.getElementById('use-code-btn');
    if (button) button.disabled = true;
    try {
        const result = await apiCall('/access-codes/use', 'POST', { code });

        if (result.success) {
            hideNetworkError();
            showCodeUsed(code);
            return true;
        } else {
            throw new Error(result.error || 'Failed to use code');
        }
    } catch (error) {
        if (isNetworkError(error)) {
            showNetworkError('Impossible d’utiliser le code. Vérifiez votre connexion.', () => useAccessCode(code));
        } else {
            alert('Erreur: ' + error.message);
        }
        return false;
    } finally {
        if (button) button.disabled = false;
    }
}

async function loadDashboardStats() {
    try {
        // Stats locales pour maintenant
        document.getElementById('daily-sales').textContent = state.dailySales;
        document.getElementById('daily-revenue').textContent = state.dailyRevenue + ' GDES';
    } catch (error) {
        console.error('Error loading stats:', error);
    }
}

// ============ UI HELPERS ============
function renderPlans() {
    const container = document.getElementById('plans-container');
    const availablePlans = plans.length > 0 ? plans : DEFAULT_PLANS;
    container.innerHTML = availablePlans.map(plan => `
        <div class="plan-card ${state.selectedPlan === plan.key ? 'selected' : ''}" onclick="selectPlan('${plan.key}')">
            <div class="plan-name">${plan.name}</div>
            <div class="plan-price">${plan.price_gdes} GDES</div>
            <div class="plan-duration">${plan.duration_minutes} minutes</div>
        </div>
    `).join('');
}

function selectPlan(planKey) {
    state.selectedPlan = planKey;
    renderPlans();
}

function showCodeGenerated(code, planKey, price, duration) {
    document.getElementById('generated-code').textContent = code;
    document.getElementById('sale-plan').textContent = planKey;
    document.getElementById('sale-price').textContent = price + ' GDES';
    document.getElementById('sale-duration').textContent = duration + ' minutes';
    showToast('Code généré avec succès', 'success');
    showView('code-generated');
}

function showValidationResult(codeData, isValid) {
    const resultBox = document.getElementById('result-box');
    const durationRemaining = calculateDurationRemaining(codeData);

    if (isValid) {
        resultBox.className = 'result-box valid';
        resultBox.innerHTML = `
            <div class="result-title">✓ Code Valide</div>
            <div class="result-message">Ce code peut être utilisé</div>
        `;
        document.getElementById('use-code-container').style.display = 'block';
    } else {
        resultBox.className = 'result-box invalid';
        const status = codeData.status === 'used' ? 'Déjà utilisé' :
                       codeData.status === 'expired' ? 'Expiré' : 'Invalide';
        resultBox.innerHTML = `
            <div class="result-title">✗ Code ${status}</div>
            <div class="result-message">Ce code ne peut pas être utilisé</div>
        `;
        document.getElementById('use-code-container').style.display = 'none';
    }

    document.getElementById('result-code').textContent = codeData.code;
    document.getElementById('result-plan').textContent = codeData.plan_code;
    document.getElementById('result-status').textContent = codeData.status;
    document.getElementById('result-duration-total').textContent = `${codeData.duration_minutes || 'N/A'} minutes`;
    document.getElementById('result-duration').textContent = durationRemaining;
    document.getElementById('result-created-at').textContent = codeData.created_at ? new Date(codeData.created_at).toLocaleString('fr-FR') : '-';
    document.getElementById('result-used-at').textContent = codeData.used_at ? new Date(codeData.used_at).toLocaleString('fr-FR') : '-';

    showView('validation-result');
}

function showCodeUsed(code) {
    document.getElementById('used-code-display').textContent = code;
    showToast('Code utilisé avec succès', 'success');
    showView('code-used');
}

function calculateDurationRemaining(codeData) {
    if (codeData.status === 'used' || codeData.status === 'expired') {
        return '0 minutes';
    }
    
    if (!codeData.created_at || !codeData.duration_minutes) {
        return 'N/A';
    }

    const created = new Date(codeData.created_at).getTime();
    const now = new Date().getTime();
    const elapsed = Math.floor((now - created) / 60000);
    const remaining = codeData.duration_minutes - elapsed;

    return remaining > 0 ? remaining + ' minutes' : '0 minutes';
}

function setFormBusy(formId, busy) {
    const form = document.getElementById(formId);
    if (!form) return;
    form.querySelectorAll('button, input[type="submit"]').forEach((control) => {
        control.disabled = busy;
    });
}

function showToast(message, type = 'success') {
    let toast = document.getElementById('pos-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'pos-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.className = `toast-notice toast-${type}`;
    toast.style.opacity = '1';
    setTimeout(() => {
        if (toast) {
            toast.style.opacity = '0';
        }
    }, 2800);
}

function showError(section, message) {
    const errorElement = document.getElementById(`${section}-error`);
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

function hideError(section) {
    const errorElement = document.getElementById(`${section}-error`);
    if (errorElement) {
        errorElement.style.display = 'none';
    }
}

function showLoading(section) {
    const loadingElement = document.getElementById(`${section}-loading`);
    if (loadingElement) {
        loadingElement.style.display = 'block';
    }
}

function hideLoading(section) {
    const loadingElement = document.getElementById(`${section}-loading`);
    if (loadingElement) {
        loadingElement.style.display = 'none';
    }
}

function showNetworkError(message, retryAction) {
    const panel = document.getElementById('network-error-panel');
    const text = document.getElementById('network-error-text');
    if (panel && text) {
        text.textContent = message;
        panel.style.display = 'flex';
        lastRetryAction = retryAction;
    }
}

function hideNetworkError() {
    const panel = document.getElementById('network-error-panel');
    if (panel) {
        panel.style.display = 'none';
        lastRetryAction = null;
    }
}

function isNetworkError(error) {
    return !error.status || error.status === 0 || error.message.includes('Erreur réseau') || error.message.includes('Failed to fetch') || error.message.includes('NetworkError');
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert('Code copié!');
    }).catch(err => {
        console.error('Erreur copie:', err);
    });
}

// ============ EVENT LISTENERS ============
document.addEventListener('DOMContentLoaded', () => {
    // Check if session exists
    const savedSession = sessionStorage.getItem('pos_session');
    const savedDevice = localStorage.getItem('pos_device');
    
    if (savedSession && savedDevice) {
        state.sessionToken = savedSession;
        state.deviceId = savedDevice;
        goToDashboard();
    } else {
        showView('login');
    }

    // LOGIN
    document.getElementById('login-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const deviceKey = document.getElementById('device-api-key').value.trim();
        if (!deviceKey) return;
        setFormBusy('login-form', true);
        await loginPOS(deviceKey);
        setFormBusy('login-form', false);
    });

    document.getElementById('logout-btn').addEventListener('click', () => {
        if (confirm('Êtes-vous sûr?')) {
            goToLogin();
        }
    });

    // DASHBOARD
    document.getElementById('new-sale-btn').addEventListener('click', goToSale);
    document.getElementById('validate-code-btn').addEventListener('click', goToValidate);

    // SALE
    document.getElementById('sale-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        if (!state.selectedPlan) {
            showError('sale', 'Veuillez sélectionner un plan');
            return;
        }

        const voucherCode = document.getElementById('voucher-code').value.trim();
        const agentName = document.getElementById('agent-name').value.trim();

        if (!voucherCode || !agentName) {
            showError('sale', 'Tous les champs sont obligatoires');
            return;
        }

        setFormBusy('sale-form', true);
        await createSale(state.selectedPlan, voucherCode, agentName);
        setFormBusy('sale-form', false);
    });

    document.getElementById('back-from-sale-btn').addEventListener('click', goToDashboard);
    document.getElementById('back-from-code-btn').addEventListener('click', goToDashboard);
    document.getElementById('new-sale-again-btn').addEventListener('click', goToSale);

    document.getElementById('copy-code-btn').addEventListener('click', () => {
        const code = document.getElementById('generated-code').textContent;
        copyToClipboard(code);
    });

    document.getElementById('network-error-retry').addEventListener('click', () => {
        if (typeof lastRetryAction === 'function') {
            hideNetworkError();
            lastRetryAction();
        }
    });

    loadPlans();

    // VALIDATE
    document.getElementById('validate-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const code = document.getElementById('validate-code-input').value.trim();
        if (!code) return;
        setFormBusy('validate-form', true);
        await validateAccessCode(code);
        setFormBusy('validate-form', false);
    });

    document.getElementById('back-from-validate-btn').addEventListener('click', goToDashboard);
    document.getElementById('back-from-result-btn').addEventListener('click', goToValidate);
    document.getElementById('validate-another-btn').addEventListener('click', goToValidate);

    // USE CODE
    document.getElementById('use-code-btn').addEventListener('click', async () => {
        if (state.currentValidationCode) {
            await useAccessCode(state.currentValidationCode.code);
        }
    });

    document.getElementById('back-dashboard-btn').addEventListener('click', goToDashboard);
});
function getDeviceId() {
  let deviceId = localStorage.getItem("bv_device_id");

  if (!deviceId) {
    deviceId = crypto.randomUUID();
    localStorage.setItem("bv_device_id", deviceId);
  }

  return deviceId;
}

function showMessage(type, message) {
  const resultDiv = document.getElementById("result");

  resultDiv.innerHTML = `
    <div class="${type}">
      ${message}
    </div>
  `;
}

async function activateCode() {
  const input = document.getElementById("codeInput");
  const code = input.value.trim().toUpperCase();

  if (!code) {
    showMessage("error", "❌ Entre un code.");
    return;
  }

  showMessage("success", "⏳ Vérification du code...");

  const deviceId = getDeviceId();

  try {
    const res = await fetch("/access-codes/use", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": "POS_DEVICE_KEY_001",
        "x-device-id": deviceId
      },
      body: JSON.stringify({
        code,
        device_id: deviceId
      })
    });

    const data = await res.json();

    if (!data.success) {
      if (data.status === "blocked_device") {
        showMessage("error", "🚫 Ce code est déjà utilisé sur un autre appareil.");
        return;
      }

      showMessage("error", `❌ ${data.error || "Code invalide."}`);
      return;
    }

    const remaining = data.remaining_minutes ?? data.data?.remaining_minutes ?? 0;

    showMessage(
      "success",
      `✅ Code activé avec succès.<br>Temps restant : ${remaining} minute(s).`
    );

    input.value = "";
  } catch (err) {
    showMessage("error", "❌ Erreur serveur. Réessaie.");
  }
}
const INTERNAL_TOKEN_KEY = "bv_access_internal_token";

function getInternalToken() {
  return localStorage.getItem(INTERNAL_TOKEN_KEY) || "";
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderQrCell(sale) {
  if (!sale.qr_code_url) return "";

  const qrUrl = escapeHtml(sale.qr_code_url);
  const portalUrl = escapeHtml(sale.portal_url || sale.qr_code_url);

  return `<a href="${portalUrl}" target="_blank" rel="noopener"><img class="qr-img" src="${qrUrl}" alt="QR voucher" /></a>`;
}

function renderAnnouncementBar(announcement) {
  const bar = document.getElementById("announcementBar");
  if (!bar) return;

  if (!announcement) {
    bar.style.display = "none";
    bar.innerHTML = "";
    return;
  }

  const actionUrl =
    announcement.link_url ||
    (announcement.whatsapp
      ? `https://wa.me/${String(announcement.whatsapp).replace(/[^\d]/g, "")}`
      : announcement.phone
        ? `tel:${announcement.phone}`
        : "");

  bar.innerHTML = `
    ${announcement.title ? `<strong>${escapeHtml(announcement.title)}</strong>` : ""}
    ${escapeHtml(announcement.message)}
    ${actionUrl ? `<br><a href="${escapeHtml(actionUrl)}" target="_blank" rel="noopener">Ouvrir</a>` : ""}
  `;
  bar.style.display = "block";
}

async function loadAnnouncementBar(siteCode = "SITE-FORTLIBERTE") {
  try {
    const response = await fetch(
      `/api/announcements?placement=dashboard_owner&site_code=${encodeURIComponent(siteCode)}&limit=1`,
      { cache: "no-store" }
    );
    const data = await response.json();
    renderAnnouncementBar(data.announcements?.[0] || null);
  } catch (error) {
    console.warn("Owner announcement unavailable:", error);
    renderAnnouncementBar(null);
  }
}

async function secureFetch(url, options = {}) {
  const headers = {
    ...(options.headers || {}),
  };
  const token = getInternalToken();

  if (token) {
    headers["X-BV-Access-Token"] = token;
  }

  let response = await fetch(url, {
    ...options,
    headers,
  });

  if (response.status === 401 || response.status === 403) {
    const nextToken = window.prompt("Token interne B&V Access");

    if (nextToken) {
      localStorage.setItem(INTERNAL_TOKEN_KEY, nextToken.trim());
      response = await fetch(url, {
        ...options,
        headers: {
          ...(options.headers || {}),
          "X-BV-Access-Token": nextToken.trim(),
        },
      });
    }
  }

  return response;
}

async function loadOwnerDashboard() {
  const siteCode = "SITE-FORTLIBERTE";
  const apiUrl = `http://localhost:3000/owner-dashboard/${siteCode}`;

  try {
    const response = await secureFetch(apiUrl);
    const data = await response.json();

    if (!data.success) {
      document.getElementById("errorBox").textContent =
        data.error || "Erreur de chargement du dashboard propriétaire.";
      return;
    }

    const site = data.site || {};
    const stats = data.stats || {};

    document.getElementById("siteName").textContent =
      site.name || "Site B&V Access";

    document.getElementById("siteCode").textContent =
      site.site_code || siteCode;

    document.getElementById("siteCity").textContent =
      site.city || "-";

    document.getElementById("totalRevenue").textContent =
      `${stats.total_revenue || 0} GDES`;

    document.getElementById("todayRevenue").textContent =
      `${stats.today_revenue || 0} GDES`;

    document.getElementById("totalSales").textContent =
      stats.total_sales || 0;

    document.getElementById("totalAgents").textContent =
      stats.total_agents || 0;

    document.getElementById("activeCodes").textContent =
      stats.active_codes || 0;

    document.getElementById("usedCodes").textContent =
      stats.used_codes || 0;

    document.getElementById("activeSessions").textContent =
      stats.active_sessions || 0;

    document.getElementById("totalCommissions").textContent =
      `${stats.total_commissions || 0} GDES`;

    const salesTable = document.getElementById("salesTable");
    salesTable.innerHTML = "";

    (data.recent_sales || []).forEach((sale) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${sale.created_at || ""}</td>
        <td>${sale.voucher_code || ""}</td>
        <td class="qr-cell">${renderQrCell(sale)}</td>
        <td>${sale.product_name || ""}</td>
        <td>${sale.amount || 0}</td>
        <td>${sale.agent_code || ""}</td>
        <td>${sale.customer_name || ""}</td>
      `;

      salesTable.appendChild(row);
    });

    const agentsTable = document.getElementById("agentsTable");
    agentsTable.innerHTML = "";

    (data.agents || []).forEach((agent) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${agent.agent_code || ""}</td>
        <td>${agent.full_name || ""}</td>
        <td>${agent.city || ""}</td>
        <td>${agent.status || ""}</td>
        <td>${agent.access_commission_percent || 0}%</td>
      `;

      agentsTable.appendChild(row);
    });
  } catch (error) {
    console.error("Owner dashboard load failed:", error);

    document.getElementById("errorBox").textContent =
      "Erreur de connexion au serveur.";
  }
}

loadOwnerDashboard();
loadAnnouncementBar("SITE-FORTLIBERTE");

setInterval(loadOwnerDashboard, 10000);
setInterval(() => loadAnnouncementBar("SITE-FORTLIBERTE"), 60000);

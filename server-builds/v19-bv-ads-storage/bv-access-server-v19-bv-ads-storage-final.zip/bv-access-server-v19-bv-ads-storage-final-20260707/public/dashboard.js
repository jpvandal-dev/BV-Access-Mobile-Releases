const API_BASE_URL = "";
const INTERNAL_TOKEN_KEY = "bv_access_internal_token";
let editingAnnouncementId = "";

function getInternalToken() {
  return localStorage.getItem(INTERNAL_TOKEN_KEY) || "";
}

async function secureFetch(url, options = {}) {
  const headers = {
    ...(options.headers || {}),
  };
  const token = getInternalToken();

  if (token) {
    headers["X-BV-Access-Token"] = token;
  }

  let response = await fetch(url, {
    ...options,
    headers,
  });

  if (response.status === 401 || response.status === 403) {
    const nextToken = window.prompt("Token interne B&V Access");

    if (nextToken) {
      localStorage.setItem(INTERNAL_TOKEN_KEY, nextToken.trim());
      response = await fetch(url, {
        ...options,
        headers: {
          ...(options.headers || {}),
          "X-BV-Access-Token": nextToken.trim(),
        },
      });
    }
  }

  return response;
}

function setText(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function renderQrCell(sale) {
  if (!sale.qr_code_url) return "";

  const qrUrl = escapeHtml(sale.qr_code_url);
  const portalUrl = escapeHtml(sale.portal_url || sale.qr_code_url);

  return `<a href="${portalUrl}" target="_blank" rel="noopener"><img class="qr-img" src="${qrUrl}" alt="QR voucher" /></a>`;
}

function formatMoney(value) {
  const amount = Number(value || 0);
  return `${amount.toLocaleString("fr-FR")} GDES`;
}

function formatDate(value) {
  if (!value) return "-";
  const date = new Date(value);
  return date.toLocaleString("fr-FR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function showError(message) {
  const errorBox = document.getElementById("errorBox");
  if (!errorBox) return;

  errorBox.style.display = "block";
  errorBox.textContent = message;
}

function hideError() {
  const errorBox = document.getElementById("errorBox");
  if (!errorBox) return;

  errorBox.style.display = "none";
  errorBox.textContent = "";
}

function parseCsv(value) {
  return String(value || "")
    .split(",")
    .map((item) => item.trim().toUpperCase())
    .filter(Boolean);
}

function renderAnnouncementBar(announcement) {
  const bar = document.getElementById("announcementBar");
  if (!bar) return;

  if (!announcement) {
    bar.style.display = "none";
    bar.innerHTML = "";
    return;
  }

  const actionUrl =
    announcement.link_url ||
    (announcement.whatsapp
      ? `https://wa.me/${String(announcement.whatsapp).replace(/[^\d]/g, "")}`
      : announcement.phone
        ? `tel:${announcement.phone}`
        : "");

  bar.innerHTML = `
    ${announcement.title ? `<strong>${escapeHtml(announcement.title)}</strong>` : ""}
    ${escapeHtml(announcement.message)}
    ${actionUrl ? `<br><a href="${escapeHtml(actionUrl)}" target="_blank" rel="noopener">Ouvrir</a>` : ""}
  `;
  bar.style.display = "block";
}

async function loadAnnouncementBar() {
  try {
    const response = await fetch(
      `${API_BASE_URL}/api/announcements?placement=dashboard_admin&site_code=SITE-FORTLIBERTE&limit=1`,
      { cache: "no-store" }
    );
    const data = await response.json();
    renderAnnouncementBar(data.announcements?.[0] || null);
  } catch (error) {
    console.warn("Announcement bar unavailable:", error);
    renderAnnouncementBar(null);
  }
}

function renderAnnouncementList(announcements) {
  const list = document.getElementById("announcementList");
  if (!list) return;

  if (!announcements || announcements.length === 0) {
    list.innerHTML = `<div class="muted">Aucune annonce publiée.</div>`;
    return;
  }

  list.innerHTML = announcements
    .slice(0, 8)
    .map((announcement) => {
      const scope =
        announcement.scope === "local"
          ? (announcement.site_codes || []).join(", ") || "Local"
          : "National";

      return `
        <div class="announcement-item">
          <div>
            <strong>${escapeHtml(announcement.message)}</strong><br>
            <span class="muted">${escapeHtml(scope)} · priorité ${Number(announcement.priority || 100)}</span>
          </div>
          <button class="announcement-toggle" data-edit-id="${escapeHtml(announcement.id)}">
            Modifier
          </button>
          <button class="announcement-toggle" data-id="${escapeHtml(announcement.id)}" data-active="${announcement.active ? "1" : "0"}">
            ${announcement.active ? "Désactiver" : "Activer"}
          </button>
        </div>
      `;
    })
    .join("");

  list.querySelectorAll(".announcement-toggle").forEach((button) => {
    if (button.dataset.editId) {
      button.addEventListener("click", () => {
        const announcement = announcements.find(
          (item) => item.id === button.dataset.editId
        );
        if (announcement) editAnnouncement(announcement);
      });
      return;
    }

    button.addEventListener("click", async () => {
      await toggleAnnouncement(button.dataset.id, button.dataset.active !== "1");
    });
  });
}

async function loadAdminAnnouncements() {
  const status = document.getElementById("announcementStatus");

  try {
    const response = await secureFetch(`${API_BASE_URL}/admin/announcements`);
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Erreur annonces: ${response.status}`);
    }

    renderAnnouncementList(data.announcements || []);
    if (status) status.textContent = "";
  } catch (error) {
    console.error("Admin announcements load failed:", error);
    if (status) status.textContent = error.message || "Erreur annonces.";
  }
}

async function publishAnnouncement() {
  const status = document.getElementById("announcementStatus");
  const message = document.getElementById("announcementMessage")?.value || "";
  const scope = document.getElementById("announcementScope")?.value || "national";

  if (!message.trim()) {
    if (status) status.textContent = "Texte obligatoire.";
    return;
  }

  try {
    if (status) status.textContent = editingAnnouncementId ? "Modification..." : "Publication...";
    const endpoint = editingAnnouncementId
      ? `${API_BASE_URL}/admin/announcements/${encodeURIComponent(editingAnnouncementId)}`
      : `${API_BASE_URL}/admin/announcements`;
    const response = await secureFetch(endpoint, {
      method: editingAnnouncementId ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: document.getElementById("announcementTitle")?.value || "",
        message,
        active: true,
        scope,
        site_codes: parseCsv(document.getElementById("announcementSites")?.value || ""),
        placements: [
          "global",
          "portal",
          "mobile_home",
          "plans",
          "payment_confirmation",
          "dashboard_admin",
          "dashboard_agent",
          "dashboard_owner",
        ],
        priority: Number(document.getElementById("announcementPriority")?.value || 100),
        whatsapp: document.getElementById("announcementWhatsapp")?.value || null,
        link_url: document.getElementById("announcementUrl")?.value || null,
        starts_at: document.getElementById("announcementStartsAt")?.value || null,
        ends_at: document.getElementById("announcementEndsAt")?.value || null,
      }),
    });
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Erreur publication: ${response.status}`);
    }

    document.getElementById("announcementMessage").value = "";
    editingAnnouncementId = "";
    if (status) status.textContent = "Annonce enregistrée.";
    await loadAdminAnnouncements();
    await loadAnnouncementBar();
  } catch (error) {
    console.error("Announcement publish failed:", error);
    if (status) status.textContent = error.message || "Publication impossible.";
  }
}

function editAnnouncement(announcement) {
  editingAnnouncementId = announcement.id;
  document.getElementById("announcementTitle").value = announcement.title || "";
  document.getElementById("announcementMessage").value = announcement.message || "";
  document.getElementById("announcementScope").value = announcement.scope || "national";
  document.getElementById("announcementSites").value = (announcement.site_codes || []).join(", ");
  document.getElementById("announcementPriority").value = announcement.priority || 100;
  document.getElementById("announcementWhatsapp").value = announcement.whatsapp || "";
  document.getElementById("announcementUrl").value = announcement.link_url || "";
  document.getElementById("announcementStartsAt").value = announcement.starts_at || "";
  document.getElementById("announcementEndsAt").value = announcement.ends_at || "";
  setText("announcementStatus", "Mode modification actif.");
}

async function toggleAnnouncement(id, active) {
  const status = document.getElementById("announcementStatus");

  try {
    const response = await secureFetch(
      `${API_BASE_URL}/admin/announcements/${encodeURIComponent(id)}`,
      {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ active }),
      }
    );
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Erreur modification: ${response.status}`);
    }

    if (status) status.textContent = "Annonce mise à jour.";
    await loadAdminAnnouncements();
    await loadAnnouncementBar();
  } catch (error) {
    console.error("Announcement toggle failed:", error);
    if (status) status.textContent = error.message || "Modification impossible.";
  }
}

function normalizeMacInput(value) {
  const cleaned = String(value || "").toLowerCase().replace(/[^a-f0-9]/g, "");
  if (cleaned.length !== 12) return "";
  return cleaned.match(/.{1,2}/g).join(":");
}

function selectedAgentPayload() {
  const select = document.getElementById("privilegedAgentSelect");
  const option = select?.selectedOptions?.[0];

  if (!option || !option.value) return null;

  return {
    agent_user_id: option.value,
    agent_code: option.dataset.agentCode || "",
    agent_name: option.dataset.agentName || "",
    agent_phone: option.dataset.agentPhone || "",
    site_code: option.dataset.siteCode || "",
  };
}

function renderPrivilegedAgents(agents) {
  const select = document.getElementById("privilegedAgentSelect");
  if (!select) return;

  if (!agents || agents.length === 0) {
    select.innerHTML = `<option value="">Aucun agent actif trouvé</option>`;
    return;
  }

  select.innerHTML = [
    `<option value="">Choisir un agent</option>`,
    ...agents.map((agent) => {
      const label = `${agent.full_name || agent.agent_code || "Agent"} · ${
        agent.agent_code || "-"
      } · ${agent.site_code || "-"}`;

      return `
        <option
          value="${escapeHtml(agent.id)}"
          data-agent-code="${escapeHtml(agent.agent_code || "")}"
          data-agent-name="${escapeHtml(agent.full_name || "")}"
          data-agent-phone="${escapeHtml(agent.phone || "")}"
          data-site-code="${escapeHtml(agent.site_code || "")}"
          ${agent.active ? "" : "disabled"}
        >
          ${escapeHtml(label)}${agent.active ? "" : " · suspendu"}
        </option>
      `;
    }),
  ].join("");

  select.addEventListener("change", () => {
    const agent = selectedAgentPayload();
    if (agent?.site_code) {
      const siteInput = document.getElementById("privilegedSiteCode");
      if (siteInput) siteInput.value = agent.site_code;
    }
  });
}

function renderPrivilegedDevices(devices) {
  const table = document.getElementById("privilegedDevicesTable");
  if (!table) return;

  if (!devices || devices.length === 0) {
    table.innerHTML = `
      <tr>
        <td colspan="8" class="muted">Aucun appareil privilégié autorisé.</td>
      </tr>
    `;
    return;
  }

  table.innerHTML = devices
    .map((device) => {
      const isActive = device.status === "active";
      const isSuspended = device.status === "suspended";

      return `
        <tr>
          <td>${escapeHtml(device.agent_name || device.agent_code || "-")}</td>
          <td>${escapeHtml(device.agent_phone || "-")}</td>
          <td>${escapeHtml(device.site_code || "-")}</td>
          <td>${escapeHtml(device.mac_address || "-")}</td>
          <td>${escapeHtml(device.status || "-")}</td>
          <td>${formatDate(device.authorized_at)}</td>
          <td>${formatDate(device.last_seen_at || device.last_authorized_at)}</td>
          <td>
            ${
              isActive
                ? `<button class="admin-action warning" data-priv-action="suspend" data-id="${escapeHtml(device.id)}">Suspendre</button>`
                : ""
            }
            ${
              isSuspended || device.status === "revoked"
                ? `<button class="admin-action success" data-priv-action="reactivate" data-id="${escapeHtml(device.id)}">Réactiver</button>`
                : ""
            }
            <button class="admin-action danger" data-priv-action="revoke" data-id="${escapeHtml(device.id)}">Désautoriser</button>
          </td>
        </tr>
      `;
    })
    .join("");

  table.querySelectorAll("[data-priv-action]").forEach((button) => {
    button.addEventListener("click", async () => {
      await updatePrivilegedDevice(button.dataset.id, button.dataset.privAction);
    });
  });
}

async function loadPrivilegedAgents() {
  const status = document.getElementById("privilegedDeviceStatus");

  try {
    const response = await secureFetch(`${API_BASE_URL}/admin/agent-profiles`);
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Erreur agents: ${response.status}`);
    }

    renderPrivilegedAgents(data.agents || []);
  } catch (error) {
    console.error("Privileged agents load failed:", error);
    if (status) status.textContent = error.message || "Chargement agents impossible.";
  }
}

async function loadPrivilegedDevices() {
  const status = document.getElementById("privilegedDeviceStatus");

  try {
    const response = await secureFetch(
      `${API_BASE_URL}/admin/agent-privileged-devices`
    );
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Erreur accès privilégiés: ${response.status}`);
    }

    renderPrivilegedDevices(data.devices || []);
  } catch (error) {
    console.error("Privileged devices load failed:", error);
    if (status) status.textContent = error.message || "Chargement accès impossible.";
  }
}

async function authorizePrivilegedDevice() {
  const status = document.getElementById("privilegedDeviceStatus");
  const agent = selectedAgentPayload();
  const siteCode = document.getElementById("privilegedSiteCode")?.value || "";
  const macAddress = normalizeMacInput(
    document.getElementById("privilegedMacAddress")?.value || ""
  );
  const deviceLabel = document.getElementById("privilegedDeviceLabel")?.value || "";

  if (!agent) {
    if (status) status.textContent = "Choisissez un agent.";
    return;
  }

  if (!macAddress) {
    if (status) status.textContent = "Adresse MAC invalide.";
    return;
  }

  try {
    if (status) status.textContent = "Autorisation UniFi en cours...";

    const response = await secureFetch(
      `${API_BASE_URL}/admin/agent-privileged-devices/authorize`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...agent,
          site_code: siteCode || agent.site_code,
          mac_address: macAddress,
          device_label: deviceLabel,
        }),
      }
    );
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Autorisation impossible: ${response.status}`);
    }

    if (status) {
      status.textContent = data.replaced_device
        ? "Nouvel appareil autorisé. Ancien appareil désautorisé."
        : "Appareil agent autorisé.";
    }

    await loadPrivilegedDevices();
  } catch (error) {
    console.error("Privileged device authorize failed:", error);
    if (status) status.textContent = error.message || "Autorisation impossible.";
  }
}

async function updatePrivilegedDevice(id, action) {
  const status = document.getElementById("privilegedDeviceStatus");
  const actionLabels = {
    suspend: "Suspension",
    reactivate: "Réactivation",
    revoke: "Désautorisation",
  };

  try {
    if (status) status.textContent = `${actionLabels[action] || "Action"} en cours...`;

    const response = await secureFetch(
      `${API_BASE_URL}/admin/agent-privileged-devices/${encodeURIComponent(id)}/${action}`,
      {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason: `${actionLabels[action] || "Action"} depuis Dashboard Admin` }),
      }
    );
    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(data.error || `Action impossible: ${response.status}`);
    }

    if (status) status.textContent = `${actionLabels[action] || "Action"} réussie.`;
    await loadPrivilegedDevices();
  } catch (error) {
    console.error("Privileged device action failed:", error);
    if (status) status.textContent = error.message || "Action impossible.";
  }
}

function renderRecentSales(sales) {
  const table = document.getElementById("recentSalesTable");
  if (!table) return;

  if (!sales || sales.length === 0) {
    table.innerHTML = `
      <tr>
        <td colspan="9" class="muted">Aucune vente récente.</td>
      </tr>
    `;
    return;
  }

  table.innerHTML = sales
    .map((sale) => {
      return `
        <tr>
          <td>${formatDate(sale.created_at)}</td>
          <td>${sale.voucher_code || "-"}</td>
          <td class="qr-cell">${renderQrCell(sale)}</td>
          <td>${sale.product_name || "-"}</td>
          <td>${formatMoney(sale.amount)}</td>
          <td>${sale.payment_method || "-"}</td>
          <td>${sale.customer_name || "-"}</td>
          <td>${sale.agent_code || sale.agent_id || "-"}</td>
          <td>${sale.site_code || "-"}</td>
        </tr>
      `;
    })
    .join("");
}

async function loadDashboardData() {
  try {
    hideError();

    const response = await secureFetch(`${API_BASE_URL}/dashboard-data`);

    if (!response.ok) {
      throw new Error(`Erreur serveur: ${response.status}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.error || "Réponse serveur invalide");
    }

    setText("revenueTotal", formatMoney(data.revenue_total_gdes));
    setText("revenueToday", formatMoney(data.revenue_today_gdes));
    setText("totalSales", Number(data.total_sales || 0).toLocaleString("fr-FR"));
    setText("totalCodes", Number(data.total_codes || 0).toLocaleString("fr-FR"));
    setText("lockedCodes", Number(data.locked_codes || 0).toLocaleString("fr-FR"));
    setText("totalAgents", Number(data.total_agents || 0).toLocaleString("fr-FR"));

    renderRecentSales(data.recent_sales || []);

    setText("syncStatus", "Connecté à Supabase");
  } catch (error) {
    console.error("Dashboard Admin National load failed:", error);
    setText("syncStatus", "Erreur de connexion");
    showError("Erreur de connexion au serveur.");
  }
}

loadDashboardData();
loadAnnouncementBar();
loadAdminAnnouncements();
loadPrivilegedAgents();
loadPrivilegedDevices();
document
  .getElementById("publishAnnouncementBtn")
  ?.addEventListener("click", publishAnnouncement);
document
  .getElementById("authorizePrivilegedDeviceBtn")
  ?.addEventListener("click", authorizePrivilegedDevice);
setInterval(loadDashboardData, 10000);
setInterval(loadAnnouncementBar, 60000);
setInterval(loadPrivilegedDevices, 60000);

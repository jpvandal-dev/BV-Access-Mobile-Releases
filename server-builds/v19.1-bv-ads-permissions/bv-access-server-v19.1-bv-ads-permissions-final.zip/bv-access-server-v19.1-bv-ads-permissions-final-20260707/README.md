# B&V Access Server v19.1 - B&V Ads Permissions

Build: server-v19-bv-ads-storage

Corrections incluses:
- Backend compatible champs Ads: category, image_url, logo_url, cta_label, cta_url, site_id, is_active.
- Route Admin DELETE /admin/announcements/:id ajoutee pour archiver proprement une annonce.
- Scripts Supabase Ads inclus.

Ordre obligatoire:
1. Executer bv-access-mobile/supabase/ad_banners.sql dans Supabase SQL Editor.
2. Executer bv-access-mobile/supabase/ad_banners_verify.sql.
3. Executer bv-access-mobile/supabase/ad_banners_permissions_verify.sql.
4. Deployer ce backend sur Render.
5. Verifier /health puis upload Ads depuis APK Admin.

Bucket attendu: bv-ad-banners
Formats: JPG, PNG, WebP

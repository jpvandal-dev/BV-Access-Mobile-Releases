const express = require("express");
const cors = require("cors");
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const { createClient } = require("@supabase/supabase-js");
const path = require("path");

require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const SERVER_BUILD = "server-v19-bv-ads-storage";
const HAITI_TIME_ZONE = "America/Port-au-Prince";
const REGIONAL_NODE_CODE = normalizeSiteCode(
  process.env.BV_REGIONAL_NODE_CODE || "BV-REGIONAL-NODE-001"
);
const DEFAULT_SITE_CODE = normalizeSiteCode(
  process.env.BV_DEFAULT_SITE_CODE || "SITE-FORTLIBERTE"
);
const CONNECTED_USAGE_PLAN_CODES = new Set(["PLAN10", "PLAN30", "PLAN60", "PLAN180"]);
const FIXED_WINDOW_PLAN_CODES = new Set(["PLANNUIT", "PLANNIGHT"]);
const SESSION_OPTIONAL_COLUMNS = new Set([
  "last_seen_at",
  "last_accounted_at",
  "paused_at",
  "seconds_consumed",
  "billing_mode",
  "expires_at",
  "unifi_connected",
  "unifi_authorized",
]);
const DOWNLOADS_DIR = path.join(__dirname, "bv-access-mobile", "builds");
const PUBLIC_APK_FILES = new Set([
  "bv-access-mobile-v1.0.2-production-prep-release.apk",
]);
const IS_PRODUCTION = process.env.NODE_ENV === "production";
const PILOT_SECURITY_ENABLED =
  parseBoolean(process.env.PILOT_SECURITY_ENABLED) ||
  parseBoolean(process.env.BV_PILOT_SECURE) ||
  IS_PRODUCTION;

const dashboardRateLimiter = createRateLimiter({
  name: "dashboard",
  windowMs: 60 * 1000,
  max: 120,
});
const voucherRateLimiter = createRateLimiter({
  name: "voucher",
  windowMs: 60 * 1000,
  max: 80,
});
const validateAccessRateLimiter = createRateLimiter({
  name: "validate-access",
  windowMs: 60 * 1000,
  max: 40,
});
const saleRateLimiter = createRateLimiter({
  name: "sale",
  windowMs: 60 * 1000,
  max: 30,
});
const paymentRateLimiter = createRateLimiter({
  name: "mobile-payment",
  windowMs: 60 * 1000,
  max: 60,
});

app.set("trust proxy", 1);
app.use(
  cors({
    origin: corsOriginDelegate,
    credentials: true,
  })
);
app.use("/webhook/shopify", express.raw({ type: "*/*" }));
app.use(express.json({ limit: "10mb" }));
app.use((req, res, next) => {
  res.setHeader("X-BV-Access-Build", SERVER_BUILD);
  next();
});
app.use(
  express.static(path.join(__dirname, "public"), {
    setHeaders: (res, filePath) => {
      if (filePath.endsWith(".html")) {
        res.setHeader(
          "Cache-Control",
          "no-store, no-cache, must-revalidate, proxy-revalidate"
        );
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");
      }
    },
  })
);

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

function parseBoolean(value) {
  return ["1", "true", "yes", "on"].includes(
    String(value || "").trim().toLowerCase()
  );
}

function splitEnvList(value) {
  return String(value || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

function getAllowedCorsOrigins() {
  const configured = splitEnvList(
    process.env.CORS_ALLOWED_ORIGINS || process.env.CORS_ORIGINS
  );

  if (configured.length > 0) return configured;

  return [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
    "https://bv-access-api.onrender.com",
    "https://betvsolutions.com",
    "https://www.betvsolutions.com",
  ];
}

function isCorsRestricted() {
  return (
    PILOT_SECURITY_ENABLED ||
    Boolean(process.env.CORS_ALLOWED_ORIGINS || process.env.CORS_ORIGINS)
  );
}

function corsOriginDelegate(origin, callback) {
  if (!origin || !isCorsRestricted()) {
    return callback(null, true);
  }

  const allowedOrigins = getAllowedCorsOrigins();

  if (allowedOrigins.includes(origin)) {
    return callback(null, true);
  }

  bvDebug("CORS ORIGIN BLOCKED", {
    origin,
    allowed_origins: allowedOrigins,
    pilot_security_enabled: PILOT_SECURITY_ENABLED,
  });

  return callback(null, false);
}

function createRateLimiter({ name, windowMs, max }) {
  const buckets = new Map();

  return (req, res, next) => {
    const now = Date.now();
    const key = `${name}:${req.ip || req.socket?.remoteAddress || "unknown"}`;
    const bucket = buckets.get(key);

    if (!bucket || bucket.resetAt <= now) {
      buckets.set(key, {
        count: 1,
        resetAt: now + windowMs,
      });
      return next();
    }

    bucket.count += 1;

    if (bucket.count > max) {
      return res.status(429).json({
        success: false,
        error: "Trop de requêtes. Réessayez dans quelques instants.",
        rate_limit: {
          name,
          max,
          window_seconds: Math.ceil(windowMs / 1000),
        },
      });
    }

    return next();
  };
}

function getInternalAuthConfigs() {
  const configs = [];

  addInternalToken(configs, {
    token:
      process.env.BV_ADMIN_TOKEN ||
      process.env.DASHBOARD_ADMIN_TOKEN ||
      process.env.BV_INTERNAL_TOKEN,
    role: "admin_bv",
    label: "admin",
  });

  addInternalToken(configs, {
    token: process.env.BV_AGENT_TOKEN || process.env.DASHBOARD_AGENT_TOKEN,
    role: "agent",
    label: "agent",
    agentCode: process.env.BV_AGENT_CODE || "BV-AGENT-001",
    siteCode: process.env.BV_AGENT_SITE_CODE || DEFAULT_SITE_CODE,
  });

  addInternalToken(configs, {
    token: process.env.BV_OWNER_TOKEN || process.env.DASHBOARD_OWNER_TOKEN,
    role: "site_owner",
    label: "site_owner",
    siteCode: process.env.BV_OWNER_SITE_CODE || DEFAULT_SITE_CODE,
  });

  return configs;
}

function addInternalToken(configs, config) {
  if (!config.token) return;

  configs.push({
    role: config.role,
    label: config.label,
    token: String(config.token),
    agentCode: config.agentCode || null,
    siteCode: config.siteCode || null,
  });
}

function getRequestAuthToken(req) {
  const headerToken =
    req.headers["x-bv-access-token"] ||
    req.headers["x-dashboard-token"] ||
    req.headers["x-api-key"];
  const authorization = String(req.headers.authorization || "");
  const bearerMatch = authorization.match(/^Bearer\s+(.+)$/i);

  return String(headerToken || bearerMatch?.[1] || "").trim();
}

function getInternalHeaderToken(req) {
  return String(
    req.headers["x-bv-access-token"] ||
      req.headers["x-dashboard-token"] ||
      req.headers["x-api-key"] ||
      ""
  ).trim();
}

function getBearerToken(req) {
  const authorization = String(req.headers.authorization || "");
  const bearerMatch = authorization.match(/^Bearer\s+(.+)$/i);
  return String(bearerMatch?.[1] || "").trim();
}

async function requireSupabaseUserOrInternal(req, res, next) {
  if (!PILOT_SECURITY_ENABLED) return next();

  const internalToken = getInternalHeaderToken(req);
  const internalAuth = getInternalAuthConfigs().find(
    (config) => config.token === internalToken
  );

  if (internalAuth) {
    req.bvAuth = {
      role: internalAuth.role,
      label: internalAuth.label,
      agentCode: internalAuth.agentCode,
      siteCode: internalAuth.siteCode,
    };
    return next();
  }

  const bearerToken = getBearerToken(req);

  if (!bearerToken) {
    return res.status(401).json({
      success: false,
      error: "Session Supabase requise pour cette action mobile.",
    });
  }

  const {
    data: userData,
    error: userError,
  } = await supabase.auth.getUser(bearerToken);

  if (userError || !userData?.user) {
    return res.status(401).json({
      success: false,
      error: "Session Supabase invalide.",
    });
  }

  const profile = await fetchServerUserProfile(userData.user.id);

  if (!profile) {
    return res.status(403).json({
      success: false,
      error: "Profil serveur B&V introuvable.",
    });
  }

  if (profile.active === false) {
    return res.status(403).json({
      success: false,
      error: "Profil serveur B&V désactivé.",
    });
  }

  req.supabaseUser = userData.user;
  req.bvAuth = {
    role: profile.role,
    label: profile.full_name || profile.role,
    agentCode: profile.agent_code || null,
    siteCode: profile.site_code || null,
    userId: userData.user.id,
  };

  return next();
}

async function fetchServerUserProfile(userId) {
  const { data, error } = await supabase
    .from("user_profiles")
    .select("id, full_name, role, site_code, agent_code, provider_code, active")
    .eq("id", userId)
    .maybeSingle();

  if (error) {
    logDiagnosticError("FETCH SERVER USER PROFILE ERROR", error);
    return null;
  }

  return data || null;
}

function requireInternalAuth(allowedRoles = []) {
  return (req, res, next) => {
    if (!PILOT_SECURITY_ENABLED) return next();

    const configs = getInternalAuthConfigs();

    if (configs.length === 0) {
      return res.status(503).json({
        success: false,
        error:
          "Sécurité pilote active, mais aucun token interne n'est configuré côté serveur.",
        required_env:
          "BV_ADMIN_TOKEN, BV_AGENT_TOKEN ou BV_OWNER_TOKEN selon le rôle.",
      });
    }

    const token = getRequestAuthToken(req);

    if (!token) {
      return res.status(401).json({
        success: false,
        error: "Authentification interne B&V requise.",
      });
    }

    const auth = configs.find((config) => config.token === token);

    if (!auth) {
      return res.status(403).json({
        success: false,
        error: "Token interne B&V invalide.",
      });
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(auth.role)) {
      return res.status(403).json({
        success: false,
        error: "Rôle non autorisé pour cette action.",
        role: auth.role,
      });
    }

    req.bvAuth = {
      role: auth.role,
      label: auth.label,
      agentCode: auth.agentCode,
      siteCode: auth.siteCode,
    };

    return next();
  };
}

function requireBvAuthRoles(allowedRoles = []) {
  return (req, res, next) => {
    if (!PILOT_SECURITY_ENABLED) return next();

    const role = req.bvAuth?.role;

    if (!role) {
      return res.status(401).json({
        success: false,
        error: "Session B&V authentifiée requise.",
      });
    }

    if (allowedRoles.length > 0 && !allowedRoles.includes(role)) {
      return res.status(403).json({
        success: false,
        error: "Rôle non autorisé pour cette action.",
        role,
      });
    }

    return next();
  };
}

function enforceAgentScope(req, res, next) {
  if (!PILOT_SECURITY_ENABLED || !req.bvAuth) return next();
  if (req.bvAuth.role === "admin_bv") return next();

  const requestedAgentCode = String(
    req.params.agent_code || req.body?.agent_code || ""
  ).trim();

  if (req.bvAuth.role === "agent" && req.bvAuth.agentCode === requestedAgentCode) {
    return next();
  }

  return res.status(403).json({
    success: false,
    error: "Agent non autorisé pour cette ressource.",
  });
}

function enforceOwnerSiteScope(req, res, next) {
  if (!PILOT_SECURITY_ENABLED || !req.bvAuth) return next();
  if (req.bvAuth.role === "admin_bv") return next();

  const requestedSiteCode = String(
    req.params.site_code || req.body?.site_code || ""
  )
    .trim()
    .toUpperCase();
  const allowedSiteCode = String(req.bvAuth.siteCode || "")
    .trim()
    .toUpperCase();

  if (req.bvAuth.role === "site_owner" && requestedSiteCode === allowedSiteCode) {
    return next();
  }

  if (req.bvAuth.role === "agent" && requestedSiteCode === allowedSiteCode) {
    return next();
  }

  return res.status(403).json({
    success: false,
    error: "Site non autorisé pour cette ressource.",
  });
}

function canAccessReservation(req, reservation) {
  if (!PILOT_SECURITY_ENABLED || !req.bvAuth) return true;
  if (req.bvAuth.role === "admin_bv") return true;

  if (req.bvAuth.role === "client") {
    return Boolean(
      reservation?.client_user_id &&
        req.bvAuth.userId &&
        String(reservation.client_user_id) === String(req.bvAuth.userId)
    );
  }

  const reservationSiteCode = String(reservation?.site_code || "")
    .trim()
    .toUpperCase();
  const allowedSiteCode = String(req.bvAuth.siteCode || "")
    .trim()
    .toUpperCase();

  if (!reservationSiteCode || !allowedSiteCode) return false;

  if (req.bvAuth.role === "agent") {
    return reservationSiteCode === allowedSiteCode;
  }

  if (req.bvAuth.role === "site_owner") {
    return reservationSiteCode === allowedSiteCode;
  }

  return false;
}

function requirePaymentProviderConfirmation(req, res, next) {
  if (!PILOT_SECURITY_ENABLED) return next();

  const transaction = req.body?.transaction || {};
  const providerTransactionId =
    transaction.providerTransactionId ||
    transaction.provider_transaction_id ||
    transaction.provider_reference ||
    transaction.reference_provider;
  const message = String(transaction.message || "").toLowerCase();

  if (!providerTransactionId || message.includes("simul")) {
    return res.status(409).json({
      success: false,
      error:
        "Paiement direct simulé bloqué en mode pilote sécurisé. Configurez un provider réel ou utilisez le cash agent.",
    });
  }

  return next();
}

function verifyShopifyWebhookSignature(req, res, next) {
  if (!PILOT_SECURITY_ENABLED) return next();

  const secret = process.env.SHOPIFY_WEBHOOK_SECRET;

  if (!secret) {
    return res.status(503).json({
      success: false,
      error:
        "Signature Shopify requise en mode pilote sécurisé, mais SHOPIFY_WEBHOOK_SECRET est absent.",
    });
  }

  const receivedHmac = String(req.headers["x-shopify-hmac-sha256"] || "");

  if (!receivedHmac || !Buffer.isBuffer(req.body)) {
    return res.status(401).json({
      success: false,
      error: "Signature Shopify manquante.",
    });
  }

  const expectedHmac = crypto
    .createHmac("sha256", secret)
    .update(req.body)
    .digest("base64");
  const receivedBuffer = Buffer.from(receivedHmac, "utf8");
  const expectedBuffer = Buffer.from(expectedHmac, "utf8");

  if (
    receivedBuffer.length !== expectedBuffer.length ||
    !crypto.timingSafeEqual(receivedBuffer, expectedBuffer)
  ) {
    return res.status(401).json({
      success: false,
      error: "Signature Shopify invalide.",
    });
  }

  return next();
}

function shouldDisableUnifiTlsVerification(siteConfig = null) {
  if (typeof siteConfig?.verify_ssl === "boolean") {
    return !siteConfig.verify_ssl;
  }

  const verifySetting = String(process.env.UNIFI_VERIFY_SSL || "")
    .trim()
    .toLowerCase();

  if (PILOT_SECURITY_ENABLED) {
    return (
      verifySetting === "false" &&
      parseBoolean(process.env.UNIFI_ALLOW_INSECURE_TLS_FOR_PILOT)
    );
  }

  return verifySetting !== "true";
}

function normalizeBVCode(code) {
  return String(code || "").trim().toUpperCase();
}

function normalizePhone(phone) {
  return String(phone || "").replace(/[^\d+]/g, "").trim();
}

function normalizeMac(mac) {
  const cleaned = String(mac || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-f0-9]/g, "");

  if (cleaned.length !== 12) return null;

  return cleaned.match(/.{1,2}/g).join(":");
}

function normalizeSiteCode(siteCode) {
  return String(siteCode || "")
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "");
}

function getUnifiSiteName(siteConfig = null) {
  return String(
    siteConfig?.unifi_site ||
      siteConfig?.unifi_site_name ||
      process.env.UNIFI_SITE ||
      process.env.UNIFI_SITE_NAME ||
      "default"
  )
    .trim()
    .replace(/^\/+|\/+$/g, "") || "default";
}

function getUnifiBaseUrl(siteConfig = null) {
  return String(
    siteConfig?.unifi_host ||
      siteConfig?.base_url ||
      siteConfig?.host ||
      process.env.UNIFI_BASE_URL ||
      process.env.UNIFI_HOST ||
      "https://192.168.1.1"
  ).trim().replace(/\/+$/g, "");
}

function getUnifiUsername(siteConfig = null) {
  return (
    siteConfig?.unifi_username ||
    siteConfig?.username ||
    process.env.UNIFI_USERNAME ||
    process.env.UNIFI_USER ||
    ""
  );
}

function getUnifiPassword(siteConfig = null) {
  return (
    siteConfig?.unifi_password ||
    siteConfig?.password ||
    process.env.UNIFI_PASSWORD ||
    process.env.UNIFI_PASS ||
    ""
  );
}

function getUnifiConfigKey(siteConfig = null) {
  return [
    normalizeSiteCode(siteConfig?.site_code || "ENV"),
    getUnifiBaseUrl(siteConfig),
    getUnifiSiteName(siteConfig),
  ].join("|");
}

const unifiAuthCache = new Map();
const unifiAuthRateLimitCache = new Map();

function getUnifiAuthCacheKey(siteConfig = null) {
  return [
    getUnifiBaseUrl(siteConfig),
    getUnifiUsername(siteConfig) || "anonymous",
  ].join("|");
}

function getUnifiAuthCacheTtlMs() {
  const configured = Number(
    process.env.BV_UNIFI_AUTH_CACHE_TTL_MS ||
      process.env.UNIFI_AUTH_CACHE_TTL_MS ||
      15 * 60 * 1000
  );

  return Math.max(60 * 1000, configured || 15 * 60 * 1000);
}

function getUnifiAuthRefreshSkewMs() {
  const configured = Number(
    process.env.BV_UNIFI_AUTH_REFRESH_SKEW_MS ||
      process.env.UNIFI_AUTH_REFRESH_SKEW_MS ||
      60 * 1000
  );

  return Math.max(10 * 1000, configured || 60 * 1000);
}

function getUnifiAuthRateLimitCooldownMs() {
  const configured = Number(
    process.env.BV_UNIFI_AUTH_RATE_LIMIT_COOLDOWN_MS ||
      process.env.UNIFI_AUTH_RATE_LIMIT_COOLDOWN_MS ||
      15 * 60 * 1000
  );

  return Math.max(60 * 1000, configured || 15 * 60 * 1000);
}

function getUnifiAuthRateLimitMinCooldownMs() {
  const configured = Number(
    process.env.BV_UNIFI_AUTH_RATE_LIMIT_COOLDOWN_MIN_MS ||
      process.env.UNIFI_AUTH_RATE_LIMIT_COOLDOWN_MIN_MS ||
      5 * 60 * 1000
  );

  return Math.max(30 * 1000, configured || 5 * 60 * 1000);
}

function parseRetryAfterMs(response) {
  const retryAfter = response?.headers?.get?.("retry-after");
  if (!retryAfter) return null;

  const retryAfterSeconds = Number(retryAfter);
  if (Number.isFinite(retryAfterSeconds) && retryAfterSeconds > 0) {
    return retryAfterSeconds * 1000;
  }

  const retryAfterDateMs = new Date(retryAfter).getTime();
  if (Number.isFinite(retryAfterDateMs)) {
    return Math.max(0, retryAfterDateMs - Date.now());
  }

  return null;
}

function isUnifiAuthRateLimitResponse(status, text = "") {
  const lowerText = String(text || "").toLowerCase();
  return (
    Number(status) === 429 ||
    lowerText.includes("authentication_failed_limit_reached") ||
    lowerText.includes("login attempt limit")
  );
}

function createUnifiAuthRateLimitError(code, siteConfig, details = {}) {
  const retryAfterMs = Math.max(0, Number(details.retryAfterMs || 0));
  const error = new Error(
    code === "UNIFI_AUTH_COOLDOWN_ACTIVE"
      ? `UniFi authentication cooldown active. Retry after ${retryAfterMs} ms.`
      : `UniFi authentication rate limited. Retry after ${retryAfterMs} ms.`
  );

  error.name = "UniFiAuthRateLimitError";
  error.code = code;
  error.status = 429;
  error.retry_after_ms = retryAfterMs;
  error.retry_after_seconds = Math.ceil(retryAfterMs / 1000);
  error.unifi_rate_limited = true;
  error.site_code = siteConfig?.site_code || null;
  error.controller_name = siteConfig?.controller_name || null;
  error.unifi_host = getUnifiBaseUrl(siteConfig);
  error.unifi_response_preview = details.responsePreview || null;

  return error;
}

function isUniFiAuthRateLimitError(error) {
  const message = String(error?.message || "").toLowerCase();
  return (
    error?.unifi_rate_limited === true ||
    error?.code === "UNIFI_AUTH_RATE_LIMITED" ||
    error?.code === "UNIFI_AUTH_COOLDOWN_ACTIVE" ||
    Number(error?.status) === 429 ||
    message.includes("authentication_failed_limit_reached") ||
    message.includes("login attempt limit") ||
    message.includes("uniFi authentication cooldown active".toLowerCase())
  );
}

function getActiveUnifiAuthRateLimit(siteConfig = null) {
  const cacheKey = getUnifiAuthCacheKey(siteConfig);
  const cooldown = unifiAuthRateLimitCache.get(cacheKey);

  if (!cooldown) return null;

  const retryAfterMs = cooldown.untilMs - Date.now();

  if (retryAfterMs <= 0) {
    unifiAuthRateLimitCache.delete(cacheKey);
    return null;
  }

  return {
    ...cooldown,
    retryAfterMs,
    retryAfterSeconds: Math.ceil(retryAfterMs / 1000),
  };
}

function storeUnifiAuthRateLimit(siteConfig = null, response, responseText = "") {
  const retryAfterMs = Math.max(
    getUnifiAuthRateLimitMinCooldownMs(),
    parseRetryAfterMs(response) || getUnifiAuthRateLimitCooldownMs()
  );
  const untilMs = Date.now() + retryAfterMs;
  const cooldown = {
    baseUrl: getUnifiBaseUrl(siteConfig),
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    status: response?.status || 429,
    responsePreview: String(responseText || "").slice(0, 500),
    startedAt: new Date().toISOString(),
    untilAt: new Date(untilMs).toISOString(),
    untilMs,
  };

  unifiAuthRateLimitCache.set(getUnifiAuthCacheKey(siteConfig), cooldown);

  console.warn("UNIFI AUTH RATE LIMITED", {
    baseUrl: cooldown.baseUrl,
    site_code: cooldown.site_code,
    controller_name: cooldown.controller_name,
    status: cooldown.status,
    retry_after_ms: retryAfterMs,
    retry_after_seconds: Math.ceil(retryAfterMs / 1000),
    cooldown_until: cooldown.untilAt,
    response_preview: cooldown.responsePreview,
  });

  return {
    ...cooldown,
    retryAfterMs,
    retryAfterSeconds: Math.ceil(retryAfterMs / 1000),
  };
}

function getCachedUnifiAuthSession(siteConfig = null) {
  const cacheKey = getUnifiAuthCacheKey(siteConfig);
  const cached = unifiAuthCache.get(cacheKey);

  if (!cached) return null;

  const refreshAtMs = cached.expiresAtMs - getUnifiAuthRefreshSkewMs();

  if (refreshAtMs <= Date.now()) {
    unifiAuthCache.delete(cacheKey);
    console.log("UNIFI LOGIN CACHE EXPIRED", {
      baseUrl: getUnifiBaseUrl(siteConfig),
      site_code: siteConfig?.site_code || null,
      controller_name: siteConfig?.controller_name || null,
      cached_at: cached.cachedAt,
      expires_at: cached.expiresAt,
    });
    return null;
  }

  console.log("UNIFI LOGIN CACHE HIT", {
    baseUrl: cached.baseUrl,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    expires_at: cached.expiresAt,
  });

  return {
    baseUrl: cached.baseUrl,
    cookie: cached.cookie,
    csrfToken: cached.csrfToken,
  };
}

function storeUnifiAuthSession(siteConfig = null, session) {
  const cacheKey = getUnifiAuthCacheKey(siteConfig);
  unifiAuthCache.set(cacheKey, session);
  unifiAuthRateLimitCache.delete(cacheKey);

  console.log("UNIFI LOGIN CACHE STORE", {
    baseUrl: session.baseUrl,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    cached_at: session.cachedAt,
    expires_at: session.expiresAt,
  });
}

function clearUnifiAuthCache(siteConfig = null, reason = "manual") {
  const cacheKey = getUnifiAuthCacheKey(siteConfig);
  const deleted = unifiAuthCache.delete(cacheKey);

  console.log("UNIFI LOGIN CACHE CLEAR", {
    baseUrl: getUnifiBaseUrl(siteConfig),
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    reason,
    deleted,
  });
}

function buildRequestId(prefix = "req") {
  return `${prefix}_${Date.now()}_${crypto.randomBytes(4).toString("hex")}`;
}

function getMacCandidatesFromRequest(req) {
  const body = req.body || {};
  const query = req.query || {};
  const portalParams = body.portal_params || {};
  const portalDebugQuery = body.portal_debug?.query || {};
  const cookies = parseCookieHeader(req.headers.cookie || "");

  return [
    { source: "body.mac_address", value: body.mac_address },
    { source: "body.mac", value: body.mac },
    { source: "body.client_mac", value: body.client_mac },
    { source: "body.sta", value: body.sta },
    { source: "body.id", value: body.id },
    { source: "body.client_id", value: body.client_id },
    { source: "body.clientId", value: body.clientId },
    { source: "body.client", value: body.client },
    { source: "body.station", value: body.station },
    { source: "body.station_mac", value: body.station_mac },
    { source: "body.device_mac", value: body.device_mac },
    { source: "body.user_mac", value: body.user_mac },
    { source: "query.id", value: query.id },
    { source: "query.mac", value: query.mac },
    { source: "query.client_mac", value: query.client_mac },
    { source: "query.sta", value: query.sta },
    { source: "query.client_id", value: query.client_id },
    { source: "query.clientId", value: query.clientId },
    { source: "query.client", value: query.client },
    { source: "query.station", value: query.station },
    { source: "query.station_mac", value: query.station_mac },
    { source: "query.device_mac", value: query.device_mac },
    { source: "query.user_mac", value: query.user_mac },
    { source: "portal_params.id", value: portalParams.id },
    { source: "portal_params.mac", value: portalParams.mac },
    { source: "portal_params.client_mac", value: portalParams.client_mac },
    { source: "portal_params.sta", value: portalParams.sta },
    { source: "portal_params.client_id", value: portalParams.client_id },
    { source: "portal_params.clientId", value: portalParams.clientId },
    { source: "portal_params.client", value: portalParams.client },
    { source: "portal_params.station", value: portalParams.station },
    { source: "portal_params.station_mac", value: portalParams.station_mac },
    { source: "portal_params.device_mac", value: portalParams.device_mac },
    { source: "portal_params.user_mac", value: portalParams.user_mac },
    { source: "portal_debug.query.id", value: portalDebugQuery.id },
    { source: "portal_debug.query.mac", value: portalDebugQuery.mac },
    { source: "portal_debug.query.client_mac", value: portalDebugQuery.client_mac },
    { source: "portal_debug.query.sta", value: portalDebugQuery.sta },
    { source: "cookie.mac", value: cookies.mac },
    { source: "cookie.client_mac", value: cookies.client_mac },
    { source: "cookie.sta", value: cookies.sta },
    { source: "header.x-client-mac", value: req.headers["x-client-mac"] },
    { source: "header.x-unifi-client-mac", value: req.headers["x-unifi-client-mac"] },
    { source: "header.x-sta-mac", value: req.headers["x-sta-mac"] },
    { source: "header.x-device-mac", value: req.headers["x-device-mac"] },
  ].map((candidate) => ({
    ...candidate,
    raw: candidate.value || null,
    normalized: normalizeMac(candidate.value),
  }));
}

function firstMacCandidate(req) {
  return getMacCandidatesFromRequest(req).find((candidate) => candidate.normalized);
}

function parseCookieHeader(cookieHeader) {
  return String(cookieHeader || "")
    .split(";")
    .map((part) => part.trim())
    .filter(Boolean)
    .reduce((cookies, part) => {
      const separatorIndex = part.indexOf("=");
      if (separatorIndex <= 0) return cookies;

      const key = part.slice(0, separatorIndex).trim();
      const value = part.slice(separatorIndex + 1).trim();

      try {
        cookies[key] = decodeURIComponent(value);
      } catch {
        cookies[key] = value;
      }

      return cookies;
    }, {});
}

function sanitizeHeadersForLog(headers = {}) {
  return Object.fromEntries(
    Object.entries(headers || {}).map(([key, value]) => {
      const lowerKey = String(key).toLowerCase();
      if (
        lowerKey.includes("authorization") ||
        lowerKey.includes("cookie") ||
        lowerKey.includes("token") ||
        lowerKey.includes("key")
      ) {
        return [key, value ? "[redacted]" : value];
      }

      return [key, value];
    })
  );
}

function sanitizeCookiesForLog(cookies = {}) {
  return Object.fromEntries(
    Object.entries(cookies || {}).map(([key, value]) => [
      key,
      String(value || "").length > 80
        ? `${String(value).slice(0, 20)}...[redacted]`
        : value,
    ])
  );
}

function normalizeIpAddress(value) {
  const raw = String(value || "").trim();
  if (!raw) return null;

  const firstValue = raw.split(",")[0].trim();
  const unwrapped = firstValue
    .replace(/^::ffff:/i, "")
    .replace(/^\[/, "")
    .replace(/\]$/, "");
  const withoutPort = unwrapped.includes(":") && /^\d+\.\d+\.\d+\.\d+:\d+$/.test(unwrapped)
    ? unwrapped.replace(/:\d+$/, "")
    : unwrapped;

  if (
    !withoutPort ||
    withoutPort === "::1" ||
    withoutPort === "127.0.0.1" ||
    withoutPort === "localhost"
  ) {
    return null;
  }

  return withoutPort;
}

function getIpCandidatesFromRequest(req) {
  const body = req.body || {};
  const query = req.query || {};
  const portalParams = body.portal_params || {};

  return [
    { source: "req.ip", value: req.ip },
    { source: "socket.remoteAddress", value: req.socket?.remoteAddress },
    { source: "header.x-forwarded-for", value: req.headers["x-forwarded-for"] },
    { source: "header.x-real-ip", value: req.headers["x-real-ip"] },
    { source: "body.ip_address", value: body.ip_address },
    { source: "body.client_ip", value: body.client_ip },
    { source: "query.ip", value: query.ip },
    { source: "query.client_ip", value: query.client_ip },
    { source: "portal_params.ip", value: portalParams.ip },
    { source: "portal_params.client_ip", value: portalParams.client_ip },
  ].map((candidate) => ({
    ...candidate,
    raw: candidate.value || null,
    normalized: normalizeIpAddress(candidate.value),
  }));
}

function buildRequestDebugPayload(req) {
  const cookies = parseCookieHeader(req.headers.cookie || "");

  return {
    method: req.method,
    path: req.originalUrl,
    ip: req.ip,
    socket_remote_address: req.socket?.remoteAddress || null,
    query: req.query || {},
    body: req.body || {},
    headers: sanitizeHeadersForLog(req.headers || {}),
    cookies: sanitizeCookiesForLog(cookies),
    ip_candidates: getIpCandidatesFromRequest(req),
    mac_candidates: getMacCandidatesFromRequest(req),
  };
}

function maskCodeForLog(code) {
  const normalized = normalizeBVCode(code);
  if (!normalized) return "";
  return normalized.length <= 4
    ? normalized
    : `${normalized.slice(0, 4)}...${normalized.slice(-2)}`;
}

function bvDebug(label, details = {}) {
  console.log("=== BV ACCESS DEBUG ===", label, details);
}

function logDiagnosticError(label, error) {
  console.error("=== BV ACCESS DEBUG ===", label, {
    name: error?.name,
    message: error?.message,
    code: error?.code,
    status: error?.status,
    retry_after_ms: error?.retry_after_ms,
    retry_after_seconds: error?.retry_after_seconds,
    unifi_rate_limited: error?.unifi_rate_limited,
    stack: error?.stack,
    cause_name: error?.cause?.name,
    cause_message: error?.cause?.message,
    cause_code: error?.cause?.code,
    cause_errno: error?.cause?.errno,
    cause_address: error?.cause?.address,
    cause_port: error?.cause?.port,
    cause_stack: error?.cause?.stack,
  });
}

function diagnosticErrorPayload(error) {
  return {
    name: error?.name || null,
    message: error?.message || null,
    code: error?.code || null,
    status: error?.status || null,
    retry_after_ms: error?.retry_after_ms || null,
    retry_after_seconds: error?.retry_after_seconds || null,
    unifi_rate_limited: error?.unifi_rate_limited || false,
    cause_name: error?.cause?.name || null,
    cause_message: error?.cause?.message || null,
    cause_code: error?.cause?.code || null,
    cause_errno: error?.cause?.errno || null,
    cause_address: error?.cause?.address || null,
    cause_port: error?.cause?.port || null,
  };
}

function userFacingUniFiError(error) {
  if (isUniFiAuthRateLimitError(error)) {
    const retryAfterSeconds = Number(error?.retry_after_seconds || 0);
    return retryAfterSeconds > 0
      ? `UniFi bloque temporairement les connexions API. Réessayez dans environ ${retryAfterSeconds} secondes.`
      : "UniFi bloque temporairement les connexions API. Réessayez après le cooldown du contrôleur.";
  }

  const causeCode = error?.cause?.code || error?.code || "";

  if (["ENETUNREACH", "EHOSTUNREACH", "ECONNREFUSED", "ETIMEDOUT"].includes(causeCode)) {
    return "Le serveur B&V Access ne peut pas joindre le contrôleur UniFi local.";
  }

  if (String(error?.message || "").toLowerCase().includes("fetch failed")) {
    return "L'appel vers UniFi a échoué.";
  }

  return error?.message || "Erreur UniFi inconnue.";
}

function isUnifiRequired() {
  return (
    String(process.env.UNIFI_REQUIRED || "").toLowerCase() === "true" ||
    String(process.env.UNIFI_STRICT || "").toLowerCase() === "true"
  );
}

function isUnifiEnabled() {
  const explicitSetting =
    process.env.UNIFI_ENABLED ?? process.env.UNIFI_BRIDGE_ENABLED;

  if (explicitSetting !== undefined) {
    return parseBoolean(explicitSetting);
  }

  return isUnifiRequired();
}

function buildUnifiFailureResult(error, action, mac, payload = null) {
  return {
    success: false,
    action,
    mac: normalizeMac(mac),
    payload,
    non_blocking: !isUnifiRequired(),
    error: userFacingUniFiError(error),
    diagnostic: diagnosticErrorPayload(error),
  };
}

const unifiSiteConfigCache = new Map();

function normalizeUnifiSiteConfig(row, requestedSiteCode = null) {
  const siteCode = normalizeSiteCode(
    row?.site_code || requestedSiteCode || process.env.BV_DEFAULT_SITE_CODE || DEFAULT_SITE_CODE
  );

  return {
    id: row?.id || null,
    site_code: siteCode,
    display_name: row?.display_name || row?.name || siteCode,
    controller_name: row?.controller_name || row?.display_name || siteCode,
    unifi_host: getUnifiBaseUrl(row),
    unifi_site: getUnifiSiteName(row),
    unifi_username: getUnifiUsername(row),
    unifi_password: getUnifiPassword(row),
    verify_ssl:
      typeof row?.verify_ssl === "boolean"
        ? row.verify_ssl
        : String(process.env.UNIFI_VERIFY_SSL || "").toLowerCase() === "true",
    vpn_type: row?.vpn_type || null,
    vpn_address: row?.vpn_address || null,
    regional_node_code:
      normalizeSiteCode(row?.regional_node_code || row?.node_code || "") ||
      REGIONAL_NODE_CODE,
    portal_host:
      row?.portal_host ||
      row?.external_portal_host ||
      row?.portal_ip_for_site ||
      null,
    portal_port: Number(row?.portal_port || row?.external_portal_port || 0) || null,
    guest_subnet: row?.guest_subnet || row?.guest_subnets || null,
    management_subnet: row?.management_subnet || row?.management_subnets || null,
    active: row?.active !== false,
    source: row?.source || "supabase",
  };
}

function getDefaultUnifiSiteConfig(siteCode = null) {
  return normalizeUnifiSiteConfig(
    {
      site_code:
        normalizeSiteCode(siteCode) ||
        normalizeSiteCode(process.env.BV_DEFAULT_SITE_CODE) ||
        DEFAULT_SITE_CODE,
      display_name: "Default UniFi controller",
      controller_name: "default-env-controller",
      unifi_host: process.env.UNIFI_BASE_URL || process.env.UNIFI_HOST,
      unifi_site: process.env.UNIFI_SITE || process.env.UNIFI_SITE_NAME || "default",
      unifi_username: process.env.UNIFI_USERNAME || process.env.UNIFI_USER,
      unifi_password: process.env.UNIFI_PASSWORD || process.env.UNIFI_PASS,
      verify_ssl: String(process.env.UNIFI_VERIFY_SSL || "").toLowerCase() === "true",
      vpn_type: "env_fallback",
      regional_node_code: REGIONAL_NODE_CODE,
      portal_host:
        process.env.BV_EXTERNAL_PORTAL_HOST ||
        process.env.UNIFI_EXTERNAL_PORTAL_HOST ||
        null,
      portal_port:
        Number(
          process.env.BV_EXTERNAL_PORTAL_PORT ||
            process.env.UNIFI_EXTERNAL_PORTAL_PORT ||
            0
        ) || null,
      guest_subnet: process.env.BV_DEFAULT_GUEST_SUBNET || null,
      management_subnet: process.env.BV_DEFAULT_MANAGEMENT_SUBNET || null,
      active: true,
      source: "env_fallback",
    },
    siteCode
  );
}

function isMissingUnifiSitesTableError(error) {
  const message = String(error?.message || "").toLowerCase();
  return (
    error?.code === "42P01" ||
    error?.code === "PGRST205" ||
    message.includes("unifi_sites") && message.includes("does not exist") ||
    message.includes("could not find the table")
  );
}

function getUnifiConfigCacheTtlMs() {
  const configured = Number(
    process.env.BV_UNIFI_SITE_CONFIG_CACHE_MS ||
      process.env.UNIFI_SITE_CONFIG_CACHE_MS ||
      60000
  );

  return Math.max(5000, configured || 60000);
}

async function getUnifiSiteConfig(siteCode = null, options = {}) {
  const normalizedSiteCode =
    normalizeSiteCode(siteCode) ||
    normalizeSiteCode(process.env.BV_DEFAULT_SITE_CODE) ||
    DEFAULT_SITE_CODE;
  const nowMs = Date.now();
  const cacheKey = normalizedSiteCode;
  const cached = unifiSiteConfigCache.get(cacheKey);

  if (!options.noCache && cached && nowMs - cached.cachedAt < getUnifiConfigCacheTtlMs()) {
    return cached.config;
  }

  let config = null;

  try {
    const { data, error } = await supabase
      .from("unifi_sites")
      .select("*")
      .eq("site_code", normalizedSiteCode)
      .eq("active", true)
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (data) {
      config = normalizeUnifiSiteConfig(data, normalizedSiteCode);
    }
  } catch (error) {
    if (isMissingUnifiSitesTableError(error)) {
      console.log("UNIFI SITE CONFIG FALLBACK: unifi_sites table unavailable", {
        site_code: normalizedSiteCode,
        reason: error.message,
      });
    } else {
      logDiagnosticError("UNIFI SITE CONFIG LOOKUP ERROR", error);
      if (options.strict) throw error;
    }
  }

  if (!config) {
    config = getDefaultUnifiSiteConfig(normalizedSiteCode);
  }

  unifiSiteConfigCache.set(cacheKey, {
    cachedAt: nowMs,
    config,
  });

  console.log("UNIFI SITE CONFIG RESOLVED", {
    site_code: normalizedSiteCode,
    source: config.source,
    controller_name: config.controller_name,
    unifi_host: config.unifi_host,
    unifi_site: config.unifi_site,
    username_present: Boolean(config.unifi_username),
    password_present: Boolean(config.unifi_password),
    verify_ssl: config.verify_ssl,
  });

  return config;
}

function ipToNumber(ipAddress) {
  const parts = String(ipAddress || "").split(".").map((part) => Number(part));

  if (
    parts.length !== 4 ||
    parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)
  ) {
    return null;
  }

  return (
    ((parts[0] << 24) >>> 0) +
    ((parts[1] << 16) >>> 0) +
    ((parts[2] << 8) >>> 0) +
    parts[3]
  ) >>> 0;
}

function isIpInCidr(ipAddress, cidr) {
  const [networkAddress, prefixValue] = String(cidr || "").trim().split("/");
  const prefix = Number(prefixValue);
  const ip = ipToNumber(ipAddress);
  const network = ipToNumber(networkAddress);

  if (
    ip === null ||
    network === null ||
    !Number.isInteger(prefix) ||
    prefix < 0 ||
    prefix > 32
  ) {
    return false;
  }

  if (prefix === 0) return true;

  const mask = (0xffffffff << (32 - prefix)) >>> 0;
  return (ip & mask) === (network & mask);
}

function getSiteSubnetsFromConfig(siteConfig = {}) {
  const rawValues = [
    siteConfig.guest_subnet,
    siteConfig.guest_subnets,
    siteConfig.portal_client_subnet,
    siteConfig.portal_client_subnets,
    siteConfig.client_subnet,
    siteConfig.client_subnets,
    siteConfig.management_subnet,
    siteConfig.management_subnets,
  ];

  return rawValues
    .flatMap((value) => {
      if (Array.isArray(value)) return value;
      if (value && typeof value === "object") return Object.values(value);
      return String(value || "").split(",");
    })
    .map((value) => String(value || "").trim())
    .filter((value) => /^\d+\.\d+\.\d+\.\d+\/\d+$/.test(value));
}

async function listRegionalUnifiSiteConfigs(options = {}) {
  const cacheKey = "__regional_sites__";
  const nowMs = Date.now();
  const cached = unifiSiteConfigCache.get(cacheKey);

  if (!options.noCache && cached && nowMs - cached.cachedAt < getUnifiConfigCacheTtlMs()) {
    return cached.configs;
  }

  let configs = [];

  try {
    let query = supabase
      .from("unifi_sites")
      .select("*")
      .eq("active", true)
      .order("site_code", { ascending: true });

    const { data, error } = await query;

    if (error) throw error;

    configs = (data || [])
      .filter((row) => {
        const nodeCode = normalizeSiteCode(row.regional_node_code || row.node_code || "");
        return !nodeCode || nodeCode === REGIONAL_NODE_CODE;
      })
      .map((row) => normalizeUnifiSiteConfig(row, row.site_code));
  } catch (error) {
    if (isMissingUnifiSitesTableError(error)) {
      console.log("REGIONAL NODE SITE LIST FALLBACK: unifi_sites table unavailable", {
        regional_node_code: REGIONAL_NODE_CODE,
        reason: error.message,
      });
    } else {
      logDiagnosticError("REGIONAL NODE SITE LIST ERROR", error);
      if (options.strict) throw error;
    }
  }

  if (configs.length === 0) {
    configs = [getDefaultUnifiSiteConfig(DEFAULT_SITE_CODE)];
  }

  unifiSiteConfigCache.set(cacheKey, {
    cachedAt: nowMs,
    configs,
  });

  return configs;
}

async function resolveRegionalSiteContext(req, requestedSiteCode = null, options = {}) {
  const explicitSiteCode = normalizeSiteCode(
    requestedSiteCode ||
      req?.query?.site_code ||
      req?.query?.siteCode ||
      req?.body?.site_code ||
      req?.body?.siteCode ||
      req?.body?.portal_debug?.query?.site_code ||
      req?.body?.portal_debug?.query?.siteCode ||
      ""
  );

  if (explicitSiteCode) {
    const siteConfig = await getUnifiSiteConfig(explicitSiteCode, options);
    return {
      site_code: siteConfig.site_code,
      source: "explicit_site_code",
      regional_node_code: REGIONAL_NODE_CODE,
      client_ip: null,
      site_config: siteConfig,
    };
  }

  const ipCandidates = getIpCandidatesFromRequest(req)
    .map((candidate) => candidate.normalized)
    .filter(Boolean)
    .filter((ip, index, all) => all.indexOf(ip) === index);
  const siteConfigs = await listRegionalUnifiSiteConfigs(options);

  for (const ipAddress of ipCandidates) {
    for (const siteConfig of siteConfigs) {
      const subnets = getSiteSubnetsFromConfig(siteConfig);

      if (subnets.some((cidr) => isIpInCidr(ipAddress, cidr))) {
        return {
          site_code: siteConfig.site_code,
          source: "client_ip_subnet",
          regional_node_code: REGIONAL_NODE_CODE,
          client_ip: ipAddress,
          matched_subnets: subnets,
          site_config: siteConfig,
        };
      }
    }
  }

  const fallbackConfig = await getUnifiSiteConfig(DEFAULT_SITE_CODE, options);

  return {
    site_code: fallbackConfig.site_code,
    source: "default_site_fallback",
    regional_node_code: REGIONAL_NODE_CODE,
    client_ip: ipCandidates[0] || null,
    site_config: fallbackConfig,
  };
}

function normalizePlanCode(planCode) {
  return String(planCode || "").trim().toUpperCase();
}

function getBillingModeForPlan(planCode) {
  const normalizedPlanCode = normalizePlanCode(planCode);
  if (FIXED_WINDOW_PLAN_CODES.has(normalizedPlanCode)) return "fixed_window";
  if (CONNECTED_USAGE_PLAN_CODES.has(normalizedPlanCode)) return "connected_usage";
  return "connected_usage";
}

function getPlanCodeFromSession(session, fallbackVoucher = null) {
  return normalizePlanCode(
    session?.plan_code ||
      fallbackVoucher?.plan_code ||
      fallbackVoucher?.plan ||
      fallbackVoucher?.product_code ||
      ""
  );
}

function getSessionBillingMode(session, fallbackVoucher = null) {
  const explicitMode = String(session?.billing_mode || "").trim();
  if (explicitMode === "fixed_window" || explicitMode === "connected_usage") {
    return explicitMode;
  }

  return getBillingModeForPlan(getPlanCodeFromSession(session, fallbackVoucher));
}

function getConnectedUsageGraceMs() {
  const configured = Number(
    process.env.BV_CLIENT_DISCONNECT_GRACE_SECONDS ||
      process.env.UNIFI_CLIENT_GRACE_SECONDS ||
      90
  );

  return Math.max(30, configured || 90) * 1000;
}

function getSessionPresencePollMs() {
  const configured = Number(
    process.env.BV_SESSION_PRESENCE_POLL_MS ||
      process.env.SESSION_PRESENCE_POLL_MS ||
      30000
  );

  return Math.max(15000, configured || 30000);
}

function getSessionWorkerBatchSize() {
  const configured = Number(
    process.env.BV_SESSION_WORKER_BATCH_SIZE ||
      process.env.SESSION_WORKER_BATCH_SIZE ||
      1000
  );

  return Math.max(100, Math.min(5000, configured || 1000));
}

function getCapacityThresholds() {
  return {
    workerDurationWarnMs: Number(process.env.BV_WORKER_DURATION_WARN_MS || 20000),
    workerDurationCriticalMs: Number(process.env.BV_WORKER_DURATION_CRITICAL_MS || 28000),
    memoryWarnRatio: Number(process.env.BV_MEMORY_WARN_RATIO || 0.7),
    memoryCriticalRatio: Number(process.env.BV_MEMORY_CRITICAL_RATIO || 0.85),
    activeSessionsWarn: Number(process.env.BV_ACTIVE_SESSIONS_WARN || 10000),
    activeSessionsCritical: Number(process.env.BV_ACTIVE_SESSIONS_CRITICAL || 25000),
    sitesWarn: Number(process.env.BV_SITES_WARN || 250),
    sitesCritical: Number(process.env.BV_SITES_CRITICAL || 500),
    unifiResponseWarnMs: Number(process.env.BV_UNIFI_RESPONSE_WARN_MS || 5000),
    unifiResponseCriticalMs: Number(process.env.BV_UNIFI_RESPONSE_CRITICAL_MS || 10000),
  };
}

function getSystemCapacitySnapshot() {
  const memory = process.memoryUsage();
  const totalMemory = os.totalmem();
  const freeMemory = os.freemem();
  const usedSystemMemory = Math.max(0, totalMemory - freeMemory);

  return {
    timestamp: new Date().toISOString(),
    platform: os.platform(),
    arch: os.arch(),
    cpus: os.cpus().length,
    loadavg: os.loadavg?.() || [0, 0, 0],
    process_memory: {
      rss: memory.rss,
      heap_total: memory.heapTotal,
      heap_used: memory.heapUsed,
      external: memory.external,
      array_buffers: memory.arrayBuffers,
    },
    system_memory: {
      total: totalMemory,
      free: freeMemory,
      used: usedSystemMemory,
      used_ratio: totalMemory ? usedSystemMemory / totalMemory : null,
    },
    uptime_seconds: Math.floor(process.uptime()),
  };
}

function buildCapacityWarnings(metrics) {
  const thresholds = getCapacityThresholds();
  const warnings = [];
  const memoryRatio = metrics?.system?.system_memory?.used_ratio;
  const maxUnifiResponseMs = Math.max(
    0,
    ...Object.values(metrics?.sites || {}).map((site) => site.unifi_response_ms || 0)
  );

  if (metrics.duration_ms >= thresholds.workerDurationCriticalMs) {
    warnings.push({
      level: "critical",
      code: "worker_duration_critical",
      message: "Le cycle worker approche ou dépasse la fréquence de polling.",
      value: metrics.duration_ms,
      threshold: thresholds.workerDurationCriticalMs,
    });
  } else if (metrics.duration_ms >= thresholds.workerDurationWarnMs) {
    warnings.push({
      level: "warning",
      code: "worker_duration_warning",
      message: "Le cycle worker devient long; surveiller avant d'ajouter beaucoup de sites.",
      value: metrics.duration_ms,
      threshold: thresholds.workerDurationWarnMs,
    });
  }

  if (memoryRatio !== null && memoryRatio >= thresholds.memoryCriticalRatio) {
    warnings.push({
      level: "critical",
      code: "memory_critical",
      message: "La mémoire du mini-PC approche une zone critique.",
      value: memoryRatio,
      threshold: thresholds.memoryCriticalRatio,
    });
  } else if (memoryRatio !== null && memoryRatio >= thresholds.memoryWarnRatio) {
    warnings.push({
      level: "warning",
      code: "memory_warning",
      message: "La mémoire du mini-PC doit être surveillée.",
      value: memoryRatio,
      threshold: thresholds.memoryWarnRatio,
    });
  }

  if (metrics.active_sessions >= thresholds.activeSessionsCritical) {
    warnings.push({
      level: "critical",
      code: "active_sessions_critical",
      message: "Nombre de sessions actives très élevé pour un seul worker.",
      value: metrics.active_sessions,
      threshold: thresholds.activeSessionsCritical,
    });
  } else if (metrics.active_sessions >= thresholds.activeSessionsWarn) {
    warnings.push({
      level: "warning",
      code: "active_sessions_warning",
      message: "Nombre de sessions actives élevé; surveiller la durée du worker.",
      value: metrics.active_sessions,
      threshold: thresholds.activeSessionsWarn,
    });
  }

  if (metrics.site_count >= thresholds.sitesCritical) {
    warnings.push({
      level: "critical",
      code: "sites_critical",
      message: "Nombre de sites très élevé pour un seul mini-PC central.",
      value: metrics.site_count,
      threshold: thresholds.sitesCritical,
    });
  } else if (metrics.site_count >= thresholds.sitesWarn) {
    warnings.push({
      level: "warning",
      code: "sites_warning",
      message: "Nombre de sites élevé; planifier monitoring et mini-PC secondaire possible.",
      value: metrics.site_count,
      threshold: thresholds.sitesWarn,
    });
  }

  if (maxUnifiResponseMs >= thresholds.unifiResponseCriticalMs) {
    warnings.push({
      level: "critical",
      code: "unifi_response_critical",
      message: "Un ou plusieurs contrôleurs UniFi répondent trop lentement.",
      value: maxUnifiResponseMs,
      threshold: thresholds.unifiResponseCriticalMs,
    });
  } else if (maxUnifiResponseMs >= thresholds.unifiResponseWarnMs) {
    warnings.push({
      level: "warning",
      code: "unifi_response_warning",
      message: "Latence UniFi élevée; vérifier VPN ou lien Internet du site.",
      value: maxUnifiResponseMs,
      threshold: thresholds.unifiResponseWarnMs,
    });
  }

  return warnings;
}

function getMaxAccountingDeltaSeconds() {
  const configured = Number(
    process.env.BV_SESSION_MAX_ACCOUNTING_DELTA_SECONDS ||
      process.env.SESSION_MAX_ACCOUNTING_DELTA_SECONDS ||
      90
  );

  return Math.max(30, configured || 90);
}

function parseDateMs(value) {
  if (!value) return null;
  const ms = new Date(value).getTime();
  return Number.isFinite(ms) ? ms : null;
}

function getNextPlanNuitExpiryIso(now = new Date()) {
  const expiryHour = Math.min(
    23,
    Math.max(0, Number(process.env.BV_PLAN_NUIT_EXPIRES_HOUR || 6) || 6)
  );
  const expiry = new Date(now);

  expiry.setHours(expiryHour, 0, 0, 0);
  if (expiry.getTime() <= now.getTime()) {
    expiry.setDate(expiry.getDate() + 1);
  }

  return expiry.toISOString();
}

function getVoucherPlanCode(voucher) {
  return normalizePlanCode(
    voucher?.plan_code ||
      voucher?.plan ||
      voucher?.product_code ||
      voucher?.plan_key ||
      ""
  );
}

function getVoucherBillingMode(voucher) {
  return getBillingModeForPlan(getVoucherPlanCode(voucher));
}

function buildVoucherSessionTiming(voucher, minutesRemaining, now = new Date()) {
  const billingMode = getVoucherBillingMode(voucher);
  const expiresAt = billingMode === "fixed_window"
    ? getNextPlanNuitExpiryIso(now)
    : null;
  const authorizeMinutes = expiresAt
    ? Math.max(1, Math.ceil((new Date(expiresAt).getTime() - now.getTime()) / 60000))
    : Math.max(1, Math.ceil(Number(minutesRemaining) || 1));

  return {
    billingMode,
    expiresAt,
    authorizeMinutes,
  };
}

function getSessionAuthorizedSeconds(session, fallbackVoucher = null) {
  const minutes =
    Number(session?.minutes_authorized || 0) ||
    Number(
      fallbackVoucher?.minutes_total ||
        fallbackVoucher?.minutes ||
        fallbackVoucher?.duration_minutes ||
        fallbackVoucher?.minutes_remaining ||
        0
    );

  return Math.max(0, Math.ceil(minutes * 60));
}

function getSessionConsumedSeconds(session, nowMs = Date.now()) {
  const explicitSeconds = Number(session?.seconds_consumed);
  if (Number.isFinite(explicitSeconds) && explicitSeconds >= 0) {
    return Math.floor(explicitSeconds);
  }

  const minutesConsumed = Number(session?.minutes_consumed);
  if (Number.isFinite(minutesConsumed) && minutesConsumed >= 0) {
    return Math.floor(minutesConsumed * 60);
  }

  const startedMs = getSessionStartMs(session);
  return Math.max(0, Math.floor((nowMs - startedMs) / 1000));
}

function stripSessionOptionalPayload(payload) {
  return Object.fromEntries(
    Object.entries(payload || {}).filter(([key]) => !SESSION_OPTIONAL_COLUMNS.has(key))
  );
}

async function safeUpdateAccessSession(sessionId, payload, options = {}) {
  if (!sessionId || !payload || Object.keys(payload).length === 0) {
    return { data: null, error: null, skipped: true };
  }

  let query = supabase.from("access_sessions").update(payload).eq("id", sessionId);

  if (options.status) {
    query = query.eq("status", options.status);
  }

  if (options.select !== false) {
    query = query.select(options.select || "*");
    query = options.single ? query.single() : query.maybeSingle();
  }

  let result = await query;

  if (!result.error || !isMissingColumnError(result.error)) {
    return result;
  }

  const fallbackPayload = stripSessionOptionalPayload(payload);

  console.log("ACCESS SESSION UPDATE FALLBACK: optional columns missing", {
    session_id: sessionId,
    missing_error: result.error.message,
    removed_fields: Object.keys(payload).filter((key) =>
      SESSION_OPTIONAL_COLUMNS.has(key)
    ),
  });

  if (Object.keys(fallbackPayload).length === 0) {
    return { data: null, error: null, skipped: true, missing_optional_columns: true };
  }

  query = supabase.from("access_sessions").update(fallbackPayload).eq("id", sessionId);

  if (options.status) {
    query = query.eq("status", options.status);
  }

  if (options.select !== false) {
    query = query.select(options.select || "*");
    query = options.single ? query.single() : query.maybeSingle();
  }

  return await query;
}

function errorSourceFromStep(step) {
  if (String(step || "").startsWith("supabase")) return "supabase";
  if (String(step || "").startsWith("unifi")) return "unifi";
  return "server";
}

function isMissingColumnError(error) {
  const message = String(error?.message || "").toLowerCase();
  return error?.code === "42703" || message.includes("does not exist");
}

async function fetchVoucherBySubmittedCode(code, logContext = "/validate-access") {
  const attempts = [];
  const fields = ["code", "access_code", "voucher_code"];

  for (const field of fields) {
    bvDebug(`${logContext} SUPABASE VOUCHER LOOKUP TRY`, {
      field,
      code: maskCodeForLog(code),
    });

    const { data, error } = await supabase
      .from("access_codes")
      .select("*")
      .eq(field, code)
      .limit(1)
      .maybeSingle();

    if (error) {
      attempts.push({
        field,
        success: false,
        code: error.code || null,
        message: error.message || null,
      });

      logDiagnosticError(
        `${logContext} SUPABASE VOUCHER LOOKUP ERROR field=${field}`,
        error
      );

      if (field === "code" || !isMissingColumnError(error)) {
        return { voucher: null, matchedField: null, attempts, error };
      }

      continue;
    }

    attempts.push({
      field,
      success: true,
      found: Boolean(data),
    });

    if (data) {
      return { voucher: data, matchedField: field, attempts, error: null };
    }
  }

  return { voucher: null, matchedField: null, attempts, error: null };
}

function getPortalBaseUrl(req = null) {
  const configured =
    process.env.BV_PORTAL_BASE_URL ||
    process.env.PUBLIC_PORTAL_BASE_URL ||
    process.env.PORTAL_BASE_URL ||
    process.env.APP_PUBLIC_URL ||
    process.env.RENDER_EXTERNAL_URL;

  if (configured) {
    return String(configured).trim().replace(/\/+$/g, "");
  }

  if (req?.get?.("host")) {
    const forwardedProto = String(req.headers["x-forwarded-proto"] || "")
      .split(",")[0]
      .trim();
    const protocol = forwardedProto || req.protocol || "http";

    return `${protocol}://${req.get("host")}`.replace(/\/+$/g, "");
  }

  return "https://bv-access-api.onrender.com";
}

function voucherPortalUrlForCode(code, req = null) {
  const portalUrl = new URL("/portal.html", `${getPortalBaseUrl(req)}/`);
  portalUrl.searchParams.set("code", normalizeBVCode(code));
  portalUrl.searchParams.set("qr", "1");

  return portalUrl.toString();
}

function qrCodeUrlForVoucher(code, req = null) {
  const portalUrl = voucherPortalUrlForCode(code, req);

  return `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(
    portalUrl
  )}`;
}

function buildVoucherQrPayload(code, req = null) {
  return {
    portal_url: voucherPortalUrlForCode(code, req),
    qr_code_url: qrCodeUrlForVoucher(code, req),
  };
}

function getVoucherCodeValue(record, fallback = "") {
  return normalizeBVCode(
    record?.code || record?.access_code || record?.voucher_code || fallback
  );
}

function decorateVoucherQr(record, req = null, fallbackCode = "") {
  const code = getVoucherCodeValue(record, fallbackCode);

  if (!code) {
    return {
      qr_code_url: null,
      portal_url: null,
    };
  }

  return buildVoucherQrPayload(code, req);
}

function decorateSaleWithVoucherQr(sale, vouchersByCode, req = null) {
  const code = normalizeBVCode(sale?.voucher_code || sale?.code || "");
  const voucher = vouchersByCode?.[code] || null;
  const qr = decorateVoucherQr(voucher, req, code);

  return {
    ...sale,
    qr_code_url: qr.qr_code_url,
    portal_url: qr.portal_url,
  };
}

function buildVouchersByCode(vouchers = []) {
  return (vouchers || []).reduce((map, voucher) => {
    const code = getVoucherCodeValue(voucher);

    if (code) {
      map[code] = voucher;
    }

    return map;
  }, {});
}

function generateAccessCode() {
  const firstPart = String(crypto.randomInt(0, 10000)).padStart(4, "0");
  const secondPart = String(crypto.randomInt(0, 10000)).padStart(4, "0");

  return `${firstPart}-${secondPart}`;
}

async function generateUniqueNationalCode() {
  for (let i = 0; i < 20; i++) {
    const code = generateAccessCode();

    const { data, error } = await supabase
      .from("access_codes")
      .select("id")
      .eq("code", code)
      .limit(1);

    if (error) throw error;

    if (!data || data.length === 0) {
      return code;
    }
  }

  throw new Error("Impossible de générer un code unique");
}

async function unifiLogin(siteConfig = null, options = {}) {
  const baseUrl = getUnifiBaseUrl(siteConfig);
  const username = getUnifiUsername(siteConfig);
  const password = getUnifiPassword(siteConfig);
  const forceRefresh = Boolean(options.forceRefresh);

  if (!username || !password) {
    throw new Error(
      `Identifiants UniFi manquants pour ${siteConfig?.site_code || "configuration .env"}`
    );
  }

  const insecureTlsEnabled = shouldDisableUnifiTlsVerification(siteConfig);
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = insecureTlsEnabled ? "0" : "1";

  if (!forceRefresh) {
    const cachedSession = getCachedUnifiAuthSession(siteConfig);
    if (cachedSession) return cachedSession;
  }

  const activeRateLimit = getActiveUnifiAuthRateLimit(siteConfig);
  if (activeRateLimit) {
    console.warn("UNIFI AUTH COOLDOWN ACTIVE", {
      baseUrl: activeRateLimit.baseUrl,
      site_code: activeRateLimit.site_code,
      controller_name: activeRateLimit.controller_name,
      retry_after_ms: activeRateLimit.retryAfterMs,
      retry_after_seconds: activeRateLimit.retryAfterSeconds,
      cooldown_until: activeRateLimit.untilAt,
    });

    throw createUnifiAuthRateLimitError(
      "UNIFI_AUTH_COOLDOWN_ACTIVE",
      siteConfig,
      {
        retryAfterMs: activeRateLimit.retryAfterMs,
        responsePreview: activeRateLimit.responsePreview,
      }
    );
  }

  if (forceRefresh) {
    clearUnifiAuthCache(siteConfig, "force_refresh");
  }

  bvDebug("unifiLogin() START", {
    baseUrl,
    loginUrl: `${baseUrl}/api/auth/login`,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    username_present: Boolean(username),
    password_present: Boolean(password),
    insecure_tls_enabled: insecureTlsEnabled,
  });

  console.log("UNIFI LOGIN START", {
    baseUrl,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    username_present: Boolean(username),
    password_present: Boolean(password),
  });

  let loginResponse;

  try {
    loginResponse = await fetch(`${baseUrl}/api/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Origin: baseUrl,
        Referer: `${baseUrl}/`,
      },
      body: JSON.stringify({
        username,
        password,
        rememberMe: true,
      }),
    });
  } catch (error) {
    logDiagnosticError("UNIFI LOGIN FETCH FAILED", error);
    throw error;
  }

  console.log("UNIFI LOGIN STATUS =", loginResponse.status);

  const rawSetCookie = loginResponse.headers.get("set-cookie");

  console.log("UNIFI LOGIN COOKIE RECEIVED =", Boolean(rawSetCookie));

  if (!loginResponse.ok || !rawSetCookie) {
    const text = await loginResponse.text();

    if (isUnifiAuthRateLimitResponse(loginResponse.status, text)) {
      const rateLimit = storeUnifiAuthRateLimit(siteConfig, loginResponse, text);
      throw createUnifiAuthRateLimitError(
        "UNIFI_AUTH_RATE_LIMITED",
        siteConfig,
        {
          retryAfterMs: rateLimit.retryAfterMs,
          responsePreview: text.slice(0, 500),
        }
      );
    }

    bvDebug("unifiLogin() HTTP ERROR", {
      status: loginResponse.status,
      cookie_received: Boolean(rawSetCookie),
      response_preview: text.slice(0, 500),
    });
    throw new Error(`UniFi login failed: ${loginResponse.status} ${text}`);
  }

  const cookie = rawSetCookie
    .split(/,(?=\s*[A-Za-z0-9_\-]+=)/)
    .map((c) => c.split(";")[0].trim())
    .join("; ");

  const tokenMatch = cookie.match(/TOKEN=([^;]+)/);

  if (!tokenMatch) {
    throw new Error("TOKEN cookie introuvable après login UniFi");
  }

  const token = tokenMatch[1];
  const tokenPayloadBase64 = token.split(".")[1];

  if (!tokenPayloadBase64) {
    throw new Error("Payload TOKEN UniFi invalide");
  }

  const normalizedPayload = tokenPayloadBase64
    .replace(/-/g, "+")
    .replace(/_/g, "/");

  const decodedPayload = JSON.parse(
    Buffer.from(normalizedPayload, "base64").toString("utf8")
  );

  const csrfToken = decodedPayload.csrfToken;

  if (!csrfToken) {
    throw new Error("csrfToken introuvable dans le TOKEN UniFi");
  }

  console.log("UNIFI CSRF TOKEN OK");

  const tokenExpiresAtMs = Number(decodedPayload.exp)
    ? Number(decodedPayload.exp) * 1000
    : null;
  const fallbackExpiresAtMs = Date.now() + getUnifiAuthCacheTtlMs();
  const expiresAtMs = tokenExpiresAtMs
    ? Math.min(tokenExpiresAtMs, fallbackExpiresAtMs)
    : fallbackExpiresAtMs;

  bvDebug("unifiLogin() RESULT OK", {
    baseUrl,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    status: loginResponse.status,
    cookie_received: Boolean(rawSetCookie),
    csrf_present: Boolean(csrfToken),
    token_expires_at: tokenExpiresAtMs
      ? new Date(tokenExpiresAtMs).toISOString()
      : null,
    cache_expires_at: new Date(expiresAtMs).toISOString(),
  });

  const session = {
    baseUrl,
    cookie,
    csrfToken,
    cachedAt: new Date().toISOString(),
    expiresAt: new Date(expiresAtMs).toISOString(),
    expiresAtMs,
  };

  storeUnifiAuthSession(siteConfig, session);

  return { baseUrl, cookie, csrfToken };
}

async function callUniFiStamgr(payload, siteConfig = null) {
  const siteName = getUnifiSiteName(siteConfig);

  bvDebug("callUniFiStamgr() START", {
    cmd: payload?.cmd,
    mac: payload?.mac || null,
    minutes: payload?.minutes || null,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    unifi_host: siteConfig ? getUnifiBaseUrl(siteConfig) : getUnifiBaseUrl(),
    unifi_site: siteName,
  });

  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const { baseUrl, cookie, csrfToken } = await unifiLogin(siteConfig, {
      forceRefresh: attempt > 1,
    });
    const stamgrUrl = `${baseUrl}/proxy/network/api/s/${encodeURIComponent(
      siteName
    )}/cmd/stamgr`;

    console.log("UNIFI STAMGR START", {
      url: stamgrUrl,
      site_code: siteConfig?.site_code || null,
      site: siteName,
      controller_name: siteConfig?.controller_name || null,
      cmd: payload?.cmd,
      mac: payload?.mac || null,
      minutes: payload?.minutes || null,
      cookie_present: Boolean(cookie),
      csrf_present: Boolean(csrfToken),
      attempt,
    });

    let response;

    try {
      response = await fetch(stamgrUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json, text/plain, */*",
          Cookie: cookie,
          "X-Csrf-Token": csrfToken,
          Origin: baseUrl,
          Referer: `${baseUrl}/network/${encodeURIComponent(siteName)}/clients/main`,
        },
        body: JSON.stringify(payload),
      });
    } catch (error) {
      logDiagnosticError("UNIFI STAMGR FETCH FAILED", error);
      throw error;
    }

    const text = await response.text();

    console.log("UNIFI STAMGR STATUS =", response.status);
    console.log("UNIFI STAMGR RESPONSE =", text);

    bvDebug("callUniFiStamgr() RESULT", {
      status: response.status,
      ok: response.ok,
      site_code: siteConfig?.site_code || null,
      unifi_site: siteName,
      attempt,
      response_preview: text.slice(0, 500),
    });

    if ((response.status === 401 || response.status === 403) && attempt === 1) {
      clearUnifiAuthCache(siteConfig, `stamgr_${response.status}`);
      console.warn("UNIFI STAMGR AUTH RETRY", {
        status: response.status,
        site_code: siteConfig?.site_code || null,
        controller_name: siteConfig?.controller_name || null,
      });
      continue;
    }

    if (!response.ok) {
      throw new Error(`UniFi stamgr failed: ${response.status} ${text}`);
    }

    try {
      return JSON.parse(text);
    } catch {
      return { raw: text };
    }
  }

  throw new Error("UniFi stamgr failed after authentication retry");
}

function extractUniFiRows(payload) {
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.clients)) return payload.clients;
  if (Array.isArray(payload?.guests)) return payload.guests;
  return [];
}

function getUniFiEpochMs(value) {
  if (value === undefined || value === null || value === "") return null;

  if (typeof value === "number") {
    if (value > 1000000000000) return value;
    if (value > 1000000000) return value * 1000;
  }

  const parsed = new Date(value).getTime();
  return Number.isFinite(parsed) ? parsed : null;
}

function readUniFiBoolean(row, keys) {
  for (const key of keys) {
    if (row && typeof row[key] === "boolean") return row[key];
    if (row && row[key] === 1) return true;
    if (row && row[key] === 0) return false;
  }

  return null;
}

function findUniFiRowByMac(rows, mac) {
  const cleanMac = normalizeMac(mac);
  if (!cleanMac) return null;

  return (
    (rows || []).find((row) => normalizeMac(row?.mac || row?._id) === cleanMac) ||
    null
  );
}

function getGuestAuthorizationState(guestRow, nowMs = Date.now()) {
  if (!guestRow) return null;

  const explicitAuthorized = readUniFiBoolean(guestRow, [
    "authorized",
    "guest_authorized",
    "is_authorized",
  ]);

  if (explicitAuthorized !== null) return explicitAuthorized;

  const endMs = getUniFiEpochMs(guestRow.end || guestRow.expire || guestRow.expires);
  if (endMs) return endMs > nowMs;

  return true;
}

async function callUniFiNetworkApi(pathname, label, siteConfig = null) {
  const siteName = getUnifiSiteName(siteConfig);
  const cleanPath = String(pathname || "").replace(/^\/+/, "");

  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const { baseUrl, cookie, csrfToken } = await unifiLogin(siteConfig, {
      forceRefresh: attempt > 1,
    });
    const url = `${baseUrl}/proxy/network/api/s/${encodeURIComponent(
      siteName
    )}/${cleanPath}`;

    console.log("UNIFI API GET START", {
      label,
      url,
      site_code: siteConfig?.site_code || null,
      site: siteName,
      controller_name: siteConfig?.controller_name || null,
      attempt,
    });

    let response;

    try {
      response = await fetch(url, {
        method: "GET",
        headers: {
          Accept: "application/json, text/plain, */*",
          Cookie: cookie,
          "X-Csrf-Token": csrfToken,
          Origin: baseUrl,
          Referer: `${baseUrl}/network/${encodeURIComponent(siteName)}/clients/main`,
        },
      });
    } catch (error) {
      logDiagnosticError(`UNIFI API GET FAILED: ${label}`, error);
      throw error;
    }

    const text = await response.text();

    console.log("UNIFI API GET RESULT", {
      label,
      status: response.status,
      ok: response.ok,
      site_code: siteConfig?.site_code || null,
      attempt,
      response_preview: text.slice(0, 500),
    });

    if ((response.status === 401 || response.status === 403) && attempt === 1) {
      clearUnifiAuthCache(siteConfig, `${label}_${response.status}`);
      console.warn("UNIFI API AUTH RETRY", {
        label,
        status: response.status,
        site_code: siteConfig?.site_code || null,
        controller_name: siteConfig?.controller_name || null,
      });
      continue;
    }

    if (!response.ok) {
      throw new Error(`UniFi API ${label} failed: ${response.status} ${text}`);
    }

    try {
      return JSON.parse(text);
    } catch {
      return { raw: text };
    }
  }

  throw new Error(`UniFi API ${label} failed after authentication retry`);
}

async function callUniFiNetworkApiRaw(
  pathname,
  label,
  siteConfig = null,
  options = {}
) {
  const siteName = getUnifiSiteName(siteConfig);
  const cleanPath = String(pathname || "").replace(/^\/+/, "");
  const method = String(options.method || "GET").toUpperCase();
  const body = options.body === undefined ? null : options.body;

  for (let attempt = 1; attempt <= 2; attempt += 1) {
    const { baseUrl, cookie, csrfToken } = await unifiLogin(siteConfig, {
      forceRefresh: attempt > 1,
    });
    const url = `${baseUrl}/proxy/network/api/s/${encodeURIComponent(
      siteName
    )}/${cleanPath}`;
    const headers = {
      Accept: "application/json, text/plain, */*",
      Cookie: cookie,
      "X-Csrf-Token": csrfToken,
      Origin: baseUrl,
      Referer: `${baseUrl}/network/${encodeURIComponent(siteName)}/settings`,
      ...(options.headers || {}),
    };

    let requestBody;
    if (body !== null) {
      headers["Content-Type"] = "application/json";
      requestBody = JSON.stringify(body);
    }

    console.log("UNIFI API REQUEST START", {
      label,
      method,
      url,
      site_code: siteConfig?.site_code || null,
      site: siteName,
      controller_name: siteConfig?.controller_name || null,
      attempt,
      body_keys: body && typeof body === "object" ? Object.keys(body) : [],
    });

    let response;

    try {
      response = await fetch(url, {
        method,
        headers,
        body: requestBody,
      });
    } catch (error) {
      logDiagnosticError(`UNIFI API REQUEST FAILED: ${label}`, error);
      throw error;
    }

    const text = await response.text();
    let json = null;

    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }

    console.log("UNIFI API REQUEST RESULT", {
      label,
      method,
      status: response.status,
      ok: response.ok,
      site_code: siteConfig?.site_code || null,
      attempt,
      response_preview: text.slice(0, 500),
    });

    if ((response.status === 401 || response.status === 403) && attempt === 1) {
      clearUnifiAuthCache(siteConfig, `${label}_${response.status}`);
      console.warn("UNIFI API REQUEST AUTH RETRY", {
        label,
        status: response.status,
        site_code: siteConfig?.site_code || null,
        controller_name: siteConfig?.controller_name || null,
      });
      continue;
    }

    if (!response.ok) {
      const error = new Error(`UniFi API ${label} failed: ${response.status} ${text}`);
      error.status = response.status;
      error.response_text = text;
      error.response_json = json;
      throw error;
    }

    return {
      status: response.status,
      ok: response.ok,
      text,
      json,
      url,
      method,
    };
  }

  throw new Error(`UniFi API ${label} failed after authentication retry`);
}

function extractUniFiEnvelopeData(payload) {
  if (Array.isArray(payload?.data)) return payload.data;
  if (Array.isArray(payload)) return payload;
  return [];
}

function getFirstNonInternalIPv4() {
  const interfaces = os.networkInterfaces();

  for (const entries of Object.values(interfaces)) {
    for (const entry of entries || []) {
      if (entry.family === "IPv4" && !entry.internal && entry.address) {
        return entry.address;
      }
    }
  }

  return "";
}

function getExternalPortalHost() {
  return String(
    process.env.BV_EXTERNAL_PORTAL_HOST ||
      process.env.UNIFI_EXTERNAL_PORTAL_HOST ||
      process.env.BV_MINIPC_IP ||
      getFirstNonInternalIPv4() ||
      "127.0.0.1"
  )
    .trim()
    .replace(/^https?:\/\//i, "")
    .replace(/[:/].*$/, "");
}

function normalizePortalHost(value) {
  return String(value || "")
    .trim()
    .replace(/^https?:\/\//i, "")
    .replace(/[:/].*$/, "");
}

function getSitePortalHost(siteConfig = null) {
  return normalizePortalHost(siteConfig?.portal_host) || getExternalPortalHost();
}

function getExternalPortalPort() {
  const configured = Number(
    process.env.BV_EXTERNAL_PORTAL_PORT ||
      process.env.UNIFI_EXTERNAL_PORTAL_PORT ||
      8880
  );

  return Number.isFinite(configured) && configured > 0 ? configured : 8880;
}

function getSitePortalPort(siteConfig = null) {
  const configured = Number(siteConfig?.portal_port || 0);
  if (Number.isFinite(configured) && configured > 0) return configured;
  return getExternalPortalPort();
}

function buildPortalBaseUrl(host, port) {
  const normalizedHost = normalizePortalHost(host);
  const normalizedPort = Number(port || 0);

  if (!normalizedHost) return null;
  if (normalizedPort && normalizedPort !== 80) {
    return `http://${normalizedHost}:${normalizedPort}`;
  }
  return `http://${normalizedHost}`;
}

function getExternalPortalExpectedConfig(siteConfig = null) {
  const host = getSitePortalHost(siteConfig);
  const port = getSitePortalPort(siteConfig);
  const siteName = getUnifiSiteName(siteConfig);
  const portalBaseUrl = buildPortalBaseUrl(host, port);
  const authMode = String(
    process.env.BV_UNIFI_EXTERNAL_PORTAL_AUTH ||
      process.env.UNIFI_EXTERNAL_PORTAL_AUTH ||
      "custom"
  )
    .trim()
    .toLowerCase();

  return {
    external_portal_host: host,
    external_portal_port: port,
    expected_unifi_external_portal_value: host,
    expected_client_portal_url: `${portalBaseUrl}/guest/s/${encodeURIComponent(siteName)}`,
    expected_portal_html_url: `${portalBaseUrl}/portal.html`,
    expected_auth: authMode || "custom",
    expected_secure_portal: false,
    expected_https_redirect: false,
  };
}

function getStalePortalUrlPatterns() {
  const configured = String(process.env.BV_STALE_PORTAL_URL_PATTERNS || "")
    .split(",")
    .map((value) => value.trim().toLowerCase())
    .filter(Boolean);

  return [
    "bv-access-api.onrender.com",
    "https://bv-access-api.onrender.com/portal.html",
    ...configured,
  ];
}

function normalizeUniFiPortalValue(value) {
  if (value === null || value === undefined) return "";
  return String(value).trim();
}

function portalFlagIsFalseOrAbsent(value) {
  return value === false || value === null || value === undefined || value === "";
}

function findStalePortalReferences(value, patterns = getStalePortalUrlPatterns(), pathName = "") {
  const matches = [];

  if (value === null || value === undefined) return matches;

  if (typeof value === "string") {
    const lower = value.toLowerCase();
    const matchedPattern = patterns.find((pattern) => lower.includes(pattern));

    if (matchedPattern) {
      matches.push({
        path: pathName || "$",
        value,
        matched_pattern: matchedPattern,
      });
    }

    return matches;
  }

  if (Array.isArray(value)) {
    value.forEach((item, index) => {
      matches.push(
        ...findStalePortalReferences(item, patterns, `${pathName || "$"}[${index}]`)
      );
    });
    return matches;
  }

  if (typeof value === "object") {
    for (const [key, child] of Object.entries(value)) {
      matches.push(
        ...findStalePortalReferences(
          child,
          patterns,
          pathName ? `${pathName}.${key}` : key
        )
      );
    }
  }

  return matches;
}

function getGuestAccessSettingFromRows(rows = []) {
  return (
    rows.find((row) => row?.key === "guest_access") ||
    rows.find((row) => row?.name === "guest_access") ||
    null
  );
}

async function fetchUniFiGuestAccessSetting(siteConfig = null) {
  const endpoints = [];
  const candidates = [];

  const settingsResult = await callUniFiNetworkApiRaw(
    "get/setting",
    "portal_get_setting",
    siteConfig
  );
  const settingsRows = extractUniFiEnvelopeData(settingsResult.json);
  const fromGetSetting = getGuestAccessSettingFromRows(settingsRows);

  endpoints.push({
    endpoint: "get/setting",
    status: settingsResult.status,
    ok: settingsResult.ok,
    rows: settingsRows.length,
    guest_access_found: Boolean(fromGetSetting),
  });

  if (fromGetSetting) {
    candidates.push({
      source: "get/setting",
      setting: fromGetSetting,
    });
  }

  const restResult = await callUniFiNetworkApiRaw(
    "rest/setting/guest_access",
    "portal_rest_guest_access",
    siteConfig
  );
  const restRows = extractUniFiEnvelopeData(restResult.json);
  const fromRest = restRows[0] || null;

  endpoints.push({
    endpoint: "rest/setting/guest_access",
    status: restResult.status,
    ok: restResult.ok,
    rows: restRows.length,
    guest_access_found: Boolean(fromRest),
  });

  if (fromRest) {
    candidates.push({
      source: "rest/setting/guest_access",
      setting: fromRest,
    });
  }

  const preferred =
    candidates.find((candidate) => candidate.source === "rest/setting/guest_access") ||
    candidates[0] ||
    null;

  return {
    setting: preferred?.setting || null,
    source: preferred?.source || "none",
    endpoints,
    candidates,
  };
}

function summarizeUniFiGuestAccess(setting = {}) {
  const interestingKeys = [
    "_id",
    "site_id",
    "key",
    "auth",
    "portal_enabled",
    "custom_ip",
    "redirect_https",
    "redirect_enabled",
    "redirect_url",
    "portal_hostname",
    "portal_use_hostname",
    "voucher_enabled",
    "password_enabled",
    "payment_enabled",
    "radius_enabled",
    "facebook_enabled",
    "wechat_enabled",
    "ec_enabled",
    "expire",
    "expire_number",
    "expire_unit",
  ];
  const summary = {};

  for (const key of interestingKeys) {
    if (Object.prototype.hasOwnProperty.call(setting, key)) {
      summary[key] = setting[key];
    }
  }

  const allowanceKeys = Object.keys(setting || {})
    .filter((key) => /allow|wall|garden|pre.?auth|portal|custom_ip|redirect/i.test(key))
    .sort();

  return {
    summary,
    allowance_and_portal_related_keys: allowanceKeys.reduce((acc, key) => {
      acc[key] = setting[key];
      return acc;
    }, {}),
    all_keys: Object.keys(setting || {}).sort(),
  };
}

function buildUniFiPortalMismatches(setting = {}, expected = {}) {
  const stalePortalReferences = findStalePortalReferences(setting);
  const checks = [
    {
      key: "portal_enabled",
      expected: true,
      actual: setting.portal_enabled,
      ok: setting.portal_enabled === true,
      reason: "Le portail captif doit être activé.",
    },
    {
      key: "auth",
      expected: expected.expected_auth,
      actual: setting.auth,
      ok: String(setting.auth || "").toLowerCase() === expected.expected_auth,
      reason:
        "Le mode doit être External Portal Server. Sur UniFi Network 10.4.57, l'API stocke ce mode sous auth=custom.",
    },
    {
      key: "custom_ip",
      expected: expected.external_portal_host,
      actual: setting.custom_ip,
      ok: String(setting.custom_ip || "").trim() === expected.external_portal_host,
      reason: "UniFi 10.x attend seulement l'IP du serveur externe dans ce champ.",
    },
    {
      key: "redirect_https",
      expected: false,
      actual: setting.redirect_https,
      ok: setting.redirect_https === false,
      reason: "HTTPS redirect ne doit pas forcer le portail interne sur 8444.",
    },
    {
      key: "redirect_enabled",
      expected: false,
      actual: setting.redirect_enabled,
      ok: portalFlagIsFalseOrAbsent(setting.redirect_enabled),
      reason: "La redirection native UniFi ne doit pas remplacer le portail externe B&V.",
    },
    {
      key: "redirect_url",
      expected: "",
      actual: setting.redirect_url,
      ok: normalizeUniFiPortalValue(setting.redirect_url) === "",
      reason: "Aucune ancienne URL Render ou landing page native ne doit rester dans redirect_url.",
    },
    {
      key: "portal_use_hostname",
      expected: false,
      actual: setting.portal_use_hostname,
      ok: portalFlagIsFalseOrAbsent(setting.portal_use_hostname),
      reason: "UniFi ne doit pas utiliser un ancien hostname de portail.",
    },
    {
      key: "portal_hostname",
      expected: "",
      actual: setting.portal_hostname,
      ok: normalizeUniFiPortalValue(setting.portal_hostname) === "",
      reason: "Aucun ancien hostname de portail ne doit rester configuré.",
    },
    {
      key: "voucher_enabled",
      expected: false,
      actual: setting.voucher_enabled,
      ok: setting.voucher_enabled === false,
      reason: "Les vouchers UniFi natifs doivent rester désactivés.",
    },
    {
      key: "password_enabled",
      expected: false,
      actual: setting.password_enabled,
      ok: setting.password_enabled === false,
      reason: "Le mot de passe UniFi natif ne doit pas contourner B&V.",
    },
    {
      key: "payment_enabled",
      expected: false,
      actual: setting.payment_enabled,
      ok: setting.payment_enabled === false,
      reason: "Le paiement UniFi natif ne doit pas contourner B&V.",
    },
    {
      key: "stale_portal_references",
      expected: [],
      actual: stalePortalReferences,
      ok: stalePortalReferences.length === 0,
      reason:
        "Une ancienne référence au portail Render ou à un autre portail externe obsolète reste stockée dans guest_access.",
    },
  ];

  return checks.filter((check) => !check.ok);
}

function buildUniFiPortalValidation(candidates = [], expected = {}) {
  const representations = candidates.map((candidate) => {
    const observed = summarizeUniFiGuestAccess(candidate.setting);
    const stalePortalReferences = findStalePortalReferences(candidate.setting);
    const mismatches = buildUniFiPortalMismatches(candidate.setting, expected);

    return {
      source: candidate.source,
      summary: observed.summary,
      allowance_and_portal_related_keys: observed.allowance_and_portal_related_keys,
      stale_portal_references: stalePortalReferences,
      mismatches,
      mismatch_count: mismatches.length,
      compliant: mismatches.length === 0,
    };
  });

  const combinedMismatches = representations.flatMap((representation) =>
    representation.mismatches.map((mismatch) => ({
      source: representation.source,
      ...mismatch,
    }))
  );
  const combinedStaleReferences = representations.flatMap((representation) =>
    representation.stale_portal_references.map((reference) => ({
      source: representation.source,
      ...reference,
    }))
  );

  return {
    success: representations.length > 0 && combinedMismatches.length === 0,
    representation_count: representations.length,
    representations,
    mismatch_count: combinedMismatches.length,
    mismatches: combinedMismatches,
    stale_portal_reference_count: combinedStaleReferences.length,
    stale_portal_references: combinedStaleReferences,
  };
}

function buildExternalPortalGuestAccessPayload(existingSetting = {}, expected = {}) {
  const payload = {
    ...existingSetting,
    portal_enabled: true,
    auth: expected.expected_auth || "custom",
    custom_ip: expected.external_portal_host,
    redirect_https: false,
    redirect_enabled: false,
    redirect_url: "",
    portal_use_hostname: false,
    portal_hostname: "",
    voucher_enabled: false,
    password_enabled: false,
    payment_enabled: false,
    radius_enabled: false,
    facebook_enabled: false,
    wechat_enabled: false,
    ec_enabled: false,
  };

  for (const key of [
    "redirect_to",
    "redirect_url",
    "portal_hostname",
    "portal_redirect_url",
    "post_auth_url",
    "success_url",
    "custom_url",
    "external_portal_url",
    "external_portal_hostname",
  ]) {
    payload[key] = "";
  }

  for (const key of [
    "secure_portal_enabled",
    "https_redirect_enabled",
    "portal_https_redirect",
    "portal_secure",
    "portal_use_hostname",
    "redirect_enabled",
  ]) {
    payload[key] = false;
  }

  return payload;
}

function buildRestGuestAccessPayload(payload = {}) {
  const restPayload = { ...payload };
  delete restPayload._id;
  return restPayload;
}

async function applyUniFiGuestAccessSetting(siteConfig = null, payload, options = {}) {
  const settingId = String(payload?._id || "").trim();

  if (!settingId) {
    throw new Error("Impossible d'appliquer guest_access: _id UniFi manquant.");
  }

  if (options.forceRest) {
    return await callUniFiNetworkApiRaw(
      `rest/setting/guest_access/${encodeURIComponent(settingId)}`,
      "portal_rest_put_guest_access",
      siteConfig,
      {
        method: "PUT",
        body: buildRestGuestAccessPayload(payload),
      }
    );
  }

  try {
    return await callUniFiNetworkApiRaw(
      `set/setting/guest_access/${encodeURIComponent(settingId)}`,
      "portal_set_guest_access",
      siteConfig,
      {
        method: "POST",
        body: payload,
      }
    );
  } catch (setError) {
    console.warn("UNIFI PORTAL SET/SETTING FAILED, TRYING REST PUT", {
      status: setError.status || null,
      message: setError.message,
    });

    return await callUniFiNetworkApiRaw(
      `rest/setting/guest_access/${encodeURIComponent(settingId)}`,
      "portal_rest_put_guest_access",
      siteConfig,
      {
        method: "PUT",
        body: buildRestGuestAccessPayload(payload),
      }
    );
  }
}

async function getUniFiSiteSnapshot(siteConfig = null, options = {}) {
  const cache = options.snapshotCache || null;
  const cacheKey = getUnifiConfigKey(siteConfig);

  if (cache?.has(cacheKey)) {
    return cache.get(cacheKey);
  }

  const snapshot = {
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    unifi_host: siteConfig ? getUnifiBaseUrl(siteConfig) : getUnifiBaseUrl(),
    unifi_site: getUnifiSiteName(siteConfig),
    state_available: false,
    staRows: [],
    guestRows: [],
    response_times_ms: {},
    errors: [],
    auth_rate_limited: false,
    auth_retry_after_ms: null,
  };

  try {
    const startMs = Date.now();
    const staPayload = await callUniFiNetworkApi("stat/sta", "stat_sta", siteConfig);
    snapshot.response_times_ms.stat_sta = Date.now() - startMs;
    snapshot.staRows = extractUniFiRows(staPayload);
    snapshot.state_available = true;
  } catch (error) {
    snapshot.errors.push({ source: "stat_sta", message: error.message });
    if (isUniFiAuthRateLimitError(error)) {
      snapshot.auth_rate_limited = true;
      snapshot.auth_retry_after_ms = error.retry_after_ms || null;
    }
    logDiagnosticError("UNIFI SITE SNAPSHOT stat/sta ERROR", error);
  }

  if (snapshot.auth_rate_limited) {
    snapshot.errors.push({
      source: "stat_guest",
      message: "Skipped because UniFi authentication is rate limited or in cooldown.",
      retry_after_ms: snapshot.auth_retry_after_ms,
    });
    console.warn("UNIFI SITE SNAPSHOT stat/guest SKIPPED", {
      site_code: snapshot.site_code,
      controller_name: snapshot.controller_name,
      reason: "unifi_auth_rate_limited",
      retry_after_ms: snapshot.auth_retry_after_ms,
    });
  } else {
    try {
      const startMs = Date.now();
      const guestPayload = await callUniFiNetworkApi("stat/guest", "stat_guest", siteConfig);
      snapshot.response_times_ms.stat_guest = Date.now() - startMs;
      snapshot.guestRows = extractUniFiRows(guestPayload);
      snapshot.state_available = true;
    } catch (error) {
      snapshot.errors.push({ source: "stat_guest", message: error.message });
      logDiagnosticError("UNIFI SITE SNAPSHOT stat/guest ERROR", error);
    }
  }

  console.log("UNIFI SITE SNAPSHOT", {
    site_code: snapshot.site_code,
    controller_name: snapshot.controller_name,
    unifi_host: snapshot.unifi_host,
    unifi_site: snapshot.unifi_site,
    state_available: snapshot.state_available,
    sta_count: snapshot.staRows.length,
    guest_count: snapshot.guestRows.length,
    auth_rate_limited: snapshot.auth_rate_limited,
    auth_retry_after_ms: snapshot.auth_retry_after_ms,
    response_times_ms: snapshot.response_times_ms,
    errors: snapshot.errors,
  });

  if (cache) {
    cache.set(cacheKey, snapshot);
  }

  return snapshot;
}

async function getUniFiClientState(mac, siteConfig = null, options = {}) {
  const cleanMac = normalizeMac(mac);
  const nowMs = Date.now();
  const graceMs = getConnectedUsageGraceMs();

  if (!cleanMac) {
    return {
      success: false,
      reason: "no_mac_provided",
      mac: null,
      site_code: siteConfig?.site_code || null,
      connected: false,
      authorized: false,
      state_available: false,
    };
  }

  if (!isUnifiEnabled()) {
    return {
      success: false,
      skipped: true,
      reason: "unifi_disabled",
      mac: cleanMac,
      site_code: siteConfig?.site_code || null,
      connected: null,
      authorized: null,
      state_available: false,
    };
  }

  const result = {
    success: true,
    mac: cleanMac,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    connected: false,
    authorized: false,
    authorization_known: false,
    state_available: false,
    last_seen_at: null,
    stale_seconds: null,
    stale: true,
    ap_mac: null,
    essid: null,
    ip: null,
    hostname: null,
    sta_found: false,
    guest_found: false,
    errors: [],
  };

  const snapshot =
    options.snapshot ||
    await getUniFiSiteSnapshot(siteConfig, {
      snapshotCache: options.snapshotCache,
    });

  const staRows = snapshot.staRows || [];
  const guestRows = snapshot.guestRows || [];
  result.state_available = Boolean(snapshot.state_available);
  result.errors = snapshot.errors || [];

  const staRow = findUniFiRowByMac(staRows, cleanMac);
  const guestRow = findUniFiRowByMac(guestRows, cleanMac);

  result.sta_found = Boolean(staRow);
  result.guest_found = Boolean(guestRow);

  if (staRow) {
    const lastSeenMs =
      getUniFiEpochMs(
        staRow.last_seen ||
          staRow.last_seen_at ||
          staRow.latest_seen ||
          staRow.latest_assoc_time ||
          staRow.assoc_time
      ) || nowMs;

    result.connected = true;
    result.last_seen_at = new Date(lastSeenMs).toISOString();
    result.stale_seconds = Math.max(0, Math.floor((nowMs - lastSeenMs) / 1000));
    result.stale = nowMs - lastSeenMs > graceMs;
    result.ap_mac =
      normalizeMac(staRow.ap_mac || staRow.last_seen_by_uap || staRow.uap_mac) ||
      null;
    result.essid = staRow.essid || staRow.network || staRow.network_name || null;
    result.ip = staRow.ip || staRow.last_ip || null;
    result.hostname = staRow.hostname || staRow.name || staRow.display_name || null;
  }

  const staAuthorized = readUniFiBoolean(staRow, [
    "authorized",
    "guest_authorized",
    "is_authorized",
  ]);
  const guestAuthorized = getGuestAuthorizationState(guestRow, nowMs);
  const authorizationValue =
    guestAuthorized !== null ? guestAuthorized : staAuthorized;

  if (authorizationValue !== null) {
    result.authorized = Boolean(authorizationValue);
    result.authorization_known = true;
  } else {
    result.authorized = Boolean(staRow && !result.stale);
    result.authorization_known = false;
  }

  console.log("UNIFI CLIENT STATE", {
    mac: result.mac,
    site_code: result.site_code,
    controller_name: result.controller_name,
    connected: result.connected,
    authorized: result.authorized,
    authorization_known: result.authorization_known,
    stale: result.stale,
    stale_seconds: result.stale_seconds,
    last_seen_at: result.last_seen_at,
    ap_mac: result.ap_mac,
    sta_found: result.sta_found,
    guest_found: result.guest_found,
    errors: result.errors,
  });

  return result;
}

async function resolveUniFiClientByIp(ipAddress, siteConfig = null, options = {}) {
  const cleanIp = normalizeIpAddress(ipAddress);

  if (!cleanIp) {
    return {
      success: false,
      reason: "invalid_ip",
      ip_address: ipAddress || null,
      state_available: false,
    };
  }

  if (!isUnifiEnabled()) {
    return {
      success: false,
      skipped: true,
      reason: "unifi_disabled",
      ip_address: cleanIp,
      state_available: false,
    };
  }

  const snapshot =
    options.snapshot ||
    await getUniFiSiteSnapshot(siteConfig, {
      snapshotCache: options.snapshotCache,
    });
  const rows = [
    ...(snapshot.staRows || []).map((row) => ({ source: "stat_sta", row })),
    ...(snapshot.guestRows || []).map((row) => ({ source: "stat_guest", row })),
  ];
  const match = rows.find(({ row }) => {
    const rowIps = [
      row?.ip,
      row?.last_ip,
      row?.fixed_ip,
      row?.network_ip,
      row?.client_ip,
    ].map(normalizeIpAddress);

    return rowIps.includes(cleanIp);
  });

  if (!match) {
    return {
      success: false,
      reason: "client_not_found_by_ip",
      ip_address: cleanIp,
      site_code: siteConfig?.site_code || null,
      controller_name: siteConfig?.controller_name || null,
      state_available: Boolean(snapshot.state_available),
      sta_count: snapshot.staRows?.length || 0,
      guest_count: snapshot.guestRows?.length || 0,
      errors: snapshot.errors || [],
    };
  }

  const mac = normalizeMac(match.row?.mac || match.row?._id);

  return {
    success: Boolean(mac),
    reason: mac ? "resolved_by_unifi_ip" : "matched_ip_without_mac",
    ip_address: cleanIp,
    mac_address: mac,
    source: match.source,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    state_available: Boolean(snapshot.state_available),
    row_preview: {
      mac: match.row?.mac || match.row?._id || null,
      ip: match.row?.ip || match.row?.last_ip || null,
      hostname: match.row?.hostname || match.row?.name || match.row?.display_name || null,
      essid: match.row?.essid || match.row?.network || match.row?.network_name || null,
      ap_mac: match.row?.ap_mac || match.row?.last_seen_by_uap || match.row?.uap_mac || null,
    },
  };
}

async function resolveMacAddressForAccessRequest(req, siteConfig = null) {
  const selectedCandidate = firstMacCandidate(req);

  if (selectedCandidate?.normalized) {
    return {
      success: true,
      method: "request_parameter",
      mac_address: selectedCandidate.normalized,
      selected_source: selectedCandidate.source,
      selected_raw: selectedCandidate.raw,
      candidates: getMacCandidatesFromRequest(req),
      ip_candidates: getIpCandidatesFromRequest(req),
    };
  }

  const ipCandidates = getIpCandidatesFromRequest(req);
  const normalizedIpCandidates = ipCandidates
    .map((candidate) => candidate.normalized)
    .filter(Boolean)
    .filter((ip, index, all) => all.indexOf(ip) === index);
  const attempts = [];

  for (const ipAddress of normalizedIpCandidates) {
    try {
      const result = await resolveUniFiClientByIp(ipAddress, siteConfig);
      attempts.push(result);

      if (result.success && result.mac_address) {
        return {
          success: true,
          method: "unifi_ip_lookup",
          mac_address: result.mac_address,
          selected_source: `${result.source}.ip:${ipAddress}`,
          candidates: getMacCandidatesFromRequest(req),
          ip_candidates: ipCandidates,
          attempts,
        };
      }
    } catch (error) {
      attempts.push({
        success: false,
        ip_address: ipAddress,
        error: error.message,
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }

  return {
    success: false,
    method: "not_resolved",
    mac_address: null,
    selected_source: null,
    candidates: getMacCandidatesFromRequest(req),
    ip_candidates: ipCandidates,
    attempts,
  };
}

async function authorizeClient(mac, minutes = 60, siteConfig = null) {
  const cleanMac = normalizeMac(mac);
  const cleanMinutes = Math.max(1, Math.ceil(Number(minutes) || 60));

  bvDebug("authorizeClient() START", {
    raw_mac: mac || null,
    normalized_mac: cleanMac,
    minutes: cleanMinutes,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    unifi_host: siteConfig ? getUnifiBaseUrl(siteConfig) : getUnifiBaseUrl(),
    unifi_site: getUnifiSiteName(siteConfig),
  });

  if (!cleanMac) {
    bvDebug("authorizeClient() SKIPPED", {
      reason: "no_mac_provided",
    });
    console.log("UNIFI AUTHORIZE SKIPPED: no MAC provided");
    return { success: false, skipped: true, reason: "no_mac_provided", mac: null };
  }

  if (!isUnifiEnabled()) {
    bvDebug("authorizeClient() SKIPPED", {
      reason: "unifi_disabled",
      mac: cleanMac,
      unifi_required: isUnifiRequired(),
      site_code: siteConfig?.site_code || null,
    });
    console.log("UNIFI AUTHORIZE SKIPPED: UniFi disabled until bridge is enabled");
    return {
      success: false,
      skipped: true,
      reason: "unifi_disabled",
      non_blocking: true,
      action: "authorize",
      mac: cleanMac,
      site_code: siteConfig?.site_code || null,
    };
  }

  const payload = {
    cmd: "authorize-guest",
    mac: cleanMac,
    minutes: cleanMinutes,
  };

  bvDebug("authorizeClient() CALL STAMGR", payload);

  const result = await callUniFiStamgr(payload, siteConfig);

  bvDebug("authorizeClient() RESULT", {
    success: true,
    mac: cleanMac,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    unifi: result,
  });

  return {
    success: true,
    action: "authorize",
    mac: cleanMac,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    payload,
    unifi: result,
  };
}

async function unauthorizeClient(mac, siteConfig = null) {
  const cleanMac = normalizeMac(mac);

  if (!cleanMac) {
    console.log("UNIFI UNAUTHORIZE SKIPPED: no MAC provided");
    return { success: false, skipped: true, reason: "no_mac_provided", mac: null };
  }

  if (!isUnifiEnabled()) {
    console.log("UNIFI UNAUTHORIZE SKIPPED: UniFi disabled until bridge is enabled");
    return {
      success: false,
      skipped: true,
      reason: "unifi_disabled",
      non_blocking: true,
      action: "unauthorize",
      mac: cleanMac,
      site_code: siteConfig?.site_code || null,
    };
  }

  const payload = {
    cmd: "unauthorize-guest",
    mac: cleanMac,
  };

  const result = await callUniFiStamgr(payload, siteConfig);

  return {
    success: true,
    action: "unauthorize",
    mac: cleanMac,
    site_code: siteConfig?.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    payload,
    unifi: result,
  };
}

function detectPlanFromTitle(title = "") {
  const t = title.toLowerCase();

  if (t.includes("express") || t.includes("10")) {
    return { plan_code: "PLAN10", minutes: 10 };
  }

  if (t.includes("standard") || t.includes("30")) {
    return { plan_code: "PLAN30", minutes: 30 };
  }

  if (t.includes("heure") || t.includes("1h") || t.includes("50")) {
    return { plan_code: "PLAN60", minutes: 60 };
  }

  if (t.includes("plus") || t.includes("3h") || t.includes("3 heures")) {
    return { plan_code: "PLAN180", minutes: 180 };
  }

  if (t.includes("nuit") || t.includes("soirée") || t.includes("12")) {
    return { plan_code: "PLANNUIT", minutes: 720 };
  }

  return { plan_code: "PLAN30", minutes: 30 };
}

function getCustomerInfo(order) {
  return {
    customer_name:
      order?.billing_address?.name ||
      `${order?.customer?.first_name || ""} ${
        order?.customer?.last_name || ""
      }`.trim() ||
      null,

    customer_email:
      order?.email || order?.customer?.email || order?.contact_email || null,

    customer_phone:
      normalizePhone(
        order?.phone ||
          order?.customer?.phone ||
          order?.billing_address?.phone ||
          order?.shipping_address?.phone ||
          ""
      ) || null,
  };
}

function detectPaymentMethod(order) {
  const gateway =
    order?.payment_gateway_names?.[0] ||
    order?.gateway ||
    order?.processing_method ||
    "";

  const g = String(gateway).toLowerCase();

  if (g.includes("cash")) return "cash";
  if (g.includes("manual")) return "cash";
  if (g.includes("moncash")) return "moncash";
  if (g.includes("natcash")) return "natcash";

  return "online_card";
}

async function findAgentIfNeeded(paymentMethod) {
  if (!["cash", "moncash", "natcash"].includes(paymentMethod)) {
    return null;
  }

  const { data, error } = await supabase
    .from("agents")
    .select("*")
    .eq("agent_code", "BV-AGENT-001")
    .eq("status", "active")
    .limit(1);

  if (error) throw error;

  return data && data.length > 0 ? data[0] : null;
}

async function createAccessCodeFromOrder(order, req = null) {
  const item = order?.line_items?.[0];
  const productTitle = item?.title || "Plan Standard 30 min";
  const plan = detectPlanFromTitle(productTitle);

  const code = await generateUniqueNationalCode();
  const { qr_code_url, portal_url } = buildVoucherQrPayload(code, req);

  const customer = getCustomerInfo(order);
  const amount = Number(order?.total_price || order?.current_total_price || 0);
  const paymentMethod = detectPaymentMethod(order);
  const agent = await findAgentIfNeeded(paymentMethod);
  const siteCode = agent?.site_code || DEFAULT_SITE_CODE;

  const { data: saleData, error: saleError } = await supabase
    .from("sales")
    .insert([
      {
        sale_type: "access",
        payment_method: paymentMethod,
        product_name: plan.plan_code,
        amount,
        customer_name: customer.customer_name,
        customer_phone: customer.customer_phone,
        agent_id: agent ? agent.id : null,
        voucher_code: code,
        payment_confirmed: true,
        site_code: siteCode,
      },
    ])
    .select();

  if (saleError) throw saleError;

  const sale = saleData[0];

  const accessPayload = {
    sale_id: sale.id,
    code,
    plan_code: plan.plan_code,
    minutes: plan.minutes,
    duration_minutes: plan.minutes,
    minutes_total: plan.minutes,
    minutes_remaining: plan.minutes,
    national_voucher: true,
    validation_mode: "central",
    purchase_source: "shopify",
    status: "unused",
    customer_name: customer.customer_name,
    customer_email: customer.customer_email,
    customer_phone: customer.customer_phone,
    amount,
    qr_code_url,
    sale_site_code: siteCode,
    notes:
      "Code national B&V Access numérique. Le code est le produit. Le client doit conserver son code.",
  };

  const { data: accessData, error: accessError } = await supabase
    .from("access_codes")
    .insert([accessPayload])
    .select();

  if (accessError) throw accessError;

  let commissionData = null;

  if (agent) {
    const commissionAmount =
      amount * (Number(agent.access_commission_percent || 10) / 100);

    const { data, error } = await supabase
      .from("commissions")
      .insert([
        {
          agent_id: agent.id,
          sale_id: sale.id,
          commission_type: "voucher_sale",
          commission_amount: commissionAmount,
          status: "pending",
          site_code: siteCode,
        },
      ])
      .select();

    if (error) throw error;
    commissionData = data;
  }

  return {
    code,
    qr_code_url,
    portal_url,
    plan,
    customer,
    product_title: productTitle,
    payment_method: paymentMethod,
    agent_code: agent ? agent.agent_code : null,
    access_code_record: accessData,
    sale_record: saleData,
    commission_record: commissionData,
  };
}
async function createAgentSale({
  agent_code,
  customer_name,
  customer_phone,
  product_name,
  amount,
  minutes,
  payment_method = "cash",
}, req = null) {
  const requestId = req?.bvPosRequestId || null;

  bvDebug("POS SALE AGENT LOOKUP START", {
    request_id: requestId,
    agent_code,
    product_name,
    amount,
    minutes,
    payment_method,
  });

  const { data: agent, error: agentError } = await supabase
    .from("agents")
    .select("*")
    .eq("agent_code", agent_code)
    .eq("status", "active")
    .single();

  if (agentError || !agent) {
    if (agentError) {
      logDiagnosticError("POS SALE AGENT LOOKUP ERROR", agentError);
    }

    bvDebug("POS SALE AGENT LOOKUP RESULT", {
      request_id: requestId,
      agent_found: Boolean(agent),
      agent_code,
    });

    throw new Error("Agent invalide ou inactif");
  }

  bvDebug("POS SALE AGENT LOOKUP RESULT", {
    request_id: requestId,
    agent_found: true,
    agent_id: agent.id,
    agent_code: agent.agent_code,
    site_code: agent.site_code || DEFAULT_SITE_CODE,
  });

  const voucherCode = await generateUniqueNationalCode();
  const { qr_code_url, portal_url } = buildVoucherQrPayload(voucherCode, req);
  const cleanPhone = normalizePhone(customer_phone);
  const siteCode = agent.site_code || DEFAULT_SITE_CODE;

  bvDebug("POS SALE INSERT SALES START", {
    request_id: requestId,
    agent_id: agent.id,
    agent_code: agent.agent_code,
    site_code: siteCode,
    product_name,
    amount,
    payment_method,
    voucher_code: voucherCode,
  });

  const { data: sale, error: saleError } = await supabase
    .from("sales")
    .insert([
      {
        agent_id: agent.id,
        sale_type: "access",
        payment_method,
        product_name,
        amount,
        customer_name,
        customer_phone: cleanPhone || null,
        voucher_code: voucherCode,
        payment_confirmed: true,
        site_code: siteCode,
      },
    ])
    .select()
    .single();

  if (saleError) {
    logDiagnosticError("POS SALE INSERT SALES ERROR", saleError);
    throw saleError;
  }

  bvDebug("POS SALE INSERT SALES RESULT", {
    request_id: requestId,
    sale_id: sale.id,
    voucher_code: voucherCode,
  });

  const accessPayload = {
    sale_id: sale.id,
    plan_code: product_name,
    code: voucherCode,
    minutes,
    duration_minutes: minutes,
    minutes_total: minutes,
    minutes_remaining: minutes,
    national_voucher: true,
    validation_mode: "central",
    purchase_source: "agent",
    amount,
    customer_name,
    customer_phone: cleanPhone || null,
    status: "unused",
    qr_code_url,
    sale_site_code: siteCode,
    notes:
      "Code national B&V Access numérique vendu par agent. Le code est le produit. Le client doit conserver son code.",
  };

  bvDebug("POS SALE INSERT ACCESS_CODES START", {
    request_id: requestId,
    sale_id: sale.id,
    code: voucherCode,
    plan_code: product_name,
    minutes,
    minutes_remaining: minutes,
    qr_present: Boolean(qr_code_url),
  });

  const { data: accessCode, error: accessError } = await supabase
    .from("access_codes")
    .insert([accessPayload])
    .select()
    .single();

  if (accessError) {
    logDiagnosticError("POS SALE INSERT ACCESS_CODES ERROR", accessError);
    throw accessError;
  }

  bvDebug("POS SALE INSERT ACCESS_CODES RESULT", {
    request_id: requestId,
    access_code_id: accessCode.id,
    code: voucherCode,
    status: accessCode.status,
  });

  const commissionRate = Number(agent.access_commission_percent || 10);
  const commissionAmount = Number(amount) * (commissionRate / 100);

  bvDebug("POS SALE INSERT COMMISSIONS START", {
    request_id: requestId,
    agent_id: agent.id,
    sale_id: sale.id,
    commission_rate: commissionRate,
    commission_amount: commissionAmount,
    site_code: siteCode,
  });

  const { data: commission, error: commissionError } = await supabase
    .from("commissions")
    .insert([
      {
        agent_id: agent.id,
        sale_id: sale.id,
        commission_type: "voucher_sale",
        commission_amount: commissionAmount,
        status: "pending",
        site_code: siteCode,
      },
    ])
    .select()
    .single();

  if (commissionError) {
    logDiagnosticError("POS SALE INSERT COMMISSIONS ERROR", commissionError);
    throw commissionError;
  }

  bvDebug("POS SALE INSERT COMMISSIONS RESULT", {
    request_id: requestId,
    commission_id: commission.id,
    commission_amount: commission.commission_amount,
    status: commission.status,
  });

  return {
    voucher_code: voucherCode,
    qr_code_url,
    portal_url,
    agent,
    sale,
    access_code: accessCode,
    commission,
  };
}

function getPosPlan(planKey) {
  const key = String(planKey || "").trim().toUpperCase();
  const plans = {
    PLAN10: {
      key: "PLAN10",
      display: "Plan Express",
      price: 10,
      minutes: 10,
    },
    PLAN30: {
      key: "PLAN30",
      display: "Plan Standard",
      price: 25,
      minutes: 30,
    },
    PLAN60: {
      key: "PLAN60",
      display: "Plan Heure",
      price: 50,
      minutes: 60,
    },
    PLAN180: {
      key: "PLAN180",
      display: "Plan Plus",
      price: 100,
      minutes: 180,
    },
    PLANNUIT: {
      key: "PLANNUIT",
      display: "Plan Nuit",
      price: 100,
      minutes: 720,
    },
    PLANNIGHT: {
      key: "PLANNUIT",
      display: "Plan Nuit",
      price: 100,
      minutes: 720,
    },
  };

  return plans[key] || null;
}

function isPosRequestAuthorized(req) {
  const token = getRequestAuthToken(req);
  const acceptedTokens = [
    process.env.BV_POS_API_KEY,
    process.env.POS_API_KEY,
    process.env.BV_AGENT_TOKEN,
    process.env.BV_INTERNAL_TOKEN,
  ]
    .map((value) => String(value || "").trim())
    .filter(Boolean);

  if (acceptedTokens.length === 0 && !PILOT_SECURITY_ENABLED) {
    return true;
  }

  return acceptedTokens.includes(token);
}

function getStartOfTodayIso() {
  const now = new Date();
  const today = new Date(now);

  today.setHours(0, 0, 0, 0);

  return today.toISOString();
}

function sumAmounts(rows, fieldName) {
  return (rows || []).reduce((sum, row) => {
    return sum + Number(row[fieldName] || 0);
  }, 0);
}

const MOBILE_ACCESS_PLANS = {
  PLAN10: {
    plan_code: "PLAN10",
    title: "Plan Express",
    price_gdes: 10,
    minutes: 10,
  },
  PLAN30: {
    plan_code: "PLAN30",
    title: "Plan Standard",
    price_gdes: 25,
    minutes: 30,
  },
  PLAN60: {
    plan_code: "PLAN60",
    title: "Plan Heure",
    price_gdes: 50,
    minutes: 60,
  },
  PLAN180: {
    plan_code: "PLAN180",
    title: "Plan Plus",
    price_gdes: 100,
    minutes: 180,
  },
  PLANNUIT: {
    plan_code: "PLANNUIT",
    title: "Plan Nuit",
    price_gdes: 100,
    minutes: 720,
  },
};

const MOBILE_PAYMENT_METHODS = [
  "cash",
  "agent_cash",
  "credit_card",
  "moncash",
  "natcash",
];

function getHaitiHour(date = new Date()) {
  try {
    const hourPart = new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      hourCycle: "h23",
      timeZone: HAITI_TIME_ZONE,
    })
      .formatToParts(date)
      .find((part) => part.type === "hour");
    const hour = Number(hourPart?.value);

    if (Number.isInteger(hour) && hour >= 0 && hour <= 23) {
      return hour;
    }
  } catch (error) {
    bvDebug("HAITI TIMEZONE FALLBACK", {
      error: error?.message || String(error),
    });
  }

  return (date.getUTCHours() - 4 + 24) % 24;
}

function isPlanAvailableNow(planCode, date = new Date()) {
  const normalized = String(planCode || "").trim().toUpperCase();

  if (!FIXED_WINDOW_PLAN_CODES.has(normalized)) {
    return true;
  }

  const haitiHour = getHaitiHour(date);
  return haitiHour >= 20 || haitiHour < 6;
}

function getPlanUnavailableMessage(planCode) {
  const normalized = String(planCode || "").trim().toUpperCase();

  if (FIXED_WINDOW_PLAN_CODES.has(normalized)) {
    return "Le Plan Nuit est disponible uniquement entre 20h00 et 06h00, heure d'Haïti.";
  }

  return "Ce plan n'est pas disponible actuellement.";
}

function mobilePlanToApi(plan, date = new Date()) {
  const available = isPlanAvailableNow(plan.plan_code, date);

  return {
    ...plan,
    available,
    unavailable_reason: available ? null : getPlanUnavailableMessage(plan.plan_code),
  };
}

function normalizeAccessPlanRow(row = {}) {
  const planCode = normalizePlanCode(row.plan_code || row.code);
  const minutes = Number(row.minutes || row.minutes_total || row.duration_minutes || 0);
  const priceGdes = Number(row.price_gdes || row.price || row.amount || 0);

  if (!planCode || !minutes || !priceGdes) return null;

  return {
    plan_code: planCode,
    title: row.title || row.plan_title || planCode,
    description: row.description || row.subtitle || null,
    price_gdes: priceGdes,
    minutes,
    active: row.active !== false && String(row.status || "active") !== "disabled",
    status: row.status || "active",
    site_codes: Array.isArray(row.site_codes) ? row.site_codes.map(normalizeSiteCode) : null,
  };
}

function accessPlanAppliesToSite(plan, siteCode = null) {
  const normalizedSiteCode = normalizeSiteCode(siteCode);

  if (!normalizedSiteCode || !Array.isArray(plan.site_codes) || plan.site_codes.length === 0) {
    return true;
  }

  return plan.site_codes.includes(normalizedSiteCode);
}

async function listMobilePlansFromSupabase(siteCode = null) {
  const { data, error } = await supabase
    .from("access_plans")
    .select("*")
    .order("price_gdes", { ascending: true });

  if (error) throw error;

  return (data || [])
    .map(normalizeAccessPlanRow)
    .filter(Boolean)
    .filter((plan) => plan.active)
    .filter((plan) => accessPlanAppliesToSite(plan, siteCode));
}

function getFallbackPublicSites() {
  return [
    {
      site_code: DEFAULT_SITE_CODE,
      site_name: "B&V Access Fort-Liberté",
      name: "B&V Access Fort-Liberté",
      city: "Fort-Liberté",
      department: "Nord-Est",
      status: "active",
      description: "Premier site officiel B&V Access.",
    },
  ];
}

function publicSiteFromRow(row = {}) {
  const siteCode = normalizeSiteCode(row.site_code || row.code || DEFAULT_SITE_CODE);

  return {
    site_code: siteCode,
    code: siteCode,
    site_name:
      row.site_name ||
      row.name ||
      row.display_name ||
      (siteCode === DEFAULT_SITE_CODE ? "B&V Access Fort-Liberté" : siteCode),
    name:
      row.site_name ||
      row.name ||
      row.display_name ||
      (siteCode === DEFAULT_SITE_CODE ? "B&V Access Fort-Liberté" : siteCode),
    city: row.city || row.commune || row.location || null,
    department: row.department || row.departement || null,
    zone: row.zone || null,
    address: row.address || row.full_address || null,
    latitude: row.latitude || row.lat || null,
    longitude: row.longitude || row.lng || row.lon || null,
    status: row.status || "active",
    description: row.description || "",
  };
}

function isMissingSupabaseTableError(error) {
  const message = String(error?.message || "").toLowerCase();

  return (
    error?.code === "42P01" ||
    error?.code === "PGRST204" ||
    error?.code === "PGRST205" ||
    message.includes("does not exist") ||
    message.includes("could not find the table") ||
    message.includes("could not find") && message.includes("column")
  );
}

function getAnnouncementSchemaErrorMessage(error) {
  const message = String(error?.message || "").toLowerCase();

  if (
    message.includes("image_url") ||
    message.includes("logo_url") ||
    message.includes("action_label") ||
    message.includes("cta_label") ||
    message.includes("cta_url") ||
    message.includes("advertiser_name") ||
    message.includes("site_id") ||
    message.includes("is_active") ||
    message.includes("category")
  ) {
    return "Colonnes publicitaires absentes. Exécutez bv-access-mobile/supabase/ad_banners.sql.";
  }

  return "Table Supabase announcements absente. Exécutez bv-access-mobile/supabase/announcements.sql.";
}

function normalizeStringArray(value) {
  if (Array.isArray(value)) {
    return value
      .map((item) => String(item || "").trim())
      .filter(Boolean);
  }

  if (typeof value === "string") {
    return value
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);
  }

  return [];
}

function normalizeAnnouncementRow(row = {}) {
  const siteCodes = normalizeStringArray(row.site_codes)
    .concat(row.site_id ? [row.site_id] : [])
    .map(normalizeSiteCode)
    .filter(Boolean);
  const placements = normalizeStringArray(row.placements);
  const active =
    row.active === undefined || row.active === null
      ? row.is_active !== false
      : row.active !== false;
  const linkUrl = row.link_url || row.cta_url || null;
  const actionLabel = row.action_label || row.cta_label || null;

  return {
    id: row.id,
    title: row.title || "",
    message: row.message || row.body || "",
    active,
    is_active: active,
    scope: row.scope === "local" ? "local" : "national",
    site_codes: siteCodes,
    site_id: row.site_id || siteCodes[0] || null,
    placements: placements.length > 0 ? placements : ["global"],
    priority: Number(row.priority || 100),
    starts_at: row.starts_at || null,
    ends_at: row.ends_at || null,
    link_url: linkUrl,
    cta_url: row.cta_url || linkUrl,
    whatsapp: row.whatsapp || null,
    phone: row.phone || null,
    category: row.category === "commercial" ? "commercial" : "institutional",
    image_url: row.image_url || null,
    image_path: row.image_path || null,
    image_mime_type: row.image_mime_type || null,
    logo_url: row.logo_url || null,
    logo_path: row.logo_path || null,
    action_label: actionLabel,
    cta_label: row.cta_label || actionLabel,
    advertiser_name: row.advertiser_name || null,
    created_by: row.created_by || null,
    created_at: row.created_at || null,
    updated_at: row.updated_at || null,
    archived_at: row.archived_at || null,
  };
}

function announcementMatchesSite(announcement, siteCode) {
  if (announcement.scope !== "local") return true;

  const normalizedSiteCode = normalizeSiteCode(siteCode || DEFAULT_SITE_CODE);
  if (!normalizedSiteCode) return false;

  return announcement.site_codes.includes(normalizedSiteCode);
}

function announcementMatchesPlacement(announcement, placement) {
  const normalizedPlacement = String(placement || "global").trim();
  const placements = announcement.placements;

  return (
    placements.includes("global") ||
    placements.includes(normalizedPlacement)
  );
}

function announcementIsCurrent(announcement, now = new Date()) {
  const nowMs = now.getTime();
  const startsAt = announcement.starts_at ? new Date(announcement.starts_at).getTime() : null;
  const endsAt = announcement.ends_at ? new Date(announcement.ends_at).getTime() : null;

  if (announcement.archived_at) return false;
  if (!announcement.active) return false;
  if (startsAt && Number.isFinite(startsAt) && startsAt > nowMs) return false;
  if (endsAt && Number.isFinite(endsAt) && endsAt < nowMs) return false;

  return true;
}

function announcementToPublicPayload(row) {
  const announcement = normalizeAnnouncementRow(row);

  return {
    id: announcement.id,
    title: announcement.title,
    message: announcement.message,
    active: announcement.active,
    is_active: announcement.is_active,
    scope: announcement.scope,
    site_codes: announcement.site_codes,
    site_id: announcement.site_id,
    placements: announcement.placements,
    priority: announcement.priority,
    starts_at: announcement.starts_at,
    ends_at: announcement.ends_at,
    link_url: announcement.link_url,
    cta_url: announcement.cta_url,
    whatsapp: announcement.whatsapp,
    phone: announcement.phone,
    category: announcement.category,
    image_url: announcement.image_url,
    image_path: announcement.image_path,
    image_mime_type: announcement.image_mime_type,
    logo_url: announcement.logo_url,
    logo_path: announcement.logo_path,
    action_label: announcement.action_label,
    cta_label: announcement.cta_label,
    advertiser_name: announcement.advertiser_name,
    created_at: announcement.created_at,
    updated_at: announcement.updated_at,
  };
}

function hasOwnDefinedValue(object, key) {
  return Object.prototype.hasOwnProperty.call(object || {}, key);
}

function assignAnnouncementOptionalField(payload, body, existing, outputKey, bodyKeys) {
  const keys = Array.isArray(bodyKeys) ? bodyKeys : [bodyKeys];
  const bodyKey = keys.find((key) => hasOwnDefinedValue(body, key));

  if (bodyKey) {
    payload[outputKey] = String(body[bodyKey] ?? "").trim() || null;
    return;
  }

  if (hasOwnDefinedValue(existing, outputKey)) {
    payload[outputKey] = existing[outputKey] || null;
  }
}

function buildAnnouncementWritePayload(body = {}, existing = {}) {
  const nextScope = body.scope === "local" ? "local" : (existing.scope || "national");
  const siteCodes = normalizeStringArray(body.site_codes ?? body.siteCodes ?? existing.site_codes)
    .map(normalizeSiteCode)
    .filter(Boolean);
  const placements = normalizeStringArray(body.placements ?? existing.placements);
  const active =
    body.active === undefined && body.is_active === undefined && body.isActive === undefined
      ? existing.active !== false && existing.is_active !== false
      : parseBoolean(body.active ?? body.is_active ?? body.isActive) ||
        body.active === true ||
        body.is_active === true ||
        body.isActive === true;
  const linkUrl =
    String(
      body.link_url ??
        body.linkUrl ??
        body.cta_url ??
        body.ctaUrl ??
        existing.link_url ??
        existing.cta_url ??
        ""
    ).trim() || null;
  const actionLabel =
    String(
      body.action_label ??
        body.actionLabel ??
        body.cta_label ??
        body.ctaLabel ??
        existing.action_label ??
        existing.cta_label ??
        ""
    ).trim() || null;
  const siteId =
    String(
      body.site_id ??
        body.siteId ??
        existing.site_id ??
        (nextScope === "local" ? siteCodes[0] : "") ??
        ""
    ).trim() || null;

  const payload = {
    title: String(body.title ?? existing.title ?? "").trim() || null,
    message: String(body.message ?? body.body ?? existing.message ?? "").trim(),
    active,
    is_active: active,
    scope: nextScope,
    site_codes: nextScope === "local" ? siteCodes : [],
    site_id: nextScope === "local" ? siteId : null,
    placements: placements.length > 0 ? placements : ["global"],
    priority: Number.isFinite(Number(body.priority ?? existing.priority))
      ? Number(body.priority ?? existing.priority)
      : 100,
    starts_at: body.starts_at ?? body.startsAt ?? existing.starts_at ?? null,
    ends_at: body.ends_at ?? body.endsAt ?? existing.ends_at ?? null,
    link_url: linkUrl,
    cta_url: linkUrl,
    whatsapp: String(body.whatsapp ?? existing.whatsapp ?? "").trim() || null,
    phone: String(body.phone ?? existing.phone ?? "").trim() || null,
    action_label: actionLabel,
    cta_label: actionLabel,
    updated_at: new Date().toISOString(),
  };

  if (hasOwnDefinedValue(body, "category") || hasOwnDefinedValue(existing, "category")) {
    const category = hasOwnDefinedValue(body, "category") ? body.category : existing.category;
    payload.category = category === "commercial"
      ? "commercial"
      : "institutional";
  }

  assignAnnouncementOptionalField(payload, body, existing, "image_url", ["image_url", "imageUrl"]);
  assignAnnouncementOptionalField(payload, body, existing, "image_path", ["image_path", "imagePath"]);
  assignAnnouncementOptionalField(payload, body, existing, "image_mime_type", ["image_mime_type", "imageMimeType"]);
  assignAnnouncementOptionalField(payload, body, existing, "logo_url", ["logo_url", "logoUrl"]);
  assignAnnouncementOptionalField(payload, body, existing, "logo_path", ["logo_path", "logoPath"]);
  assignAnnouncementOptionalField(payload, body, existing, "action_label", ["action_label", "actionLabel", "cta_label", "ctaLabel"]);
  payload.cta_label = payload.action_label || null;
  assignAnnouncementOptionalField(payload, body, existing, "advertiser_name", ["advertiser_name", "advertiserName"]);

  return payload;
}

function getAgentPrivilegedAccessMinutes() {
  const configured = Number(
    process.env.BV_AGENT_PRIVILEGED_ACCESS_MINUTES ||
      process.env.AGENT_PRIVILEGED_ACCESS_MINUTES ||
      10080
  );

  return Math.max(60, Math.ceil(configured || 10080));
}

function normalizePrivilegedDeviceRow(row = {}) {
  return {
    id: row.id || null,
    agent_user_id: row.agent_user_id || null,
    agent_code: String(row.agent_code || "").trim(),
    agent_name: row.agent_name || "",
    agent_phone: row.agent_phone || "",
    site_code: normalizeSiteCode(row.site_code || DEFAULT_SITE_CODE),
    device_label: row.device_label || "",
    mac_address: normalizeMac(row.mac_address) || row.mac_address || "",
    status: row.status || "active",
    authorized_at: row.authorized_at || null,
    last_seen_at: row.last_seen_at || null,
    last_authorized_at: row.last_authorized_at || null,
    suspended_at: row.suspended_at || null,
    revoked_at: row.revoked_at || null,
    revoked_by: row.revoked_by || null,
    replaced_by_device_id: row.replaced_by_device_id || null,
    notes: row.notes || "",
    unifi_result: row.unifi_result || null,
    created_by: row.created_by || null,
    created_at: row.created_at || null,
    updated_at: row.updated_at || null,
  };
}

function privilegedDeviceToPublicPayload(row = {}) {
  return normalizePrivilegedDeviceRow(row);
}

function buildPrivilegedDeviceWritePayload(body = {}, agentProfile = {}) {
  const macAddress = normalizeMac(
    body.mac_address || body.macAddress || body.mac || body.client_mac || body.clientMac
  );
  const siteCode = normalizeSiteCode(
    body.site_code || body.siteCode || agentProfile.site_code || DEFAULT_SITE_CODE
  );

  return {
    agent_user_id: agentProfile.id || body.agent_user_id || body.agentUserId || null,
    agent_code: String(
      agentProfile.agent_code || body.agent_code || body.agentCode || ""
    ).trim(),
    agent_name: String(
      agentProfile.full_name || body.agent_name || body.agentName || ""
    ).trim() || null,
    agent_phone: normalizePhone(
      agentProfile.phone || body.agent_phone || body.agentPhone || body.phone || ""
    ) || null,
    site_code: siteCode,
    device_label: String(body.device_label || body.deviceLabel || "").trim() || null,
    mac_address: macAddress,
    notes: String(body.notes || "").trim() || null,
  };
}

async function findAgentProfileForPrivilegedAccess(body = {}) {
  const agentUserId = String(body.agent_user_id || body.agentUserId || "").trim();
  const agentCode = String(body.agent_code || body.agentCode || "").trim();

  let query = supabase
    .from("user_profiles")
    .select("id, full_name, phone, role, site_code, agent_code, active");

  if (agentUserId) {
    query = query.eq("id", agentUserId);
  } else if (agentCode) {
    query = query.eq("agent_code", agentCode);
  } else {
    return {
      profile: null,
      error: "agent_user_id ou agent_code est obligatoire.",
      status: 400,
    };
  }

  const { data, error } = await query.limit(1).maybeSingle();

  if (error) {
    return {
      profile: null,
      error: "Lecture du profil agent impossible.",
      status: 500,
      diagnostic: diagnosticErrorPayload(error),
    };
  }

  if (!data) {
    return {
      profile: null,
      error: "Agent introuvable.",
      status: 404,
    };
  }

  const role = String(data.role || "").trim();

  if (role !== "agent") {
    return {
      profile: null,
      error: "Le profil sélectionné n'est pas un agent.",
      status: 400,
    };
  }

  if (data.active === false) {
    return {
      profile: null,
      error: "Agent suspendu ou inactif.",
      status: 409,
    };
  }

  if (!data.agent_code) {
    return {
      profile: null,
      error: "Code agent manquant dans user_profiles.",
      status: 409,
    };
  }

  return { profile: data, error: null, status: 200 };
}

async function revokePrivilegedDevice(device, actorUserId = null, reason = "revoked") {
  return await setPrivilegedDeviceStatus(device, "revoked", actorUserId, reason);
}

async function suspendPrivilegedDevice(device, actorUserId = null, reason = "suspended") {
  return await setPrivilegedDeviceStatus(device, "suspended", actorUserId, reason);
}

async function setPrivilegedDeviceStatus(
  device,
  status,
  actorUserId = null,
  reason = status
) {
  const normalizedDevice = normalizePrivilegedDeviceRow(device);
  const siteConfig = await getUnifiSiteConfig(normalizedDevice.site_code);
  const unifiResult = await unauthorizeClient(normalizedDevice.mac_address, siteConfig);
  const nowIso = new Date().toISOString();
  const statusPayload = {
    status,
    revoked_by: actorUserId || null,
    notes: [normalizedDevice.notes, reason].filter(Boolean).join(" | ") || null,
    unifi_result: unifiResult,
    updated_at: nowIso,
  };

  if (status === "revoked") {
    statusPayload.revoked_at = nowIso;
  }

  if (status === "suspended") {
    statusPayload.suspended_at = nowIso;
  }

  const { data, error } = await supabase
    .from("agent_privileged_devices")
    .update(statusPayload)
    .eq("id", normalizedDevice.id)
    .select("*")
    .single();

  if (error) throw error;

  return {
    device: privilegedDeviceToPublicPayload(data),
    unifi: unifiResult,
  };
}

function isMissingSupabaseColumnError(error) {
  const message = String(error?.message || "").toLowerCase();

  return (
    error?.code === "PGRST204" ||
    (message.includes("could not find the") &&
      message.includes("column") &&
      message.includes("schema cache"))
  );
}

function sendMobilePaymentError(res, error, label) {
  logDiagnosticError(label, error);

  if (isMissingSupabaseTableError(error)) {
    return res.status(503).json({
      success: false,
      error:
        "Tables Supabase mobile payment non créées. Appliquez d'abord la migration mobile_payment_reservations.sql.",
      sql_file: "bv-access-mobile/supabase/mobile_payment_reservations.sql",
      diagnostic: diagnosticErrorPayload(error),
    });
  }

  if (isMissingSupabaseColumnError(error)) {
    return res.status(500).json({
      success: false,
      error:
        "Schéma Supabase incomplet pour les réservations mobiles. Une colonne attendue par l'API est absente.",
      diagnostic: diagnosticErrorPayload(error),
    });
  }

  return res.status(500).json({
    success: false,
    error: error.message,
    diagnostic: diagnosticErrorPayload(error),
  });
}

function getStaticMobilePlan(planCode) {
  return MOBILE_ACCESS_PLANS[String(planCode || "").toUpperCase()] || null;
}

async function getMobilePlan(planCode) {
  const staticPlan = getStaticMobilePlan(planCode);

  if (staticPlan) return staticPlan;

  try {
    const { data, error } = await supabase
      .from("access_plans")
      .select("*")
      .eq("plan_code", normalizePlanCode(planCode))
      .eq("active", true)
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    return normalizeAccessPlanRow(data);
  } catch (error) {
    if (!isMissingSupabaseTableError(error)) {
      logDiagnosticError("MOBILE PLAN LOOKUP ERROR", error);
    }
  }

  return null;
}

function normalizeMobilePaymentMethod(method) {
  const normalized = String(method || "cash").toLowerCase();
  return MOBILE_PAYMENT_METHODS.includes(normalized) ? normalized : null;
}

function normalizeMobilePaymentStatus(status) {
  const normalized = String(status || "pending").toLowerCase();
  if (["pending", "paid", "failed", "refunded", "cancelled"].includes(normalized)) {
    return normalized;
  }

  if (normalized === "reserved") return "pending";
  return "pending";
}

function normalizeMobileReservationStatus(status, paymentMethod) {
  const normalized = String(status || "").toLowerCase();

  if (
    [
      "payment_pending",
      "agent_confirmation_required",
      "payment_confirmed",
      "voucher_generated",
      "cancelled",
      "expired",
    ].includes(normalized)
  ) {
    return normalized;
  }

  return ["cash", "agent_cash"].includes(paymentMethod)
    ? "agent_confirmation_required"
    : "payment_pending";
}

function generateMobileReservationReference() {
  return `MPR-${Date.now()}-${crypto.randomInt(1000, 10000)}`;
}

async function validateMobileReservationBody(body) {
  const plan = await getMobilePlan(body.plan_code || body.planCode);
  const paymentMethod = normalizeMobilePaymentMethod(
    body.payment_method || body.paymentMethod
  );
  const priceGdes = Number(body.price_gdes ?? body.priceGdes ?? plan?.price_gdes);
  const minutesTotal = Number(
    body.minutes_total ?? body.minutesTotal ?? plan?.minutes
  );

  if (!plan) {
    throw new Error("Plan mobile invalide");
  }

  if (!isPlanAvailableNow(plan.plan_code)) {
    throw new Error(getPlanUnavailableMessage(plan.plan_code));
  }

  if (!paymentMethod) {
    throw new Error("Mode de paiement mobile invalide");
  }

  if (!priceGdes || priceGdes <= 0) {
    throw new Error("Prix GDES invalide");
  }

  if (!minutesTotal || minutesTotal <= 0) {
    throw new Error("Minutes invalides");
  }

  return {
    plan,
    paymentMethod,
    priceGdes,
    minutesTotal,
  };
}

async function buildMobileReservationPayload(body) {
  const {
    plan,
    paymentMethod,
    priceGdes,
    minutesTotal,
  } = await validateMobileReservationBody(body);
  const reference = String(
    body.reference || body.id || generateMobileReservationReference()
  ).trim();
  const paymentStatus = normalizeMobilePaymentStatus(
    body.payment_status || body.paymentStatus
  );
  const reservationStatus = normalizeMobileReservationStatus(
    body.reservation_status || body.status,
    paymentMethod
  );
  const commissionRate = Number(body.commission_rate ?? 0.1);

  if (!reference) {
    throw new Error("Référence réservation obligatoire");
  }

  return {
    reference,
    client_user_id: body.client_user_id || body.clientUserId || null,
    agent_user_id: body.agent_user_id || body.agentUserId || null,
    site_code: body.site_code || body.siteCode || DEFAULT_SITE_CODE,
    plan_code: plan.plan_code,
    plan_title: body.plan_title || body.planTitle || plan.title,
    price_gdes: priceGdes,
    minutes_total: minutesTotal,
    payment_method: paymentMethod,
    payment_status: paymentStatus,
    reservation_status: reservationStatus,
    commission_rate: commissionRate,
    commission_gdes: Number(body.commission_gdes ?? priceGdes * commissionRate),
    commission_status: body.commission_status || "pending",
    customer_name: body.customer_name || body.customerName || null,
    customer_phone: normalizePhone(body.customer_phone || body.customerPhone || ""),
    customer_email: body.customer_email || body.customerEmail || null,
    metadata: body.metadata || {},
    created_at: body.created_at || body.createdAt || new Date().toISOString(),
    paid_at: body.paid_at || body.paidAt || null,
  };
}

async function fetchMobileReservationByReference(reference) {
  const { data, error } = await supabase
    .from("mobile_payment_reservations")
    .select("*")
    .eq("reference", reference)
    .limit(1)
    .maybeSingle();

  return { reservation: data, error };
}

function providerForMobilePaymentMethod(paymentMethod) {
  if (paymentMethod === "moncash") return "moncash";
  if (paymentMethod === "natcash") return "natcash";
  if (paymentMethod === "credit_card") return "card_processor";
  if (paymentMethod === "agent_cash" || paymentMethod === "cash") {
    return "agent_cash";
  }

  return "manual";
}

function buildMobileVoucherResponse(accessCode, reservation, req = null) {
  const qr = decorateVoucherQr(accessCode, req);

  return {
    code: accessCode.code,
    planCode: accessCode.plan_code,
    planTitle: reservation.plan_title,
    status: accessCode.status || "unused",
    source: "api",
    paymentStatus: "paid",
    paymentMethod: reservation.payment_method,
    paymentMethodLabel: getMobilePaymentMethodLabel(reservation.payment_method),
    priceGdes: Number(accessCode.amount || reservation.price_gdes || 0),
    minutesTotal: Number(
      accessCode.minutes_total ||
        accessCode.minutes ||
        accessCode.duration_minutes ||
        reservation.minutes_total ||
        0
    ),
    minutesRemaining: Number(accessCode.minutes_remaining || 0),
    siteCode:
      accessCode.sale_site_code ||
      reservation.site_code ||
      DEFAULT_SITE_CODE,
    siteName: reservation.site_code || "B&V Access",
    qrValue: qr.portal_url || accessCode.code,
    qrCodeUrl: qr.qr_code_url,
    portalUrl: qr.portal_url,
    createdAt: accessCode.created_at || new Date().toISOString(),
  };
}

function getMobilePaymentMethodLabel(paymentMethod) {
  const labels = {
    cash: "Cash",
    agent_cash: "Cash agent",
    credit_card: "Carte de crédit",
    moncash: "MonCash",
    natcash: "NatCash",
  };

  return labels[paymentMethod] || "Cash";
}

app.get("/", (req, res) => {
  res.status(200).send("BV Access API is running");
});

function getPortalHtmlCandidates() {
  return [
    path.join(__dirname, "public", "portal.html"),
    path.join(process.cwd(), "public", "portal.html"),
  ].filter((candidate, index, all) => all.indexOf(candidate) === index);
}

function getPortalHtmlPath() {
  return getPortalHtmlCandidates().find((candidate) => {
    try {
      return fs.existsSync(candidate);
    } catch {
      return false;
    }
  });
}

function serveCaptivePortal(req, res) {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  res.setHeader("Expires", "0");
  const portalPath = getPortalHtmlPath();

  if (!portalPath) {
    return res.status(500).json({
      success: false,
      error: "portal.html introuvable sur le serveur B&V Access.",
      server_build: SERVER_BUILD,
      cwd: process.cwd(),
      dirname: __dirname,
      candidates: getPortalHtmlCandidates().map((candidate) => ({
        path: candidate,
        exists: fs.existsSync(candidate),
      })),
    });
  }

  res.sendFile(portalPath);
}

app.get(["/portal", "/portal/"], serveCaptivePortal);
app.get(["/portal.html", "/portal.html/"], serveCaptivePortal);
app.get(/^\/guest\/s\/[^/]+(?:\/.*)?$/, serveCaptivePortal);

app.get("/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "BV Access API healthy",
    mode: "national_voucher_numeric_code_with_admin_pro_dashboard_phase",
    server_build: SERVER_BUILD,
    regional_node_code: REGIONAL_NODE_CODE,
    default_site_code: DEFAULT_SITE_CODE,
  });
});

app.get("/diagnostics/portal-file", dashboardRateLimiter, (req, res) => {
  const selectedPath = getPortalHtmlPath();
  const candidates = getPortalHtmlCandidates().map((candidate) => {
    let stat = null;

    try {
      stat = fs.statSync(candidate);
    } catch {
      stat = null;
    }

    return {
      path: candidate,
      exists: Boolean(stat),
      is_file: Boolean(stat?.isFile?.()),
      size_bytes: stat?.size || null,
      modified_at: stat?.mtime?.toISOString?.() || null,
    };
  });

  res.status(200).json({
    success: Boolean(selectedPath),
    server_build: SERVER_BUILD,
    cwd: process.cwd(),
    dirname: __dirname,
    selected_path: selectedPath || null,
    candidates,
  });
});

app.get("/portal-config", validateAccessRateLimiter, async (req, res) => {
  try {
    const context = await resolveRegionalSiteContext(req, req.query.site_code || req.query.siteCode);
    const siteConfig = context.site_config || {};
    const portalHost = getSitePortalHost(siteConfig);
    const portalPort = getSitePortalPort(siteConfig);
    const portalBaseUrl = buildPortalBaseUrl(portalHost, portalPort);
    const unifiSite = getUnifiSiteName(siteConfig);

    res.status(200).json({
      success: true,
      server_build: SERVER_BUILD,
      regional_node_code: REGIONAL_NODE_CODE,
      default_site_code: DEFAULT_SITE_CODE,
      site_code: context.site_code,
      source: context.source,
      client_ip: context.client_ip || null,
      display_name: siteConfig.display_name || context.site_code,
      controller_name: siteConfig.controller_name || null,
      unifi_site: unifiSite,
      unifi_host_configured: Boolean(siteConfig.unifi_host),
      portal_host: portalHost || null,
      portal_port: portalPort || null,
      portal_base_url: portalBaseUrl,
      portal_html_url: portalBaseUrl ? `${portalBaseUrl}/portal.html` : null,
      guest_portal_url: portalBaseUrl
        ? `${portalBaseUrl}/guest/s/${encodeURIComponent(unifiSite)}`
        : null,
      guest_subnets: getSiteSubnetsFromConfig(siteConfig),
      environment_hint:
        context.source === "default_site_fallback"
          ? "No explicit site_code or subnet match was found; using default fallback site."
          : null,
    });
  } catch (error) {
    logDiagnosticError("/portal-config ERROR", error);
    res.status(200).json({
      success: true,
      fallback: true,
      server_build: SERVER_BUILD,
      regional_node_code: REGIONAL_NODE_CODE,
      default_site_code: DEFAULT_SITE_CODE,
      site_code: DEFAULT_SITE_CODE,
      source: "error_default_site_fallback",
      error: error.message,
    });
  }
});

app.get("/api/plans", async (req, res) => {
  const now = new Date();
  const siteCode = normalizeSiteCode(req.query.site_code || "");
  let source = "fallback";
  let rawPlans = Object.values(MOBILE_ACCESS_PLANS);

  try {
    const supabasePlans = await listMobilePlansFromSupabase(siteCode);

    if (supabasePlans.length > 0) {
      rawPlans = supabasePlans;
      source = "supabase";
    }
  } catch (error) {
    if (!isMissingSupabaseTableError(error)) {
      logDiagnosticError("/api/plans SUPABASE ERROR", error);
    }
  }

  const plans = rawPlans.map((plan) => mobilePlanToApi(plan, now));

  res.status(200).json({
    success: true,
    source,
    timezone: HAITI_TIME_ZONE,
    haiti_hour: getHaitiHour(now),
    site_code: siteCode || null,
    plans,
    active_plans: plans.filter((plan) => plan.available),
  });
});

app.get("/api/sites", async (req, res) => {
  try {
    const includeInactive = parseBoolean(req.query.include_inactive);
    let query = supabase
      .from("sites")
      .select("*")
      .order("created_at", { ascending: false });

    if (!includeInactive) {
      query = query.in("status", ["active", "preparation", "coming_soon"]);
    }

    const { data, error } = await query;

    if (error) throw error;

    const sites = (data && data.length > 0 ? data : getFallbackPublicSites())
      .map(publicSiteFromRow)
      .filter((site) => includeInactive || site.status !== "out_of_service");

    res.status(200).json({
      success: true,
      default_site_code: DEFAULT_SITE_CODE,
      sites,
    });
  } catch (error) {
    if (isMissingSupabaseTableError(error)) {
      return res.status(200).json({
        success: true,
        fallback: true,
        default_site_code: DEFAULT_SITE_CODE,
        sites: getFallbackPublicSites().map(publicSiteFromRow),
        warning: "Table Supabase sites indisponible; fallback local utilisé.",
      });
    }

    logDiagnosticError("/api/sites ERROR", error);
    res.status(500).json({
      success: false,
      error: "Chargement des sites impossible.",
      diagnostic: diagnosticErrorPayload(error),
    });
  }
});

app.get("/api/announcements", async (req, res) => {
  const siteCode = normalizeSiteCode(req.query.site_code || req.query.siteCode || DEFAULT_SITE_CODE);
  const placement = String(req.query.placement || "global").trim() || "global";
  const limit = Math.min(Math.max(Number(req.query.limit || 3), 1), 10);

  try {
    const { data, error } = await supabase
      .from("announcements")
      .select("*")
      .is("archived_at", null)
      .order("priority", { ascending: true })
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) throw error;

    const announcements = (data || [])
      .map(normalizeAnnouncementRow)
      .filter((announcement) => announcementIsCurrent(announcement))
      .filter((announcement) => announcementMatchesSite(announcement, siteCode))
      .filter((announcement) => announcementMatchesPlacement(announcement, placement))
      .slice(0, limit)
      .map(announcementToPublicPayload);

    res.status(200).json({
      success: true,
      source: "supabase",
      site_code: siteCode,
      placement,
      announcements,
    });
  } catch (error) {
    if (isMissingSupabaseTableError(error)) {
      return res.status(200).json({
        success: true,
        fallback: true,
        site_code: siteCode,
        placement,
        announcements: [],
        warning:
          "Table Supabase announcements indisponible; appliquez announcements.sql pour activer la barre dynamique.",
      });
    }

    logDiagnosticError("/api/announcements ERROR", error);
    res.status(500).json({
      success: false,
      error: "Chargement des annonces impossible.",
      diagnostic: diagnosticErrorPayload(error),
    });
  }
});

app.get(
  "/admin/announcements",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const siteCode = normalizeSiteCode(req.query.site_code || req.query.siteCode || "");
      const includeArchived = parseBoolean(req.query.include_archived);
      let query = supabase
        .from("announcements")
        .select("*")
        .order("priority", { ascending: true })
        .order("created_at", { ascending: false })
        .limit(100);

      if (!includeArchived) query = query.is("archived_at", null);

      const { data, error } = await query;
      if (error) throw error;

      const announcements = (data || [])
        .map(normalizeAnnouncementRow)
        .filter((announcement) => !siteCode || announcementMatchesSite(announcement, siteCode))
        .map(announcementToPublicPayload);

      res.status(200).json({
        success: true,
        announcements,
      });
    } catch (error) {
      if (isMissingSupabaseTableError(error)) {
        return res.status(503).json({
          success: false,
          error: getAnnouncementSchemaErrorMessage(error),
          diagnostic: diagnosticErrorPayload(error),
        });
      }

      logDiagnosticError("/admin/announcements GET ERROR", error);
      res.status(500).json({
        success: false,
        error: "Lecture admin des annonces impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.post(
  "/admin/announcements",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const payload = buildAnnouncementWritePayload(req.body || {});

      if (!payload.message) {
        return res.status(400).json({
          success: false,
          error: "Le texte de l'annonce est obligatoire.",
        });
      }

      if (payload.scope === "local" && payload.site_codes.length === 0) {
        return res.status(400).json({
          success: false,
          error: "Une annonce locale doit cibler au moins un site.",
        });
      }

      const { data, error } = await supabase
        .from("announcements")
        .insert({
          ...payload,
          created_by: req.bvAuth?.userId || null,
        })
        .select("*")
        .single();

      if (error) throw error;

      res.status(201).json({
        success: true,
        announcement: announcementToPublicPayload(data),
      });
    } catch (error) {
      logDiagnosticError("/admin/announcements POST ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? getAnnouncementSchemaErrorMessage(error)
          : "Création de l'annonce impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.patch(
  "/admin/announcements/:id",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const announcementId = String(req.params.id || "").trim();

      if (!announcementId) {
        return res.status(400).json({
          success: false,
          error: "Identifiant annonce manquant.",
        });
      }

      const { data: existing, error: existingError } = await supabase
        .from("announcements")
        .select("*")
        .eq("id", announcementId)
        .maybeSingle();

      if (existingError) throw existingError;

      if (!existing) {
        return res.status(404).json({
          success: false,
          error: "Annonce introuvable.",
        });
      }

      const payload = buildAnnouncementWritePayload(req.body || {}, existing);

      if (!payload.message) {
        return res.status(400).json({
          success: false,
          error: "Le texte de l'annonce est obligatoire.",
        });
      }

      if (payload.scope === "local" && payload.site_codes.length === 0) {
        return res.status(400).json({
          success: false,
          error: "Une annonce locale doit cibler au moins un site.",
        });
      }

      if (req.body?.archived === true || parseBoolean(req.body?.archived)) {
        payload.archived_at = new Date().toISOString();
      }

      const { data, error } = await supabase
        .from("announcements")
        .update(payload)
        .eq("id", announcementId)
        .select("*")
        .single();

      if (error) throw error;

      res.status(200).json({
        success: true,
        announcement: announcementToPublicPayload(data),
      });
    } catch (error) {
      logDiagnosticError("/admin/announcements PATCH ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? getAnnouncementSchemaErrorMessage(error)
          : "Modification de l'annonce impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.delete(
  "/admin/announcements/:id",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const announcementId = String(req.params.id || "").trim();

      if (!announcementId) {
        return res.status(400).json({
          success: false,
          error: "Identifiant annonce manquant.",
        });
      }

      const { data: existing, error: existingError } = await supabase
        .from("announcements")
        .select("*")
        .eq("id", announcementId)
        .maybeSingle();

      if (existingError) throw existingError;

      if (!existing) {
        return res.status(404).json({
          success: false,
          error: "Annonce introuvable.",
        });
      }

      const { data, error } = await supabase
        .from("announcements")
        .update({
          active: false,
          is_active: false,
          archived_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq("id", announcementId)
        .select("*")
        .single();

      if (error) throw error;

      res.status(200).json({
        success: true,
        announcement: announcementToPublicPayload(data),
      });
    } catch (error) {
      logDiagnosticError("/admin/announcements DELETE ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? getAnnouncementSchemaErrorMessage(error)
          : "Suppression de l'annonce impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.get(
  "/admin/agent-profiles",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      let query = supabase
        .from("user_profiles")
        .select("id, full_name, phone, role, site_code, agent_code, active")
        .eq("role", "agent")
        .order("full_name", { ascending: true });

      const siteCode = normalizeSiteCode(req.query.site_code || req.query.siteCode || "");
      if (siteCode) query = query.eq("site_code", siteCode);

      const { data, error } = await query;
      if (error) throw error;

      res.status(200).json({
        success: true,
        agents: (data || []).map((agent) => ({
          id: agent.id,
          full_name: agent.full_name || agent.agent_code || "Agent B&V",
          phone: agent.phone || "",
          role: agent.role,
          site_code: normalizeSiteCode(agent.site_code || DEFAULT_SITE_CODE),
          agent_code: agent.agent_code || "",
          active: agent.active !== false,
        })),
      });
    } catch (error) {
      logDiagnosticError("/admin/agent-profiles ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? "Table Supabase user_profiles absente."
          : "Lecture des agents impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.get(
  "/admin/agent-privileged-devices",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      let query = supabase
        .from("agent_privileged_devices")
        .select("*")
        .order("updated_at", { ascending: false })
        .limit(250);

      const siteCode = normalizeSiteCode(req.query.site_code || req.query.siteCode || "");
      const status = String(req.query.status || "").trim();
      if (siteCode) query = query.eq("site_code", siteCode);
      if (status) query = query.eq("status", status);

      const { data, error } = await query;
      if (error) throw error;

      const devices = (data || []).map(privilegedDeviceToPublicPayload);

      res.status(200).json({
        success: true,
        devices,
        privileged_access_minutes: getAgentPrivilegedAccessMinutes(),
      });
    } catch (error) {
      logDiagnosticError("/admin/agent-privileged-devices GET ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? "Table Supabase agent_privileged_devices absente. Exécutez agent_privileged_devices.sql."
          : "Lecture des accès privilégiés impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.post(
  "/admin/agent-privileged-devices/authorize",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const { profile, error, status, diagnostic } =
        await findAgentProfileForPrivilegedAccess(req.body || {});

      if (error) {
        return res.status(status || 400).json({
          success: false,
          error,
          diagnostic,
        });
      }

      const payload = buildPrivilegedDeviceWritePayload(req.body || {}, profile);

      if (!payload.mac_address) {
        return res.status(400).json({
          success: false,
          error: "Adresse MAC invalide ou manquante.",
        });
      }

      if (!payload.site_code) {
        return res.status(400).json({
          success: false,
          error: "Site obligatoire pour autoriser l'appareil agent.",
        });
      }

      const { data: activeForMac, error: macLookupError } = await supabase
        .from("agent_privileged_devices")
        .select("*")
        .eq("status", "active")
        .eq("site_code", payload.site_code)
        .eq("mac_address", payload.mac_address)
        .maybeSingle();

      if (macLookupError) throw macLookupError;

      if (activeForMac && activeForMac.agent_code !== payload.agent_code) {
        return res.status(409).json({
          success: false,
          error:
            "Cette adresse MAC est déjà autorisée pour un autre agent sur ce site.",
          device: privilegedDeviceToPublicPayload(activeForMac),
        });
      }

      const { data: existingActive, error: activeLookupError } = await supabase
        .from("agent_privileged_devices")
        .select("*")
        .eq("agent_code", payload.agent_code)
        .eq("status", "active")
        .limit(1)
        .maybeSingle();

      if (activeLookupError) throw activeLookupError;

      const replacingDifferentDevice =
        existingActive &&
        (normalizeMac(existingActive.mac_address) !== payload.mac_address ||
          normalizeSiteCode(existingActive.site_code) !== payload.site_code);

      let replacedDevice = null;
      if (replacingDifferentDevice) {
        replacedDevice = await revokePrivilegedDevice(
          existingActive,
          req.bvAuth?.userId || null,
          "Remplacé par un nouvel appareil privilégié agent"
        );
      }

      const siteConfig = await getUnifiSiteConfig(payload.site_code);
      const unifiResult = await authorizeClient(
        payload.mac_address,
        getAgentPrivilegedAccessMinutes(),
        siteConfig
      );
      const nowIso = new Date().toISOString();
      let savedDevice;

      if (existingActive && !replacingDifferentDevice) {
        const { data, error: updateError } = await supabase
          .from("agent_privileged_devices")
          .update({
            ...payload,
            status: "active",
            last_authorized_at: nowIso,
            authorized_at: existingActive.authorized_at || nowIso,
            suspended_at: null,
            revoked_at: null,
            revoked_by: null,
            unifi_result: unifiResult,
            updated_at: nowIso,
          })
          .eq("id", existingActive.id)
          .select("*")
          .single();

        if (updateError) throw updateError;
        savedDevice = data;
      } else {
        const { data, error: insertError } = await supabase
          .from("agent_privileged_devices")
          .insert({
            ...payload,
            status: "active",
            authorized_at: nowIso,
            last_authorized_at: nowIso,
            created_by: req.bvAuth?.userId || null,
            unifi_result: unifiResult,
          })
          .select("*")
          .single();

        if (insertError) throw insertError;
        savedDevice = data;
      }

      if (replacedDevice?.device?.id && savedDevice?.id) {
        await supabase
          .from("agent_privileged_devices")
          .update({ replaced_by_device_id: savedDevice.id })
          .eq("id", replacedDevice.device.id);
      }

      res.status(201).json({
        success: true,
        device: privilegedDeviceToPublicPayload(savedDevice),
        replaced_device: replacedDevice?.device || null,
        unifi: unifiResult,
      });
    } catch (error) {
      logDiagnosticError("/admin/agent-privileged-devices AUTHORIZE ERROR", error);
      const statusCode = isMissingSupabaseTableError(error)
        ? 503
        : error?.code === "23505"
          ? 409
          : 500;

      res.status(statusCode).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? "Table Supabase agent_privileged_devices absente. Exécutez agent_privileged_devices.sql."
          : error?.code === "23505"
            ? "Un agent ne peut avoir qu'un seul appareil privilégié actif."
            : "Autorisation de l'appareil agent impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.patch(
  "/admin/agent-privileged-devices/:id/suspend",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const deviceId = String(req.params.id || "").trim();
      const { data: device, error } = await supabase
        .from("agent_privileged_devices")
        .select("*")
        .eq("id", deviceId)
        .maybeSingle();

      if (error) throw error;
      if (!device) {
        return res.status(404).json({ success: false, error: "Appareil introuvable." });
      }

      const result = await suspendPrivilegedDevice(
        device,
        req.bvAuth?.userId || null,
        req.body?.reason || "Accès agent suspendu par Admin"
      );

      res.status(200).json({ success: true, ...result });
    } catch (error) {
      logDiagnosticError("/admin/agent-privileged-devices SUSPEND ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? "Table Supabase agent_privileged_devices absente."
          : "Suspension de l'accès agent impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.patch(
  "/admin/agent-privileged-devices/:id/revoke",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const deviceId = String(req.params.id || "").trim();
      const { data: device, error } = await supabase
        .from("agent_privileged_devices")
        .select("*")
        .eq("id", deviceId)
        .maybeSingle();

      if (error) throw error;
      if (!device) {
        return res.status(404).json({ success: false, error: "Appareil introuvable." });
      }

      const result = await revokePrivilegedDevice(
        device,
        req.bvAuth?.userId || null,
        req.body?.reason || "Accès agent révoqué par Admin"
      );

      res.status(200).json({ success: true, ...result });
    } catch (error) {
      logDiagnosticError("/admin/agent-privileged-devices REVOKE ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? "Table Supabase agent_privileged_devices absente."
          : "Révocation de l'accès agent impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.patch(
  "/admin/agent-privileged-devices/:id/reactivate",
  dashboardRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["admin_bv"]),
  async (req, res) => {
    try {
      const deviceId = String(req.params.id || "").trim();
      const { data: device, error } = await supabase
        .from("agent_privileged_devices")
        .select("*")
        .eq("id", deviceId)
        .maybeSingle();

      if (error) throw error;
      if (!device) {
        return res.status(404).json({ success: false, error: "Appareil introuvable." });
      }

      const { profile, error: profileError, status, diagnostic } =
        await findAgentProfileForPrivilegedAccess({
          agent_user_id: device.agent_user_id,
          agent_code: device.agent_code,
        });

      if (profileError) {
        return res.status(status || 400).json({
          success: false,
          error: profileError,
          diagnostic,
        });
      }

      const normalizedDevice = normalizePrivilegedDeviceRow(device);
      const { data: existingActive, error: activeLookupError } = await supabase
        .from("agent_privileged_devices")
        .select("*")
        .eq("agent_code", normalizedDevice.agent_code)
        .eq("status", "active")
        .neq("id", normalizedDevice.id)
        .limit(1)
        .maybeSingle();

      if (activeLookupError) throw activeLookupError;

      let replacedDevice = null;
      if (existingActive) {
        replacedDevice = await revokePrivilegedDevice(
          existingActive,
          req.bvAuth?.userId || null,
          "Remplacé pendant la réactivation d'un appareil agent"
        );
      }

      const siteConfig = await getUnifiSiteConfig(normalizedDevice.site_code);
      const unifiResult = await authorizeClient(
        normalizedDevice.mac_address,
        getAgentPrivilegedAccessMinutes(),
        siteConfig
      );
      const nowIso = new Date().toISOString();

      const { data, error: updateError } = await supabase
        .from("agent_privileged_devices")
        .update({
          status: "active",
          agent_user_id: profile.id,
          agent_name: profile.full_name || device.agent_name || null,
          agent_phone: normalizePhone(profile.phone || device.agent_phone || "") || null,
          site_code: normalizeSiteCode(device.site_code || profile.site_code || DEFAULT_SITE_CODE),
          suspended_at: null,
          revoked_at: null,
          revoked_by: null,
          last_authorized_at: nowIso,
          authorized_at: device.authorized_at || nowIso,
          unifi_result: unifiResult,
          updated_at: nowIso,
        })
        .eq("id", normalizedDevice.id)
        .select("*")
        .single();

      if (updateError) throw updateError;

      res.status(200).json({
        success: true,
        device: privilegedDeviceToPublicPayload(data),
        replaced_device: replacedDevice?.device || null,
        unifi: unifiResult,
      });
    } catch (error) {
      logDiagnosticError("/admin/agent-privileged-devices REACTIVATE ERROR", error);
      res.status(isMissingSupabaseTableError(error) ? 503 : 500).json({
        success: false,
        error: isMissingSupabaseTableError(error)
          ? "Table Supabase agent_privileged_devices absente."
          : "Réactivation de l'accès agent impossible.",
        diagnostic: diagnosticErrorPayload(error),
      });
    }
  }
);

app.all("/diagnostics/mac", validateAccessRateLimiter, (req, res) => {
  const requestId = buildRequestId("macdiag");
  const requestDebug = buildRequestDebugPayload(req);
  const candidates = getMacCandidatesFromRequest(req);
  const selected = candidates.find((candidate) => candidate.normalized) || null;

  bvDebug("/diagnostics/mac RESULT", {
    request_id: requestId,
    method: req.method,
    path: req.originalUrl,
    ip: req.ip,
    user_agent: req.headers["user-agent"] || null,
    referer: req.headers.referer || null,
    origin: req.headers.origin || null,
    selected,
    candidates,
    request_debug: requestDebug,
  });

  res.status(200).json({
    success: true,
    request_id: requestId,
    mac_detected: Boolean(selected),
    mac_address: selected?.normalized || null,
    mac_source: selected?.source || null,
    candidates,
    ip_candidates: requestDebug.ip_candidates,
    query: req.query || {},
    body: req.body || {},
    headers: requestDebug.headers,
    cookies: requestDebug.cookies,
    request_debug: requestDebug,
    server_build: SERVER_BUILD,
  });
});

app.get("/diagnostics/unifi-site", validateAccessRateLimiter, async (req, res) => {
  const requestId = buildRequestId("unifisite");
  const requestedSiteCode = normalizeSiteCode(req.query.site_code || DEFAULT_SITE_CODE);
  const siteConfig = await getUnifiSiteConfig(requestedSiteCode);
  const configuredSite = getUnifiSiteName(siteConfig);

  try {
    const { baseUrl, cookie } = await unifiLogin(siteConfig);
    const endpoints = [
      "/proxy/network/api/self/sites",
      "/proxy/network/api/stat/sites",
    ];
    const results = [];

    for (const endpoint of endpoints) {
      const response = await fetch(`${baseUrl}${endpoint}`, {
        headers: {
          Accept: "application/json, text/plain, */*",
          Cookie: cookie,
          Origin: baseUrl,
          Referer: `${baseUrl}/network/${encodeURIComponent(configuredSite)}/`,
        },
      });
      const text = await response.text();
      let json = null;

      try {
        json = text ? JSON.parse(text) : null;
      } catch {
        json = null;
      }

      results.push({
        endpoint,
        status: response.status,
        ok: response.ok,
        json,
        preview: text.slice(0, 500),
      });
    }

    const sites = results
      .flatMap((result) => result.json?.data || [])
      .map((site) => ({
        name: site.name || null,
        desc: site.desc || site.description || null,
        role: site.role || null,
        site_id: site._id || site.site_id || null,
      }))
      .filter((site, index, all) => {
        if (!site.name) return false;
        return all.findIndex((item) => item.name === site.name) === index;
      });

    bvDebug("/diagnostics/unifi-site RESULT", {
      request_id: requestId,
      site_code: requestedSiteCode,
      controller_name: siteConfig.controller_name,
      unifi_host: getUnifiBaseUrl(siteConfig),
      configured_site: configuredSite,
      site_names: sites.map((site) => site.name),
      endpoints: results.map((result) => ({
        endpoint: result.endpoint,
        status: result.status,
        ok: result.ok,
      })),
    });

    res.status(200).json({
      success: true,
      request_id: requestId,
      site_code: requestedSiteCode,
      controller_name: siteConfig.controller_name,
      unifi_host: getUnifiBaseUrl(siteConfig),
      configured_site: configuredSite,
      site_confirmed: sites.some((site) => site.name === configuredSite),
      sites,
      results,
      server_build: SERVER_BUILD,
    });
  } catch (error) {
    logDiagnosticError("/diagnostics/unifi-site ERROR", error);

    res.status(500).json({
      success: false,
      request_id: requestId,
      site_code: requestedSiteCode,
      controller_name: siteConfig.controller_name,
      unifi_host: getUnifiBaseUrl(siteConfig),
      configured_site: configuredSite,
      error: userFacingUniFiError(error),
      diagnostic: diagnosticErrorPayload(error),
      server_build: SERVER_BUILD,
    });
  }
});

app.get("/diagnostics/unifi-client", validateAccessRateLimiter, async (req, res) => {
  const requestId = buildRequestId("unificlient");
  const siteCode = normalizeSiteCode(req.query.site_code || DEFAULT_SITE_CODE);
  const mac = normalizeMac(req.query.mac || req.query.id || req.query.client_mac);

  if (!mac) {
    return res.status(400).json({
      success: false,
      request_id: requestId,
      error: "Paramètre mac obligatoire",
      server_build: SERVER_BUILD,
    });
  }

  try {
    const siteConfig = await getUnifiSiteConfig(siteCode);
    const client_state = await getUniFiClientState(mac, siteConfig);

    res.status(200).json({
      success: true,
      request_id: requestId,
      site_code: siteCode,
      mac_address: mac,
      client_state,
      server_build: SERVER_BUILD,
    });
  } catch (error) {
    logDiagnosticError("/diagnostics/unifi-client ERROR", error);

    res.status(500).json({
      success: false,
      request_id: requestId,
      site_code: siteCode,
      mac_address: mac,
      error: userFacingUniFiError(error),
      diagnostic: diagnosticErrorPayload(error),
      server_build: SERVER_BUILD,
    });
  }
});

app.get("/diagnostics/unifi-portal", validateAccessRateLimiter, async (req, res) => {
  const requestId = buildRequestId("unifiportal");
  const siteCode = normalizeSiteCode(req.query.site_code || DEFAULT_SITE_CODE);

  try {
    const siteConfig = await getUnifiSiteConfig(siteCode);
    const expected = getExternalPortalExpectedConfig(siteConfig);
    const { setting, source, endpoints, candidates } =
      await fetchUniFiGuestAccessSetting(siteConfig);

    if (!setting) {
      return res.status(404).json({
        success: false,
        request_id: requestId,
        site_code: siteCode,
        error: "Configuration UniFi guest_access introuvable.",
        endpoints,
        expected,
        server_build: SERVER_BUILD,
      });
    }

    const observed = summarizeUniFiGuestAccess(setting);
    const validation = buildUniFiPortalValidation(candidates, expected);

    console.log("UNIFI PORTAL DIAGNOSTIC", {
      request_id: requestId,
      site_code: siteCode,
      source,
      expected,
      observed_summary: observed.summary,
      validation,
    });

    res.status(200).json({
      success: true,
      request_id: requestId,
      site_code: siteCode,
      controller_name: siteConfig.controller_name,
      unifi_host: getUnifiBaseUrl(siteConfig),
      unifi_site: getUnifiSiteName(siteConfig),
      source,
      endpoints,
      expected,
      observed,
      validation,
      representations: validation.representations,
      stale_portal_references: validation.stale_portal_references,
      compliant: validation.success,
      mismatches: validation.mismatches,
      server_build: SERVER_BUILD,
    });
  } catch (error) {
    logDiagnosticError("/diagnostics/unifi-portal ERROR", error);

    res.status(500).json({
      success: false,
      request_id: requestId,
      site_code: siteCode,
      error: userFacingUniFiError(error),
      diagnostic: diagnosticErrorPayload(error),
      server_build: SERVER_BUILD,
    });
  }
});

app.post(
  "/admin/unifi-portal/apply",
  dashboardRateLimiter,
  requireInternalAuth(["admin_bv"]),
  async (req, res) => {
    const requestId = buildRequestId("unifiportalapply");
    const siteCode = normalizeSiteCode(
      req.body?.site_code || req.query.site_code || DEFAULT_SITE_CODE
    );

    try {
      const siteConfig = await getUnifiSiteConfig(siteCode);
      const expected = {
        ...getExternalPortalExpectedConfig(siteConfig),
        external_portal_host: String(
          req.body?.external_portal_host ||
            req.body?.custom_ip ||
            getSitePortalHost(siteConfig)
        )
          .trim()
          .replace(/^https?:\/\//i, "")
          .replace(/[:/].*$/, ""),
        external_portal_port: Number(
          req.body?.external_portal_port || getSitePortalPort(siteConfig)
        ),
      };
      const expectedPortalBaseUrl = buildPortalBaseUrl(
        expected.external_portal_host,
        expected.external_portal_port
      );
      expected.expected_unifi_external_portal_value = expected.external_portal_host;
      expected.expected_client_portal_url = `${expectedPortalBaseUrl}/guest/s/${encodeURIComponent(
        getUnifiSiteName(siteConfig)
      )}`;
      expected.expected_portal_html_url = `${expectedPortalBaseUrl}/portal.html`;
      expected.expected_auth = String(
        req.body?.external_portal_auth || expected.expected_auth || "custom"
      )
        .trim()
        .toLowerCase();

      const before = await fetchUniFiGuestAccessSetting(siteConfig);

      if (!before.setting) {
        return res.status(404).json({
          success: false,
          request_id: requestId,
          site_code: siteCode,
          error: "Configuration UniFi guest_access introuvable; application impossible.",
          expected,
          endpoints: before.endpoints,
          server_build: SERVER_BUILD,
        });
      }

      const payload = buildExternalPortalGuestAccessPayload(before.setting, expected);
      const beforeValidation = buildUniFiPortalValidation(before.candidates || [], expected);

      console.log("UNIFI PORTAL APPLY START", {
        request_id: requestId,
        site_code: siteCode,
        unifi_host: getUnifiBaseUrl(siteConfig),
        unifi_site: getUnifiSiteName(siteConfig),
        expected,
        before: summarizeUniFiGuestAccess(before.setting).summary,
        before_validation: beforeValidation,
        payload: summarizeUniFiGuestAccess(payload).summary,
      });

      const applyResults = [];
      const applyResult = await applyUniFiGuestAccessSetting(siteConfig, payload);
      applyResults.push({
        endpoint: applyResult.url,
        method: applyResult.method,
        status: applyResult.status,
        ok: applyResult.ok,
        response: applyResult.json || applyResult.text?.slice(0, 1000) || null,
      });

      try {
        const restApplyResult = await applyUniFiGuestAccessSetting(siteConfig, payload, {
          forceRest: true,
        });

        applyResults.push({
          endpoint: restApplyResult.url,
          method: restApplyResult.method,
          status: restApplyResult.status,
          ok: restApplyResult.ok,
          response:
            restApplyResult.json || restApplyResult.text?.slice(0, 1000) || null,
        });
      } catch (restApplyError) {
        console.warn("UNIFI PORTAL REST APPLY FAILED", {
          request_id: requestId,
          site_code: siteCode,
          message: restApplyError.message,
          status: restApplyError.status || null,
        });
        applyResults.push({
          endpoint: "rest/setting/guest_access",
          method: "PUT",
          status: restApplyError.status || null,
          ok: false,
          error: restApplyError.message,
          response: restApplyError.response_json || restApplyError.response_text || null,
        });
      }

      let after = await fetchUniFiGuestAccessSetting(siteConfig);

      if (!after.setting) {
        return res.status(502).json({
          success: false,
          request_id: requestId,
          site_code: siteCode,
          error:
            "UniFi a accepté la requête, mais guest_access reste introuvable après application.",
          apply_result: {
            endpoint: applyResult.url,
            method: applyResult.method,
            status: applyResult.status,
            ok: applyResult.ok,
            response: applyResult.json || applyResult.text?.slice(0, 1000) || null,
          },
          apply_results: applyResults,
          server_build: SERVER_BUILD,
        });
      }

      let observed = summarizeUniFiGuestAccess(after.setting);
      let validation = buildUniFiPortalValidation(after.candidates || [], expected);

      if (
        validation.mismatches.some((mismatch) =>
          [
            "redirect_enabled",
            "redirect_url",
            "portal_use_hostname",
            "portal_hostname",
            "stale_portal_references",
          ].includes(mismatch.key)
        )
      ) {
        console.warn("UNIFI PORTAL CLEANUP SECOND PASS START", {
          request_id: requestId,
          site_code: siteCode,
          validation,
        });

        try {
          const secondRestApplyResult = await applyUniFiGuestAccessSetting(
            siteConfig,
            payload,
            {
              forceRest: true,
            }
          );

          applyResults.push({
            endpoint: secondRestApplyResult.url,
            method: secondRestApplyResult.method,
            status: secondRestApplyResult.status,
            ok: secondRestApplyResult.ok,
            response:
              secondRestApplyResult.json ||
              secondRestApplyResult.text?.slice(0, 1000) ||
              null,
          });
        } catch (secondRestApplyError) {
          console.warn("UNIFI PORTAL SECOND REST APPLY FAILED", {
            request_id: requestId,
            site_code: siteCode,
            message: secondRestApplyError.message,
            status: secondRestApplyError.status || null,
          });
          applyResults.push({
            endpoint: "rest/setting/guest_access",
            method: "PUT",
            status: secondRestApplyError.status || null,
            ok: false,
            error: secondRestApplyError.message,
            response:
              secondRestApplyError.response_json ||
              secondRestApplyError.response_text ||
              null,
          });
        }

        after = await fetchUniFiGuestAccessSetting(siteConfig);

        if (!after.setting) {
          return res.status(502).json({
            success: false,
            request_id: requestId,
            site_code: siteCode,
            error:
              "UniFi a accepté le nettoyage REST, mais guest_access reste introuvable après application.",
            apply_results: applyResults,
            server_build: SERVER_BUILD,
          });
        }

        observed = summarizeUniFiGuestAccess(after.setting);
        validation = buildUniFiPortalValidation(after.candidates || [], expected);
      }

      console.log("UNIFI PORTAL APPLY RESULT", {
        request_id: requestId,
        site_code: siteCode,
        apply_status: applyResult.status,
        apply_ok: applyResult.ok,
        after: observed.summary,
        validation,
      });

      res.status(200).json({
        success: validation.success,
        request_id: requestId,
        site_code: siteCode,
        controller_name: siteConfig.controller_name,
        unifi_host: getUnifiBaseUrl(siteConfig),
        unifi_site: getUnifiSiteName(siteConfig),
        expected,
        apply_result: {
          endpoint: applyResult.url,
          method: applyResult.method,
          status: applyResult.status,
          ok: applyResult.ok,
          response: applyResult.json || applyResult.text?.slice(0, 1000) || null,
        },
        apply_results: applyResults,
        before: summarizeUniFiGuestAccess(before.setting),
        before_validation: beforeValidation,
        after: observed,
        validation,
        representations: validation.representations,
        stale_portal_references: validation.stale_portal_references,
        compliant: validation.success,
        mismatches: validation.mismatches,
        server_build: SERVER_BUILD,
      });
    } catch (error) {
      logDiagnosticError("/admin/unifi-portal/apply ERROR", error);

      res.status(500).json({
        success: false,
        request_id: requestId,
        site_code: siteCode,
        error: userFacingUniFiError(error),
        diagnostic: diagnosticErrorPayload(error),
        server_build: SERVER_BUILD,
      });
    }
  }
);

app.get("/diagnostics/capacity", dashboardRateLimiter, async (req, res) => {
  try {
    const includeLiveCounts = parseBoolean(req.query.live_counts);
    let activeSessionsCount = null;
    let configuredSitesCount = null;

    if (includeLiveCounts) {
      const { count: sessionCount, error: sessionCountError } = await supabase
        .from("access_sessions")
        .select("id", { count: "exact", head: true })
        .eq("status", "active");

      if (sessionCountError) throw sessionCountError;
      activeSessionsCount = sessionCount;

      const { count: siteCount, error: siteCountError } = await supabase
        .from("unifi_sites")
        .select("id", { count: "exact", head: true })
        .eq("active", true);

      if (!siteCountError) {
        configuredSitesCount = siteCount;
      }
    }

    res.status(200).json({
      success: true,
      server_build: SERVER_BUILD,
      system: getSystemCapacitySnapshot(),
      thresholds: getCapacityThresholds(),
      worker: lastSessionWorkerMetrics,
      live_counts: includeLiveCounts
        ? {
            active_sessions: activeSessionsCount,
            configured_unifi_sites: configuredSitesCount,
          }
        : null,
      recommended_poll_ms: getSessionPresencePollMs(),
      worker_batch_size: getSessionWorkerBatchSize(),
    });
  } catch (error) {
    logDiagnosticError("/diagnostics/capacity ERROR", error);

    res.status(500).json({
      success: false,
      error: error.message,
      diagnostic: diagnosticErrorPayload(error),
      server_build: SERVER_BUILD,
    });
  }
});

app.get("/diagnostics/regional-node", dashboardRateLimiter, async (req, res) => {
  try {
    const includeInactive = parseBoolean(req.query.include_inactive);
    let sites = [];
    let source = "supabase";

    try {
      let query = supabase
        .from("unifi_sites")
        .select("*")
        .order("site_code", { ascending: true });

      if (!includeInactive) {
        query = query.eq("active", true);
      }

      const { data, error } = await query;

      if (error) throw error;

      sites = (data || [])
        .filter((row) => {
          const nodeCode = normalizeSiteCode(row.regional_node_code || row.node_code || "");
          return !nodeCode || nodeCode === REGIONAL_NODE_CODE || includeInactive;
        })
        .map((row) => {
          const config = normalizeUnifiSiteConfig(row, row.site_code);
          const portalHost = getSitePortalHost(config);
          const portalPort = getSitePortalPort(config);
          const portalBaseUrl = buildPortalBaseUrl(portalHost, portalPort);
          const unifiSite = getUnifiSiteName(config);

          return {
            site_code: config.site_code,
            display_name: config.display_name,
            controller_name: config.controller_name,
            regional_node_code: config.regional_node_code,
            active: config.active,
            unifi_host: config.unifi_host,
            unifi_site: config.unifi_site,
            username_present: Boolean(config.unifi_username),
            password_present: Boolean(config.unifi_password),
            verify_ssl: config.verify_ssl,
            vpn_type: config.vpn_type,
            vpn_address: config.vpn_address,
            portal_host: portalHost,
            portal_port: portalPort,
            portal_base_url: portalBaseUrl,
            portal_html_url: portalBaseUrl ? `${portalBaseUrl}/portal.html` : null,
            guest_portal_url: portalBaseUrl
              ? `${portalBaseUrl}/guest/s/${encodeURIComponent(unifiSite)}`
              : null,
            guest_subnets: getSiteSubnetsFromConfig(config),
          };
        });
    } catch (error) {
      if (!isMissingUnifiSitesTableError(error)) throw error;

      source = "env_fallback";
      sites = [getDefaultUnifiSiteConfig(DEFAULT_SITE_CODE)].map((config) => ({
        site_code: config.site_code,
        display_name: config.display_name,
        controller_name: config.controller_name,
        regional_node_code: config.regional_node_code,
        active: config.active,
        unifi_host: config.unifi_host,
        unifi_site: config.unifi_site,
        username_present: Boolean(config.unifi_username),
        password_present: Boolean(config.unifi_password),
        verify_ssl: config.verify_ssl,
        vpn_type: config.vpn_type,
        vpn_address: config.vpn_address,
        portal_host: getSitePortalHost(config),
        portal_port: getSitePortalPort(config),
        portal_base_url: buildPortalBaseUrl(
          getSitePortalHost(config),
          getSitePortalPort(config)
        ),
        portal_html_url: `${buildPortalBaseUrl(
          getSitePortalHost(config),
          getSitePortalPort(config)
        )}/portal.html`,
        guest_portal_url: `${buildPortalBaseUrl(
          getSitePortalHost(config),
          getSitePortalPort(config)
        )}/guest/s/${encodeURIComponent(getUnifiSiteName(config))}`,
        guest_subnets: getSiteSubnetsFromConfig(config),
      }));
    }

    res.status(200).json({
      success: true,
      server_build: SERVER_BUILD,
      regional_node_code: REGIONAL_NODE_CODE,
      default_site_code: DEFAULT_SITE_CODE,
      source,
      site_count: sites.length,
      sites,
      worker: lastSessionWorkerMetrics
        ? {
            started_at: lastSessionWorkerMetrics.started_at,
            finished_at: lastSessionWorkerMetrics.finished_at,
            duration_ms: lastSessionWorkerMetrics.duration_ms,
            active_sessions: lastSessionWorkerMetrics.active_sessions,
            site_count: lastSessionWorkerMetrics.site_count,
            warnings: lastSessionWorkerMetrics.warnings,
          }
        : null,
    });
  } catch (error) {
    logDiagnosticError("/diagnostics/regional-node ERROR", error);

    res.status(500).json({
      success: false,
      error: error.message,
      diagnostic: diagnosticErrorPayload(error),
      server_build: SERVER_BUILD,
      regional_node_code: REGIONAL_NODE_CODE,
    });
  }
});

app.get("/generate", async (req, res) => {
  try {
    const fakeOrder = {
      name: "TEST",
      total_price: 25,
      email: "test@email.com",
      phone: "+50900000000",
      payment_gateway_names: ["cash"],
      line_items: [
        {
          title: "Plan Standard 30 min",
        },
      ],
      billing_address: {
        name: "Client Test",
        phone: "+50900000000",
      },
    };

    const result = await createAccessCodeFromOrder(fakeOrder, req);

    res.status(200).json({
      success: true,
      message: "NATIONAL B&V numeric voucher generated",
      ...result,
    });
  } catch (error) {
    console.error("GENERATE ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.post(
  "/agent-sale",
  saleRateLimiter,
  requireInternalAuth(["agent", "admin_bv"]),
  enforceAgentScope,
  async (req, res) => {
  try {
    const {
      agent_code,
      customer_name,
      customer_phone,
      product_name,
      amount,
      minutes,
      payment_method,
    } = req.body;

    if (!agent_code || !product_name || !amount || !minutes) {
      return res.status(400).json({
        success: false,
        error: "Champs obligatoires manquants",
      });
    }

    const result = await createAgentSale({
      agent_code,
      customer_name,
      customer_phone,
      product_name,
      amount: Number(amount),
      minutes: Number(minutes),
      payment_method: payment_method || "cash",
    }, req);

    res.status(200).json({
      success: true,
      message: "Agent sale created successfully",
      print_page: "https://bv-access-api.onrender.com/code/latest",
      ...result,
    });
  } catch (error) {
    console.error("AGENT SALE ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);

app.post("/api/pos/sale", saleRateLimiter, async (req, res) => {
  const requestId = buildRequestId("possale");
  req.bvPosRequestId = requestId;

  try {
    bvDebug("/api/pos/sale ENTER", {
      request_id: requestId,
      method: req.method,
      path: req.originalUrl,
      ip: req.ip,
      body: {
        plan_key: req.body?.plan_key || null,
        agent_code_present: Boolean(req.body?.agent_code),
        payment_method: req.body?.payment_method || null,
        amount_present: req.body?.amount !== undefined,
        minutes_present: req.body?.minutes !== undefined,
      },
      token_present: Boolean(getRequestAuthToken(req)),
    });

    const posAuthorized = isPosRequestAuthorized(req);

    bvDebug("/api/pos/sale AUTH RESULT", {
      request_id: requestId,
      authorized: posAuthorized,
      token_present: Boolean(getRequestAuthToken(req)),
      pilot_security_enabled: PILOT_SECURITY_ENABLED,
    });

    if (!posAuthorized) {
      return res.status(401).json({
        success: false,
        request_id: requestId,
        message: "POS non autorisé",
        error: "POS non autorisé",
      });
    }

    bvDebug("/api/pos/sale PLAN RECEIVED", {
      request_id: requestId,
      raw_plan_key: req.body?.plan_key || null,
    });

    const plan = getPosPlan(req.body?.plan_key);

    if (!plan) {
      return res.status(400).json({
        success: false,
        request_id: requestId,
        message: "Plan POS invalide",
        error: "Plan POS invalide",
        received_plan_key: req.body?.plan_key || null,
      });
    }

    if (!isPlanAvailableNow(plan.key)) {
      const unavailableMessage = getPlanUnavailableMessage(plan.key);

      bvDebug("/api/pos/sale PLAN UNAVAILABLE", {
        request_id: requestId,
        plan_key: plan.key,
        haiti_hour: getHaitiHour(),
        message: unavailableMessage,
      });

      return res.status(400).json({
        success: false,
        request_id: requestId,
        message: unavailableMessage,
        error: unavailableMessage,
        plan_key: plan.key,
        timezone: HAITI_TIME_ZONE,
      });
    }

    const agentCode =
      req.body?.agent_code ||
      process.env.BV_AGENT_CODE ||
      process.env.POS_AGENT_CODE ||
      "BV-AGENT-001";

    bvDebug("/api/pos/sale CREATE AGENT SALE START", {
      request_id: requestId,
      plan,
      agent_code: agentCode,
      amount: Number(req.body?.amount || plan.price),
      minutes: Number(req.body?.minutes || plan.minutes),
      payment_method: req.body?.payment_method || "cash",
    });

    const result = await createAgentSale({
      agent_code: agentCode,
      customer_name: req.body?.customer_name || "Client POS",
      customer_phone: req.body?.customer_phone || "",
      product_name: plan.key,
      amount: Number(req.body?.amount || plan.price),
      minutes: Number(req.body?.minutes || plan.minutes),
      payment_method: req.body?.payment_method || "cash",
    }, req);

    bvDebug("/api/pos/sale RESULT", {
      request_id: requestId,
      success: true,
      code: result.voucher_code,
      sale_id: result.sale?.id || null,
      access_code_id: result.access_code?.id || null,
      commission_id: result.commission?.id || null,
      qr_present: Boolean(result.qr_code_url),
    });

    res.status(200).json({
      success: true,
      request_id: requestId,
      message: "Voucher généré par POS",
      plan,
      voucher: {
        code: result.voucher_code,
        status: result.access_code?.status || "unused",
        qr_code_url: result.qr_code_url,
        portal_url: result.portal_url,
      },
      ...result,
    });
  } catch (error) {
    logDiagnosticError("/api/pos/sale ERROR COMPLETE", error);
    console.error("POS SALE ERROR:", error.message);

    res.status(500).json({
      success: false,
      request_id: requestId,
      message: error.message || "Erreur POS inconnue",
      error: error.message || "Erreur POS inconnue",
      diagnostic: diagnosticErrorPayload(error),
    });
  }
});

app.post(
  "/mobile-payment-reservations",
  paymentRateLimiter,
  requireSupabaseUserOrInternal,
  async (req, res) => {
  try {
    bvDebug("MOBILE PAYMENT RESERVATION ENTER", {
      body_keys: Object.keys(req.body || {}),
      plan_code: req.body?.plan_code || req.body?.planCode || null,
      payment_method: req.body?.payment_method || req.body?.paymentMethod || null,
      site_code: req.body?.site_code || req.body?.siteCode || null,
      auth_role: req.bvAuth?.role || null,
      auth_user_id: req.bvAuth?.userId || null,
      auth_site_code: req.bvAuth?.siteCode || null,
    });

    const payload = await buildMobileReservationPayload(req.body || {});

    if (PILOT_SECURITY_ENABLED && req.bvAuth) {
      if (req.bvAuth.role === "client") {
        payload.client_user_id = req.bvAuth.userId || null;
        payload.agent_user_id = null;
      }

      if (req.bvAuth.role === "agent") {
        payload.agent_user_id = req.bvAuth.userId || null;
        payload.site_code = req.bvAuth.siteCode || payload.site_code;
      }

      if (req.bvAuth.role === "site_owner") {
        payload.site_code = req.bvAuth.siteCode || payload.site_code;
      }
    }

    bvDebug("MOBILE PAYMENT RESERVATION CREATE", {
      reference: payload.reference,
      plan_code: payload.plan_code,
      payment_method: payload.payment_method,
      site_code: payload.site_code,
      reservation_status: payload.reservation_status,
      payment_status: payload.payment_status,
      payload_keys: Object.keys(payload),
    });

    const { data, error } = await supabase
      .from("mobile_payment_reservations")
      .insert([payload])
      .select()
      .single();

    if (error) {
      if (error.code === "23505") {
        return res.status(409).json({
          success: false,
          error: "Réservation mobile déjà existante",
          reference: payload.reference,
        });
      }

      logDiagnosticError("MOBILE PAYMENT RESERVATION SUPABASE INSERT ERROR", error);
      throw error;
    }

    bvDebug("MOBILE PAYMENT RESERVATION CREATED", {
      reference: data?.reference || payload.reference,
      id: data?.id || null,
      plan_code: data?.plan_code || payload.plan_code,
      status: data?.reservation_status || payload.reservation_status,
    });

    res.status(201).json({
      success: true,
      reservation: data,
    });
  } catch (error) {
    const validationMessages = [
      "Plan mobile invalide",
      "Mode de paiement mobile invalide",
      "Prix GDES invalide",
      "Minutes invalides",
      "Référence réservation obligatoire",
    ];

    if (
      validationMessages.includes(error.message) ||
      String(error.message || "").includes("Plan Nuit est disponible")
    ) {
      return res.status(400).json({
        success: false,
        error: error.message,
        received: {
          plan_code: req.body?.plan_code || req.body?.planCode || null,
          payment_method: req.body?.payment_method || req.body?.paymentMethod || null,
          price_gdes: req.body?.price_gdes ?? req.body?.priceGdes ?? null,
          minutes_total: req.body?.minutes_total ?? req.body?.minutesTotal ?? null,
          site_code: req.body?.site_code || req.body?.siteCode || null,
        },
      });
    }

    return sendMobilePaymentError(
      res,
      error,
      "MOBILE PAYMENT RESERVATION CREATE ERROR"
    );
  }
  }
);

app.get(
  "/mobile-payment-reservations",
  paymentRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["client", "agent", "site_owner", "admin_bv"]),
  async (req, res) => {
  try {
    let query = supabase
      .from("mobile_payment_reservations")
      .select("*")
      .order("created_at", { ascending: false });

    if (req.query.status) {
      query = query.eq("reservation_status", String(req.query.status));
    }

    if (req.query.payment_status) {
      query = query.eq("payment_status", String(req.query.payment_status));
    }

    if (req.query.site_code) {
      query = query.eq("site_code", String(req.query.site_code));
    }

    if (req.query.agent_user_id) {
      query = query.eq("agent_user_id", String(req.query.agent_user_id));
    }

    if (req.query.client_user_id) {
      query = query.eq("client_user_id", String(req.query.client_user_id));
    }

    if (PILOT_SECURITY_ENABLED && req.bvAuth?.role === "client") {
      query = query.eq("client_user_id", req.bvAuth.userId);
    } else if (PILOT_SECURITY_ENABLED && req.bvAuth?.role !== "admin_bv") {
      const scopedSiteCode = String(req.bvAuth?.siteCode || "").trim();

      if (!scopedSiteCode) {
        return res.status(403).json({
          success: false,
          error: "Aucun site autorisé pour cette session interne.",
        });
      }

      query = query.eq("site_code", scopedSiteCode);
    }

    const limit = Math.min(Number(req.query.limit || 50), 200);
    const { data, error } = await query.limit(limit);

    if (error) throw error;

    res.status(200).json({
      success: true,
      reservations: data || [],
    });
  } catch (error) {
    return sendMobilePaymentError(
      res,
      error,
      "MOBILE PAYMENT RESERVATION LIST ERROR"
    );
  }
  }
);

app.post(
  "/mobile-payment-reservations/:reference/agent-confirmation",
  paymentRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["agent", "site_owner", "admin_bv"]),
  async (req, res) => {
    try {
      const reference = String(req.params.reference || "").trim();

      if (!reference) {
        return res.status(400).json({
          success: false,
          error: "Référence réservation obligatoire",
        });
      }

      const {
        reservation,
        error: fetchError,
      } = await fetchMobileReservationByReference(reference);

      if (fetchError) throw fetchError;

      if (!reservation) {
        return res.status(404).json({
          success: false,
          error: "Réservation mobile introuvable",
          reference,
        });
      }

      if (!canAccessReservation(req, reservation)) {
        return res.status(403).json({
          success: false,
          error: "Réservation non autorisée pour cet agent.",
        });
      }

      if (!["cash", "agent_cash"].includes(reservation.payment_method)) {
        return res.status(400).json({
          success: false,
          error: "Cette réservation ne nécessite pas de confirmation cash agent",
          payment_method: reservation.payment_method,
        });
      }

      const nowIso = new Date().toISOString();
      const amountReceived = Number(
        req.body.amount_received_gdes ??
          req.body.amountReceivedGdes ??
          reservation.price_gdes
      );
      const expectedAmount = Number(
        req.body.expected_amount_gdes ??
          req.body.expectedAmountGdes ??
          reservation.price_gdes
      );
      const commissionRate = Number(
        req.body.commission_rate ?? reservation.commission_rate ?? 0.1
      );
      const commissionGdes = Number(
        req.body.commission_gdes ?? amountReceived * commissionRate
      );
      const confirmedAgentUserId =
        req.body.agent_user_id ||
        req.body.agentUserId ||
        reservation.agent_user_id ||
        (req.bvAuth?.role === "agent" ? req.bvAuth.userId : null);

      if (!amountReceived || amountReceived <= 0) {
        return res.status(400).json({
          success: false,
          error: "Montant reçu invalide",
        });
      }

      const transactionReference = `CASH-${reference}-${Date.now()}`;
      const { data: transaction, error: transactionError } = await supabase
        .from("mobile_payment_transactions")
        .insert([
          {
            reservation_id: reservation.id,
            reference: transactionReference,
            payment_method: reservation.payment_method,
            provider: "agent_cash",
            amount_gdes: amountReceived,
            status: "confirmed",
            provider_reference: req.body.provider_reference || null,
            provider_status: "cash_received",
            request_payload: req.body || {},
            response_payload: {
              source: "agent-confirmation",
              confirmed_at: nowIso,
            },
            confirmed_at: nowIso,
          },
        ])
        .select()
        .single();

      if (transactionError) throw transactionError;

      const { data: confirmation, error: confirmationError } = await supabase
        .from("mobile_agent_confirmations")
        .insert([
          {
            reservation_id: reservation.id,
            transaction_id: transaction.id,
            agent_user_id: confirmedAgentUserId,
            site_code: req.body.site_code || reservation.site_code,
            amount_received_gdes: amountReceived,
            expected_amount_gdes: expectedAmount,
            amount_matches: amountReceived === expectedAmount,
            agent_confirmed_cash_received: true,
            confirmation_status: "confirmed",
            confirmation_note: req.body.confirmation_note || req.body.note || null,
            commission_rate: commissionRate,
            commission_gdes: commissionGdes,
            confirmed_at: nowIso,
          },
        ])
        .select()
        .single();

      if (confirmationError) throw confirmationError;

      const { data: updatedReservation, error: updateError } = await supabase
        .from("mobile_payment_reservations")
        .update({
          agent_user_id: confirmedAgentUserId,
          payment_status: "paid",
          reservation_status: "payment_confirmed",
          commission_rate: commissionRate,
          commission_gdes: commissionGdes,
          commission_status: "pending",
          paid_at: nowIso,
          updated_at: nowIso,
        })
        .eq("id", reservation.id)
        .select()
        .single();

      if (updateError) throw updateError;

      res.status(200).json({
        success: true,
        reservation: updatedReservation,
        transaction,
        confirmation,
      });
    } catch (error) {
      return sendMobilePaymentError(
        res,
        error,
        "MOBILE PAYMENT AGENT CONFIRMATION ERROR"
      );
    }
  }
);

app.post(
  "/mobile-payment-reservations/:reference/payment-confirmed",
  paymentRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["client", "agent", "site_owner", "admin_bv"]),
  requirePaymentProviderConfirmation,
  async (req, res) => {
    try {
      const reference = String(req.params.reference || "").trim();

      if (!reference) {
        return res.status(400).json({
          success: false,
          error: "Référence réservation obligatoire",
        });
      }

      const {
        reservation,
        error: fetchError,
      } = await fetchMobileReservationByReference(reference);

      if (fetchError) throw fetchError;

      if (!reservation) {
        return res.status(404).json({
          success: false,
          error: "Réservation mobile introuvable",
          reference,
        });
      }

      if (!canAccessReservation(req, reservation)) {
        return res.status(403).json({
          success: false,
          error: "Réservation non autorisée pour cet utilisateur.",
        });
      }

      if (["cash", "agent_cash"].includes(reservation.payment_method)) {
        return res.status(400).json({
          success: false,
          error: "Utilisez la confirmation agent pour un paiement cash",
          payment_method: reservation.payment_method,
        });
      }

      const nowIso = new Date().toISOString();
      const transactionBody = req.body.transaction || {};
      const transactionReference =
        transactionBody.reference ||
        `${String(reservation.payment_method).toUpperCase()}-${reference}-${Date.now()}`;

      const { data: transaction, error: transactionError } = await supabase
        .from("mobile_payment_transactions")
        .insert([
          {
            reservation_id: reservation.id,
            reference: transactionReference,
            payment_method: reservation.payment_method,
            provider: providerForMobilePaymentMethod(reservation.payment_method),
            amount_gdes: Number(
              transactionBody.amountGdes ||
                transactionBody.amount_gdes ||
                reservation.price_gdes
            ),
            status: "confirmed",
            provider_transaction_id:
              transactionBody.providerTransactionId ||
              transactionBody.provider_transaction_id ||
              null,
            provider_reference: transactionBody.reference || null,
            provider_status: transactionBody.status || "confirmed",
            request_payload: req.body || {},
            response_payload: {
              source: "payment-confirmed",
              confirmed_at: nowIso,
              transaction: transactionBody,
            },
            confirmed_at: nowIso,
          },
        ])
        .select()
        .single();

      if (transactionError) throw transactionError;

      const { data: updatedReservation, error: updateError } = await supabase
        .from("mobile_payment_reservations")
        .update({
          payment_status: "paid",
          reservation_status: "payment_confirmed",
          paid_at: nowIso,
          updated_at: nowIso,
        })
        .eq("id", reservation.id)
        .select()
        .single();

      if (updateError) throw updateError;

      res.status(200).json({
        success: true,
        reservation: updatedReservation,
        transaction,
      });
    } catch (error) {
      return sendMobilePaymentError(
        res,
        error,
        "MOBILE PAYMENT DIRECT CONFIRMATION ERROR"
      );
    }
  }
);

app.post(
  "/mobile-payment-reservations/:reference/generate-voucher",
  paymentRateLimiter,
  requireSupabaseUserOrInternal,
  requireBvAuthRoles(["client", "agent", "site_owner", "admin_bv"]),
  async (req, res) => {
    try {
      const reference = String(req.params.reference || "").trim();

      if (!reference) {
        return res.status(400).json({
          success: false,
          error: "Référence réservation obligatoire",
        });
      }

      const {
        reservation,
        error: fetchError,
      } = await fetchMobileReservationByReference(reference);

      if (fetchError) throw fetchError;

      if (!reservation) {
        return res.status(404).json({
          success: false,
          error: "Réservation mobile introuvable",
          reference,
        });
      }

      if (!canAccessReservation(req, reservation)) {
        return res.status(403).json({
          success: false,
          error: "Réservation non autorisée pour cet utilisateur interne.",
        });
      }

      if (reservation.generated_voucher_code) {
        const {
          voucher,
          error: voucherError,
        } = await fetchVoucherBySubmittedCode(
          reservation.generated_voucher_code,
          "/mobile-payment-reservations/generate-voucher"
        );

        if (voucherError) throw voucherError;

        if (voucher) {
          return res.status(200).json({
            success: true,
            reservation,
            voucher: buildMobileVoucherResponse(voucher, reservation, req),
            already_generated: true,
          });
        }
      }

      if (
        reservation.payment_status !== "paid" ||
        !["payment_confirmed", "voucher_generated"].includes(
          reservation.reservation_status
        )
      ) {
        return res.status(409).json({
          success: false,
          error: "Paiement non confirmé. Le voucher ne peut pas encore être généré.",
          payment_status: reservation.payment_status,
          reservation_status: reservation.reservation_status,
        });
      }

      const voucherCode = await generateUniqueNationalCode();
      const { qr_code_url } = buildVoucherQrPayload(voucherCode, req);
      const nowIso = new Date().toISOString();
      const accessPayload = {
        code: voucherCode,
        plan_code: reservation.plan_code,
        minutes: reservation.minutes_total,
        duration_minutes: reservation.minutes_total,
        minutes_total: reservation.minutes_total,
        minutes_remaining: reservation.minutes_total,
        national_voucher: true,
        validation_mode: "central",
        purchase_source: "mobile_app",
        amount: reservation.price_gdes,
        customer_name: reservation.customer_name,
        customer_phone: reservation.customer_phone,
        customer_email: reservation.customer_email,
        status: "unused",
        qr_code_url,
        sale_site_code: reservation.site_code,
        notes:
          "Code national B&V Access généré depuis réservation mobile après paiement confirmé.",
      };

      const { data: accessCode, error: accessError } = await supabase
        .from("access_codes")
        .insert([accessPayload])
        .select()
        .single();

      if (accessError) throw accessError;

      const { data: updatedReservation, error: updateError } = await supabase
        .from("mobile_payment_reservations")
        .update({
          reservation_status: "voucher_generated",
          generated_voucher_code: voucherCode,
          generated_access_code_id: String(accessCode.id),
          generated_at: nowIso,
          updated_at: nowIso,
        })
        .eq("id", reservation.id)
        .select()
        .single();

      if (updateError) throw updateError;

      res.status(200).json({
        success: true,
        reservation: updatedReservation,
        voucher: buildMobileVoucherResponse(accessCode, updatedReservation, req),
      });
    } catch (error) {
      return sendMobilePaymentError(
        res,
        error,
        "MOBILE PAYMENT GENERATE VOUCHER ERROR"
      );
    }
  }
);

app.get(
  "/agent-dashboard/:agent_code",
  dashboardRateLimiter,
  requireInternalAuth(["agent", "admin_bv"]),
  enforceAgentScope,
  async (req, res) => {
  try {
    const agentCode = String(req.params.agent_code || "").trim();

    const { data: agent, error: agentError } = await supabase
      .from("agents")
      .select("*")
      .eq("agent_code", agentCode)
      .single();

    if (agentError || !agent) {
      return res.status(404).json({
        success: false,
        error: "Agent introuvable",
      });
    }

    const { data: sales, error: salesError } = await supabase
      .from("sales")
      .select("*")
      .eq("agent_id", agent.id)
      .order("created_at", { ascending: false });

    if (salesError) throw salesError;

    const { data: commissions, error: commissionsError } = await supabase
      .from("commissions")
      .select("*")
      .eq("agent_id", agent.id)
      .order("created_at", { ascending: false });

    if (commissionsError) throw commissionsError;

    const voucherCodes = [...new Set(
      (sales || [])
        .map((sale) => normalizeBVCode(sale.voucher_code))
        .filter(Boolean)
    )];

    let vouchersByCode = {};

    if (voucherCodes.length > 0) {
      const { data: saleVouchers, error: saleVouchersError } = await supabase
        .from("access_codes")
        .select("*")
        .in("code", voucherCodes);

      if (saleVouchersError) throw saleVouchersError;

      vouchersByCode = buildVouchersByCode(saleVouchers || []);
    }

    const todayIso = getStartOfTodayIso();

    const todaySales = (sales || []).filter((sale) => {
      return new Date(sale.created_at).toISOString() >= todayIso;
    });

    const todayCommissions = (commissions || []).filter((commission) => {
      return new Date(commission.created_at).toISOString() >= todayIso;
    });

    const pendingCommissionAmount = (commissions || [])
      .filter((commission) => {
        return String(commission.status || "").toLowerCase() === "pending";
      })
      .reduce((sum, commission) => {
        return sum + Number(commission.commission_amount || 0);
      }, 0);

    res.status(200).json({
      success: true,
      agent,
      stats: {
        total_sales_count: sales.length,
        today_sales_count: todaySales.length,
        total_sales_amount: sumAmounts(sales, "amount"),
        today_sales_amount: sumAmounts(todaySales, "amount"),
        total_commission_amount: sumAmounts(commissions, "commission_amount"),
        today_commission_amount: sumAmounts(
          todayCommissions,
          "commission_amount"
        ),
        pending_commission_amount: pendingCommissionAmount,
      },
      recent_sales: sales
        .slice(0, 20)
        .map((sale) => decorateSaleWithVoucherQr(sale, vouchersByCode, req)),
      recent_commissions: commissions.slice(0, 20),
    });
  } catch (error) {
    console.error("AGENT DASHBOARD ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);
app.get(
  "/dashboard-data",
  dashboardRateLimiter,
  requireInternalAuth(["admin_bv"]),
  async (req, res) => {
  try {
    const todayIso = getStartOfTodayIso();

    const { data: sales, error: salesError } = await supabase
      .from("sales")
      .select("*")
      .order("created_at", { ascending: false });

    if (salesError) throw salesError;

    const { data: vouchers, error: vouchersError } = await supabase
      .from("access_codes")
      .select("*")
      .order("created_at", { ascending: false });

    if (vouchersError) throw vouchersError;

    const { data: agents, error: agentsError } = await supabase
      .from("agents")
      .select("*")
      .order("created_at", { ascending: false });

    if (agentsError) throw agentsError;

    const { data: sites, error: sitesError } = await supabase
      .from("sites")
      .select("*")
      .order("created_at", { ascending: false });

    if (sitesError) throw sitesError;

    const { data: sessions, error: sessionsError } = await supabase
      .from("access_sessions")
      .select("*")
      .order("started_at", { ascending: false });

    if (sessionsError) throw sessionsError;

    const { data: commissions, error: commissionsError } = await supabase
      .from("commissions")
      .select("*")
      .order("created_at", { ascending: false });

    if (commissionsError) throw commissionsError;

    const safeSales = sales || [];
    const safeVouchers = vouchers || [];
    const safeAgents = agents || [];
    const safeSites = sites || [];
    const safeSessions = sessions || [];
    const safeCommissions = commissions || [];
    const vouchersByCode = buildVouchersByCode(safeVouchers);

    const salesToday = safeSales.filter((sale) => {
      return new Date(sale.created_at).toISOString() >= todayIso;
    });

    const activeCodes = safeVouchers.filter((voucher) => {
      const status = String(voucher.status || "").toLowerCase();
      return status === "active" || status === "unused";
    });

    const usedCodes = safeVouchers.filter((voucher) => {
      return String(voucher.status || "").toLowerCase() === "used";
    });

    const activeSessions = safeSessions.filter((session) => {
      return String(session.status || "").toLowerCase() === "active";
    });

    const activeSites = safeSites.filter((site) => {
      return String(site.status || "active").toLowerCase() === "active";
    });

    const activeAgents = safeAgents.filter((agent) => {
      return String(agent.status || "").toLowerCase() === "active";
    });

    const agentsById = {};
    safeAgents.forEach((agent) => {
      agentsById[agent.id] = agent;
    });

    const sitesByCode = {};
    safeSites.forEach((site) => {
      sitesByCode[site.site_code] = site;
    });

    const topSitesMap = {};

    safeSales.forEach((sale) => {
      const siteCode = sale.site_code || "NON-ASSIGNÉ";
      const site = sitesByCode[siteCode] || {};

      if (!topSitesMap[siteCode]) {
        topSitesMap[siteCode] = {
          site_code: siteCode,
          site_name: site.site_name || site.name || siteCode,
          city: site.city || site.location || "-",
          total_sales: 0,
          total_revenue: 0,
        };
      }

      topSitesMap[siteCode].total_sales += 1;
      topSitesMap[siteCode].total_revenue += Number(sale.amount || 0);
    });

    const top_sites = Object.values(topSitesMap).sort((a, b) => {
      return Number(b.total_revenue || 0) - Number(a.total_revenue || 0);
    });

    const topAgentsMap = {};

    safeSales.forEach((sale) => {
      const agentId = sale.agent_id || "NON-ASSIGNÉ";
      const agent = agentsById[agentId] || {};

      if (!topAgentsMap[agentId]) {
        topAgentsMap[agentId] = {
          agent_id: agentId,
          agent_code: agent.agent_code || "-",
          agent_name: agent.full_name || "-",
          city: agent.city || "-",
          total_sales: 0,
          total_revenue: 0,
          total_commissions: 0,
        };
      }

      topAgentsMap[agentId].total_sales += 1;
      topAgentsMap[agentId].total_revenue += Number(sale.amount || 0);
    });

    safeCommissions.forEach((commission) => {
      const agentId = commission.agent_id || "NON-ASSIGNÉ";

      if (!topAgentsMap[agentId]) {
        const agent = agentsById[agentId] || {};

        topAgentsMap[agentId] = {
          agent_id: agentId,
          agent_code: agent.agent_code || "-",
          agent_name: agent.full_name || "-",
          city: agent.city || "-",
          total_sales: 0,
          total_revenue: 0,
          total_commissions: 0,
        };
      }

      topAgentsMap[agentId].total_commissions += Number(
        commission.commission_amount || 0
      );
    });

    const top_agents = Object.values(topAgentsMap).sort((a, b) => {
      return Number(b.total_revenue || 0) - Number(a.total_revenue || 0);
    });

    const recent_sales = safeSales.slice(0, 20).map((sale) => {
      const agent = agentsById[sale.agent_id] || {};

      return {
        ...decorateSaleWithVoucherQr(sale, vouchersByCode, req),
        agent_code: agent.agent_code || sale.agent_code || "-",
        agent_name: agent.full_name || "-",
      };
    });

    res.status(200).json({
      success: true,

      revenue_total_gdes: sumAmounts(safeSales, "amount"),
      revenue_today_gdes: sumAmounts(salesToday, "amount"),

      total_sales: safeSales.length,
      total_codes: safeVouchers.length,
      locked_codes: usedCodes.length,
      active_codes: activeCodes.length,
      used_codes: usedCodes.length,

      total_agents: safeAgents.length,
      active_agents: activeAgents.length,

      total_sites: safeSites.length,
      active_sites: activeSites.length,

      active_sessions: activeSessions.length,
      total_sessions: safeSessions.length,

      total_commissions: sumAmounts(safeCommissions, "commission_amount"),

      recent_sales,
      recent_sessions: safeSessions.slice(0, 20),
      recent_commissions: safeCommissions.slice(0, 20),

      top_sites,
      top_agents,
    });
  } catch (error) {
    console.error("DASHBOARD DATA ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);

app.get(
  "/owner-dashboard/:site_code",
  dashboardRateLimiter,
  requireInternalAuth(["site_owner", "admin_bv"]),
  enforceOwnerSiteScope,
  async (req, res) => {
  try {
    const siteCode = String(req.params.site_code || "").trim().toUpperCase();

    const { data: site, error: siteError } = await supabase
      .from("sites")
      .select("*")
      .eq("site_code", siteCode)
      .maybeSingle();

    if (siteError) throw siteError;

    const { data: sales, error: salesError } = await supabase
      .from("sales")
      .select("*")
      .eq("site_code", siteCode)
      .order("created_at", { ascending: false });

    if (salesError) throw salesError;

    const { data: agents, error: agentsError } = await supabase
      .from("agents")
      .select("*")
      .eq("site_code", siteCode)
      .order("created_at", { ascending: false });

    if (agentsError) throw agentsError;

    const { data: commissions, error: commissionsError } = await supabase
      .from("commissions")
      .select("*")
      .eq("site_code", siteCode)
      .order("created_at", { ascending: false });

    if (commissionsError) throw commissionsError;

    const { data: vouchers, error: vouchersError } = await supabase
      .from("access_codes")
      .select("*")
      .or(`sale_site_code.eq.${siteCode},last_site_code.eq.${siteCode}`)
      .order("created_at", { ascending: false });

    if (vouchersError) throw vouchersError;

    const { data: sessions, error: sessionsError } = await supabase
      .from("access_sessions")
      .select("*")
      .eq("site_code", siteCode)
      .order("started_at", { ascending: false });

    if (sessionsError) throw sessionsError;

    const todayIso = getStartOfTodayIso();

    const salesToday = (sales || []).filter((sale) => {
      return new Date(sale.created_at).toISOString() >= todayIso;
    });

    const activeCodes = (vouchers || []).filter((voucher) => {
      return String(voucher.status || "").toLowerCase() === "active";
    });

    const usedCodes = (vouchers || []).filter((voucher) => {
      return String(voucher.status || "").toLowerCase() === "used";
    });

    const activeSessions = (sessions || []).filter((session) => {
      return String(session.status || "").toLowerCase() === "active";
    });

    const agentsById = {};
    (agents || []).forEach((agent) => {
      agentsById[agent.id] = agent;
    });
    const vouchersByCode = buildVouchersByCode(vouchers || []);

    const recentSales = (sales || []).slice(0, 30).map((sale) => {
      const agent = agentsById[sale.agent_id] || {};
      return {
        ...decorateSaleWithVoucherQr(sale, vouchersByCode, req),
        agent_code: agent.agent_code || "",
        agent_name: agent.full_name || "",
      };
    });

    res.status(200).json({
      success: true,
      site: {
        id: site ? site.id : null,
        site_code: siteCode,
        name: site ? site.site_name || site.name || siteCode : siteCode,
        city: site ? site.city || site.location || "-" : "-",
        status: site ? site.status || "active" : "active",
      },
      stats: {
        total_revenue: sumAmounts(sales || [], "amount"),
        today_revenue: sumAmounts(salesToday || [], "amount"),
        total_sales: (sales || []).length,
        total_agents: (agents || []).length,
        active_codes: activeCodes.length,
        used_codes: usedCodes.length,
        active_sessions: activeSessions.length,
        total_commissions: sumAmounts(commissions || [], "commission_amount"),
      },
      recent_sales: recentSales,
      agents: agents || [],
      vouchers: (vouchers || [])
        .slice(0, 50)
        .map((voucher) => ({
          ...voucher,
          ...decorateVoucherQr(voucher, req),
        })),
      sessions: (sessions || []).slice(0, 50),
      commissions: (commissions || []).slice(0, 50),
    });
  } catch (error) {
    console.error("OWNER DASHBOARD ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);
app.get(
  "/dashboard-data",
  dashboardRateLimiter,
  requireInternalAuth(["admin_bv"]),
  async (req, res) => {
  try {
    const todayIso = getStartOfTodayIso();

    const { data: sales, error: salesError } = await supabase
      .from("sales")
      .select("*")
      .order("created_at", { ascending: false });

    if (salesError) throw salesError;

    const { data: vouchers, error: vouchersError } = await supabase
      .from("access_codes")
      .select("*")
      .order("created_at", { ascending: false });

    if (vouchersError) throw vouchersError;

    const { data: agents, error: agentsError } = await supabase
      .from("agents")
      .select("*")
      .order("created_at", { ascending: false });

    if (agentsError) throw agentsError;

    const { data: sites, error: sitesError } = await supabase
      .from("sites")
      .select("*")
      .order("created_at", { ascending: false });

    if (sitesError) throw sitesError;

    const { data: sessions, error: sessionsError } = await supabase
      .from("access_sessions")
      .select("*")
      .order("started_at", { ascending: false });

    if (sessionsError) throw sessionsError;

    const { data: commissions, error: commissionsError } = await supabase
      .from("commissions")
      .select("*")
      .order("created_at", { ascending: false });

    if (commissionsError) throw commissionsError;

    const safeSales = sales || [];
    const safeVouchers = vouchers || [];
    const safeAgents = agents || [];
    const safeSites = sites || [];
    const safeSessions = sessions || [];
    const safeCommissions = commissions || [];
    const vouchersByCode = buildVouchersByCode(safeVouchers);

    const salesToday = safeSales.filter((sale) => {
      return new Date(sale.created_at).toISOString() >= todayIso;
    });

    const activeCodes = safeVouchers.filter((voucher) => {
      const status = String(voucher.status || "").toLowerCase();
      return status === "active" || status === "unused";
    });

    const usedCodes = safeVouchers.filter((voucher) => {
      return String(voucher.status || "").toLowerCase() === "used";
    });

    const activeSessions = safeSessions.filter((session) => {
      return String(session.status || "").toLowerCase() === "active";
    });

    const activeSites = safeSites.filter((site) => {
      return String(site.status || "active").toLowerCase() === "active";
    });

    const activeAgents = safeAgents.filter((agent) => {
      return String(agent.status || "").toLowerCase() === "active";
    });

    const agentsById = {};
    safeAgents.forEach((agent) => {
      agentsById[agent.id] = agent;
    });

    const sitesByCode = {};
    safeSites.forEach((site) => {
      sitesByCode[site.site_code] = site;
    });

    const topSitesMap = {};

    safeSales.forEach((sale) => {
      const siteCode = sale.site_code || "NON-ASSIGNÉ";
      const site = sitesByCode[siteCode] || {};

      if (!topSitesMap[siteCode]) {
        topSitesMap[siteCode] = {
          site_code: siteCode,
          site_name: site.site_name || site.name || siteCode,
          city: site.city || site.location || "-",
          total_sales: 0,
          total_revenue: 0,
        };
      }

      topSitesMap[siteCode].total_sales += 1;
      topSitesMap[siteCode].total_revenue += Number(sale.amount || 0);
    });

    const top_sites = Object.values(topSitesMap).sort((a, b) => {
      return Number(b.total_revenue || 0) - Number(a.total_revenue || 0);
    });

    const topAgentsMap = {};

    safeSales.forEach((sale) => {
      const agentId = sale.agent_id || "NON-ASSIGNÉ";
      const agent = agentsById[agentId] || {};

      if (!topAgentsMap[agentId]) {
        topAgentsMap[agentId] = {
          agent_id: agentId,
          agent_code: agent.agent_code || "-",
          agent_name: agent.full_name || "-",
          city: agent.city || "-",
          total_sales: 0,
          total_revenue: 0,
          total_commissions: 0,
        };
      }

      topAgentsMap[agentId].total_sales += 1;
      topAgentsMap[agentId].total_revenue += Number(sale.amount || 0);
    });

    safeCommissions.forEach((commission) => {
      const agentId = commission.agent_id || "NON-ASSIGNÉ";

      if (!topAgentsMap[agentId]) {
        const agent = agentsById[agentId] || {};

        topAgentsMap[agentId] = {
          agent_id: agentId,
          agent_code: agent.agent_code || "-",
          agent_name: agent.full_name || "-",
          city: agent.city || "-",
          total_sales: 0,
          total_revenue: 0,
          total_commissions: 0,
        };
      }

      topAgentsMap[agentId].total_commissions += Number(
        commission.commission_amount || 0
      );
    });

    const top_agents = Object.values(topAgentsMap).sort((a, b) => {
      return Number(b.total_revenue || 0) - Number(a.total_revenue || 0);
    });

    const recent_sales = safeSales.slice(0, 20).map((sale) => {
      const agent = agentsById[sale.agent_id] || {};

      return {
        ...decorateSaleWithVoucherQr(sale, vouchersByCode, req),
        agent_code: agent.agent_code || sale.agent_code || "-",
        agent_name: agent.full_name || "-",
      };
    });

    res.status(200).json({
      success: true,

      revenue_total_gdes: sumAmounts(safeSales, "amount"),
      revenue_today_gdes: sumAmounts(salesToday, "amount"),

      total_sales: safeSales.length,
      total_codes: safeVouchers.length,
      locked_codes: usedCodes.length,
      active_codes: activeCodes.length,
      used_codes: usedCodes.length,

      total_agents: safeAgents.length,
      active_agents: activeAgents.length,

      total_sites: safeSites.length,
      active_sites: activeSites.length,

      active_sessions: activeSessions.length,
      total_sessions: safeSessions.length,

      total_commissions: sumAmounts(safeCommissions, "commission_amount"),

      recent_sales,
      recent_sessions: safeSessions.slice(0, 20),
      recent_commissions: safeCommissions.slice(0, 20),

      top_sites,
      top_agents,
    });
  } catch (error) {
    console.error("DASHBOARD DATA ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);

app.get(
  "/owner-dashboard/:site_code",
  dashboardRateLimiter,
  requireInternalAuth(["site_owner", "admin_bv"]),
  enforceOwnerSiteScope,
  async (req, res) => {
  try {
    const siteCode = String(req.params.site_code || "").trim().toUpperCase();

    const { data: site, error: siteError } = await supabase
      .from("sites")
      .select("*")
      .eq("site_code", siteCode)
      .maybeSingle();

    if (siteError) throw siteError;

    const { data: sales, error: salesError } = await supabase
      .from("sales")
      .select("*")
      .eq("site_code", siteCode)
      .order("created_at", { ascending: false });

    if (salesError) throw salesError;

    const { data: agents, error: agentsError } = await supabase
      .from("agents")
      .select("*")
      .eq("site_code", siteCode)
      .order("created_at", { ascending: false });

    if (agentsError) throw agentsError;

    const { data: commissions, error: commissionsError } = await supabase
      .from("commissions")
      .select("*")
      .eq("site_code", siteCode)
      .order("created_at", { ascending: false });

    if (commissionsError) throw commissionsError;

    const { data: vouchers, error: vouchersError } = await supabase
      .from("access_codes")
      .select("*")
      .or(`sale_site_code.eq.${siteCode},last_site_code.eq.${siteCode}`)
      .order("created_at", { ascending: false });

    if (vouchersError) throw vouchersError;

    const { data: sessions, error: sessionsError } = await supabase
      .from("access_sessions")
      .select("*")
      .eq("site_code", siteCode)
      .order("started_at", { ascending: false });

    if (sessionsError) throw sessionsError;

    const todayIso = getStartOfTodayIso();

    const salesToday = (sales || []).filter((sale) => {
      return new Date(sale.created_at).toISOString() >= todayIso;
    });

    const activeCodes = (vouchers || []).filter((voucher) => {
      return String(voucher.status || "").toLowerCase() === "active";
    });

    const usedCodes = (vouchers || []).filter((voucher) => {
      return String(voucher.status || "").toLowerCase() === "used";
    });

    const activeSessions = (sessions || []).filter((session) => {
      return String(session.status || "").toLowerCase() === "active";
    });

    const agentsById = {};
    (agents || []).forEach((agent) => {
      agentsById[agent.id] = agent;
    });
    const vouchersByCode = buildVouchersByCode(vouchers || []);

    const recentSales = (sales || []).slice(0, 30).map((sale) => {
      const agent = agentsById[sale.agent_id] || {};
      return {
        ...decorateSaleWithVoucherQr(sale, vouchersByCode, req),
        agent_code: agent.agent_code || "",
        agent_name: agent.full_name || "",
      };
    });

    res.status(200).json({
      success: true,
      site: {
        id: site ? site.id : null,
        site_code: siteCode,
        name: site ? site.site_name || site.name || siteCode : siteCode,
        city: site ? site.city || site.location || "-" : "-",
        status: site ? site.status || "active" : "active",
      },
      stats: {
        total_revenue: sumAmounts(sales || [], "amount"),
        today_revenue: sumAmounts(salesToday || [], "amount"),
        total_sales: (sales || []).length,
        total_agents: (agents || []).length,
        active_codes: activeCodes.length,
        used_codes: usedCodes.length,
        active_sessions: activeSessions.length,
        total_commissions: sumAmounts(commissions || [], "commission_amount"),
      },
      recent_sales: recentSales,
      agents: agents || [],
      vouchers: (vouchers || [])
        .slice(0, 50)
        .map((voucher) => ({
          ...voucher,
          ...decorateVoucherQr(voucher, req),
        })),
      sessions: (sessions || []).slice(0, 50),
      commissions: (commissions || []).slice(0, 50),
    });
  } catch (error) {
    console.error("OWNER DASHBOARD ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);
app.get(
  "/vouchers",
  voucherRateLimiter,
  requireInternalAuth(["admin_bv"]),
  async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("access_codes")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);

    if (error) throw error;

    res.status(200).json({
      success: true,
      data: (data || []).map((voucher) => ({
        ...voucher,
        ...decorateVoucherQr(voucher, req),
      })),
    });
  } catch (error) {
    console.error("VOUCHERS ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
  }
);

app.get("/voucher/:code", voucherRateLimiter, async (req, res) => {
  try {
    const code = normalizeBVCode(req.params.code);

    bvDebug("/voucher LOOKUP ENTER", {
      code: maskCodeForLog(code),
    });

    const {
      voucher,
      matchedField,
      attempts,
      error,
    } = await fetchVoucherBySubmittedCode(code, "/voucher");

    bvDebug("/voucher LOOKUP RESULT", {
      found: Boolean(voucher),
      matched_field: matchedField,
      attempts,
      voucher_id: voucher?.id || null,
      status: voucher?.status || null,
      site_code: voucher?.site_code || voucher?.last_site_code || null,
    });

    if (error || !voucher) {
      return res.status(404).json({
        success: false,
        error: error?.message || "Code introuvable",
        attempts,
      });
    }

    const minutesTotal =
      voucher.minutes_total || voucher.minutes || voucher.duration_minutes || 0;

    const minutesRemaining = Number(voucher.minutes_remaining ?? 0);
    const qr = decorateVoucherQr(voucher, req, code);

    res.status(200).json({
      success: true,
      voucher: {
        code: voucher.code || voucher.access_code || voucher.voucher_code || code,
        plan_code: voucher.plan_code,
        status: voucher.status,
        minutes_total: minutesTotal,
        minutes_remaining: minutesRemaining,
        national_voucher: voucher.national_voucher,
        active: String(voucher.status || "").toLowerCase() === "active",
        exhausted: minutesRemaining <= 0,
        site_code: voucher.site_code,
        sale_site_code: voucher.sale_site_code,
        last_site_code: voucher.last_site_code,
        last_connection_at: voucher.last_connection_at,
        qr_code_url: qr.qr_code_url,
        portal_url: qr.portal_url,
      },
    });
  } catch (error) {
    logDiagnosticError("/voucher LOOKUP ERROR", error);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.post("/validate-access", validateAccessRateLimiter, async (req, res) => {
  let validateStep = "route_start";
  const requestId = buildRequestId("validate");

  try {
    validateStep = "request_enter";
    const requestDebug = buildRequestDebugPayload(req);
    const directMacCandidate = firstMacCandidate(req);
    const macCandidates = getMacCandidatesFromRequest(req);

    bvDebug("/validate-access ENTER", {
      request_id: requestId,
      method: req.method,
      path: req.originalUrl,
      ip: req.ip,
      user_agent: req.headers["user-agent"] || null,
      referer: req.headers.referer || null,
      origin: req.headers.origin || null,
      query: req.query || {},
      body_keys: Object.keys(req.body || {}),
      request_debug: requestDebug,
    });

    const code = normalizeBVCode(req.body.code);
    const requestedSiteCode = normalizeSiteCode(
      req.body.site_code ||
        req.body.siteCode ||
        req.query.site_code ||
        req.query.siteCode ||
        ""
    );
    const device_id = req.body.device_id || null;
    const siteContext = await resolveRegionalSiteContext(req, requestedSiteCode);
    const site_code = siteContext.site_code;
    const unifiSiteConfig = siteContext.site_config;
    let macResolution = {
      success: Boolean(directMacCandidate?.normalized),
      method: directMacCandidate?.normalized ? "request_parameter" : "not_attempted",
      mac_address: directMacCandidate?.normalized || null,
      selected_source: directMacCandidate?.source || null,
      selected_raw: directMacCandidate?.raw || null,
      candidates: macCandidates,
      ip_candidates: getIpCandidatesFromRequest(req),
      attempts: [],
    };
    let mac_address = macResolution.mac_address;
    const ip_address = req.body.ip_address || req.ip || null;
    const phone = normalizePhone(
      req.body.phone || req.body.customer_phone || req.body.activated_phone || ""
    );

    bvDebug("/validate-access CODE RECEIVED", {
      request_id: requestId,
      raw_code: req.body.code || null,
      normalized_code: code,
      masked_code: maskCodeForLog(code),
    });

    bvDebug("/validate-access MAC RECEIVED", {
      request_id: requestId,
      raw_mac: req.body.mac_address || null,
      normalized_mac: mac_address,
      selected_source: macResolution.selected_source,
      mac_candidates: macCandidates,
      ip_candidates: macResolution.ip_candidates,
      mac_resolution: macResolution,
    });

    bvDebug("/validate-access PHONE RECEIVED", {
      request_id: requestId,
      raw_phone:
        req.body.phone ||
        req.body.customer_phone ||
        req.body.activated_phone ||
        null,
      normalized_phone: phone || null,
      phone_present: Boolean(phone),
    });

    console.log("VALIDATE ACCESS START", {
      request_id: requestId,
      code: maskCodeForLog(code),
      site_code,
      requested_site_code: requestedSiteCode || null,
      site_source: siteContext.source,
      regional_node_code: siteContext.regional_node_code,
      device_id,
      mac_address,
      ip_address,
      phone_present: Boolean(phone),
      raw_mac_received: req.body.mac_address || null,
      mac_source: macResolution.selected_source,
    });

    if (!code) {
      console.log("VALIDATE ACCESS STOP: missing code");

      return res.status(400).json({
        success: false,
        authorized: false,
        request_id: requestId,
        error: "Code obligatoire",
      });
    }

    validateStep = "supabase_fetch_voucher";

    bvDebug("/validate-access SUPABASE FETCH VOUCHER START", {
      request_id: requestId,
      code: maskCodeForLog(code),
    });

    console.log("VALIDATE ACCESS SUPABASE: fetching voucher");

    const {
      voucher,
      matchedField,
      attempts: voucherLookupAttempts,
      error: voucherError,
    } = await fetchVoucherBySubmittedCode(code, "/validate-access");

    bvDebug("/validate-access SUPABASE FETCH VOUCHER RESULT", {
      request_id: requestId,
      voucher_found: Boolean(voucher),
      matched_field: matchedField,
      lookup_attempts: voucherLookupAttempts,
      voucher_id: voucher?.id || null,
      status: voucher?.status || null,
      code_present: Boolean(voucher?.code),
      access_code_present: Boolean(voucher?.access_code),
      voucher_code_present: Boolean(voucher?.voucher_code),
      minutes_remaining:
        voucher?.minutes_remaining ??
        voucher?.minutes ??
        voucher?.duration_minutes ??
        null,
      activated_phone: voucher?.activated_phone || null,
      customer_phone: voucher?.customer_phone || null,
      site_code:
        voucher?.site_code ||
        voucher?.sale_site_code ||
        voucher?.last_site_code ||
        null,
    });

    if (voucherError) {
      logDiagnosticError("VALIDATE ACCESS SUPABASE VOUCHER ERROR", voucherError);
      throw voucherError;
    }

    if (!voucher) {
      console.log("VALIDATE ACCESS STOP: voucher not found", {
        code: maskCodeForLog(code),
        lookup_attempts: voucherLookupAttempts,
      });

      return res.status(404).json({
        success: false,
        authorized: false,
        request_id: requestId,
        error: "Code introuvable",
        error_source: "supabase",
        error_step: validateStep,
        server_build: SERVER_BUILD,
        lookup_attempts: voucherLookupAttempts,
      });
    }

    console.log("VALIDATE ACCESS SUPABASE: voucher found", {
      voucher_id: voucher.id,
      matched_field: matchedField,
      status: voucher.status,
      fields: {
        code: voucher.code ?? null,
        access_code: voucher.access_code ?? null,
        voucher_code: voucher.voucher_code ?? null,
        minutes_remaining: voucher.minutes_remaining ?? null,
        activated_phone: voucher.activated_phone ?? null,
        status: voucher.status ?? null,
        site_code:
          voucher.site_code ||
          voucher.sale_site_code ||
          voucher.last_site_code ||
          null,
      },
      minutes_remaining:
        voucher.minutes_remaining ??
        voucher.minutes ??
        voucher.duration_minutes ??
        null,
    });

    const blockedStatuses = ["expired", "blocked", "cancelled"];

    if (blockedStatuses.includes(String(voucher.status || "").toLowerCase())) {
      console.log("VALIDATE ACCESS STOP: blocked status", {
        voucher_id: voucher.id,
        status: voucher.status,
      });

      return res.status(403).json({
        success: false,
        authorized: false,
        request_id: requestId,
        error: "Code non valide",
        status: voucher.status,
      });
    }

    const minutesRemaining = Number(
      voucher.minutes_remaining ??
        voucher.minutes ??
        voucher.duration_minutes ??
        0
    );
    const sessionTiming = buildVoucherSessionTiming(
      voucher,
      minutesRemaining,
      new Date()
    );

    if (minutesRemaining <= 0) {
      console.log("VALIDATE ACCESS STOP: exhausted voucher", {
        request_id: requestId,
        voucher_id: voucher.id,
        mac_address,
      });

      validateStep = "supabase_mark_voucher_used";

      await supabase
        .from("access_codes")
        .update({
          status: "used",
          minutes_remaining: 0,
        })
        .eq("id", voucher.id);

      if (mac_address) {
        validateStep = "unifi_unauthorize_exhausted_voucher";

        try {
          await unauthorizeClient(mac_address, unifiSiteConfig);
        } catch (error) {
          logDiagnosticError("/validate-access UNIFI UNAUTHORIZE FAILED", error);

          if (isUnifiRequired()) {
            return res.status(502).json({
              success: false,
              authorized: false,
              request_id: requestId,
              voucher_valid: false,
              network_authorized: false,
              error: userFacingUniFiError(error),
              error_source: "unifi",
              error_step: validateStep,
              server_build: SERVER_BUILD,
              code,
              site_code,
              mac_address,
              minutes_remaining: 0,
              diagnostic: diagnosticErrorPayload(error),
              unifi: buildUnifiFailureResult(error, "unauthorize", mac_address),
            });
          }
        }
      }

      return res.status(403).json({
        success: false,
        authorized: false,
        request_id: requestId,
        error: "Temps épuisé",
        error_source: "voucher",
        error_step: validateStep,
        server_build: SERVER_BUILD,
        minutes_remaining: 0,
      });
    }

    if (!mac_address) {
      validateStep = "resolve_mac_address";
      macResolution = await resolveMacAddressForAccessRequest(req, unifiSiteConfig);
      mac_address = macResolution.mac_address;

      bvDebug("/validate-access MAC RESOLUTION RESULT", {
        request_id: requestId,
        mac_address,
        mac_resolution: macResolution,
        request_debug: requestDebug,
      });

      console.log("VALIDATE ACCESS MAC RESOLUTION RESULT", {
        request_id: requestId,
        mac_address,
        method: macResolution.method,
        selected_source: macResolution.selected_source,
        ip_candidates: macResolution.ip_candidates,
        attempts: macResolution.attempts,
      });
    }

    if (!mac_address && isUnifiRequired()) {
      return res.status(400).json({
        success: false,
        authorized: false,
        request_id: requestId,
        voucher_valid: true,
        network_authorized: false,
        error: "Adresse MAC introuvable",
        error_source: "mac_detection",
        error_step: validateStep,
        server_build: SERVER_BUILD,
        code,
        site_code,
        mac_address: null,
        mac_resolution: macResolution,
        request_debug: requestDebug,
      });
    }

    validateStep = "supabase_check_active_session";

    const { data: activeSessions, error: activeSessionsError } = await supabase
      .from("access_sessions")
      .select("*")
      .eq("access_code_id", voucher.id)
      .in("status", ["active", "paused"])
      .order("created_at", { ascending: true })
      .limit(10);

    if (activeSessionsError) {
      logDiagnosticError("VALIDATE ACCESS ACTIVE SESSION LOOKUP ERROR", activeSessionsError);
      throw activeSessionsError;
    }

    const nowMsForActiveSession = Date.now();
    const nonExpiredActiveSessions = (activeSessions || []).filter(
      (session) =>
        session.status === "active" && !isSessionExpired(session, nowMsForActiveSession)
    );
    const pausedSessions = (activeSessions || []).filter(
      (session) =>
        session.status === "paused" && !isSessionExpired(session, nowMsForActiveSession)
    );
    const sameMacActiveSession = nonExpiredActiveSessions.find(
      (session) =>
        Boolean(normalizeMac(session.mac_address) && mac_address) &&
        normalizeMac(session.mac_address) === mac_address
    );
    const sameMacPausedSession = pausedSessions.find(
      (session) =>
        Boolean(normalizeMac(session.mac_address) && mac_address) &&
        normalizeMac(session.mac_address) === mac_address
    );
    const reusableActiveSession =
      sameMacActiveSession || nonExpiredActiveSessions[0] || null;
    const expiredActiveSessions = (activeSessions || []).filter((session) =>
      isSessionExpired(session, nowMsForActiveSession)
    );

    for (const expiredSession of expiredActiveSessions) {
      const expiredResult = await endAccessSession(expiredSession, {
        nowMs: nowMsForActiveSession,
        minutesConsumed: getSessionAuthorizedMinutes(expiredSession),
      });

      console.log("VALIDATE ACCESS ACTIVE SESSION EXPIRED", {
        request_id: requestId,
        session_id: expiredSession.id,
        code: expiredSession.code,
        mac_address: expiredSession.mac_address,
        unifi: expiredResult.unifi,
      });
    }

    if (sameMacPausedSession) {
      const nowIso = new Date(nowMsForActiveSession).toISOString();
      const secondsConsumed = getSessionConsumedSeconds(
        sameMacPausedSession,
        nowMsForActiveSession
      );
      const authorizedSeconds = getSessionAuthorizedSeconds(
        sameMacPausedSession,
        voucher
      );
      const remainingMinutes = Math.max(
        1,
        Math.ceil(Math.max(0, authorizedSeconds - secondsConsumed) / 60)
      );
      const resumeTiming =
        getSessionBillingMode(sameMacPausedSession, voucher) === "fixed_window"
          ? {
              billingMode: "fixed_window",
              expiresAt:
                sameMacPausedSession.expires_at || sessionTiming.expiresAt,
              authorizeMinutes: Math.max(
                1,
                Math.ceil(
                  (parseDateMs(
                    sameMacPausedSession.expires_at || sessionTiming.expiresAt
                  ) -
                    nowMsForActiveSession) /
                    60000
                )
              ),
            }
          : {
              billingMode: "connected_usage",
              expiresAt: null,
              authorizeMinutes: remainingMinutes,
            };

      console.log("VALIDATE ACCESS SESSION RESUME START", {
        request_id: requestId,
        session_id: sameMacPausedSession.id,
        code: sameMacPausedSession.code,
        mac_address,
        seconds_consumed: secondsConsumed,
        minutes_remaining: remainingMinutes,
        billing_mode: resumeTiming.billingMode,
      });

      const resumeUpdate = await safeUpdateAccessSession(
        sameMacPausedSession.id,
        {
          status: "active",
          paused_at: null,
          last_accounted_at: nowIso,
          last_seen_at: nowIso,
          unifi_connected: true,
          site_code,
        },
        { select: "*", single: true }
      );

      if (resumeUpdate.error) throw resumeUpdate.error;

      await supabase
        .from("access_codes")
        .update({
          status: "active",
          last_site_code: site_code,
          last_connection_at: nowIso,
          minutes_remaining: remainingMinutes,
        })
        .eq("id", voucher.id);

      let unifiResult;

      try {
        unifiResult = await authorizeClient(
          mac_address,
          resumeTiming.authorizeMinutes,
          unifiSiteConfig
        );
      } catch (error) {
        logDiagnosticError("/validate-access UNIFI RESUME AUTHORIZE FAILED", error);

        unifiResult = buildUnifiFailureResult(error, "authorize", mac_address, {
          cmd: "authorize-guest",
          mac: mac_address,
          minutes: resumeTiming.authorizeMinutes,
        });

        if (isUnifiRequired()) {
          return res.status(502).json({
            success: false,
            authorized: false,
            request_id: requestId,
            voucher_valid: true,
            network_authorized: false,
            error: userFacingUniFiError(error),
            error_source: "unifi",
            error_step: "unifi_resume_authorize_client",
            server_build: SERVER_BUILD,
            code: voucher.code,
            site_code,
            mac_address,
            minutes_remaining: remainingMinutes,
            diagnostic: diagnosticErrorPayload(error),
            unifi: unifiResult,
          });
        }
      }

      await safeUpdateAccessSession(
        sameMacPausedSession.id,
        {
          unifi_authorized: Boolean(unifiResult?.success),
          unifi_connected: Boolean(unifiResult?.success),
          last_seen_at: nowIso,
        },
        { select: false }
      );

      console.log("SESSION RESUMED", {
        request_id: requestId,
        session_id: sameMacPausedSession.id,
        code: sameMacPausedSession.code,
        mac_address,
        site_code,
        controller_name: unifiSiteConfig.controller_name,
        minutes_remaining: remainingMinutes,
        unifi: unifiResult,
      });

      return res.status(200).json({
        success: true,
        authorized: true,
        resumed: true,
        request_id: requestId,
        message: "Session reprise",
        session_id: sameMacPausedSession.id,
        code: voucher.code,
        site_code,
        mac_address,
        ip_address,
        minutes_remaining: remainingMinutes,
        billing_mode: resumeTiming.billingMode,
        expires_at: resumeTiming.expiresAt,
        redirect_url: "https://betvsolutions.com",
        server_build: SERVER_BUILD,
        unifi: unifiResult,
      });
    }

    if (expiredActiveSessions.length > 0 && !reusableActiveSession) {
      return res.status(403).json({
        success: false,
        authorized: false,
        request_id: requestId,
        error: "Temps épuisé",
        error_source: "voucher",
        error_step: validateStep,
        server_build: SERVER_BUILD,
        minutes_remaining: 0,
      });
    }

    if (reusableActiveSession) {
      const existingMac = normalizeMac(reusableActiveSession.mac_address);
      const sameMac =
        Boolean(existingMac && mac_address) && existingMac === mac_address;
      const progress = await syncActiveSessionProgress(
        reusableActiveSession,
        nowMsForActiveSession
      );

      if (sameMac) {
        const previousSiteCode = normalizeSiteCode(reusableActiveSession.site_code);
        const roamingToNewSite =
          previousSiteCode && previousSiteCode !== site_code;

        if (roamingToNewSite) {
          const nowIso = new Date(nowMsForActiveSession).toISOString();
          const oldSiteConfig = await getUnifiSiteConfig(previousSiteCode);
          const secondsConsumed = getSessionConsumedSeconds(
            reusableActiveSession,
            nowMsForActiveSession
          );
          const authorizedSeconds = getSessionAuthorizedSeconds(
            reusableActiveSession,
            voucher
          );
          const remainingMinutes = Math.max(
            1,
            Math.ceil(Math.max(0, authorizedSeconds - secondsConsumed) / 60)
          );
          let oldUnifi = null;
          let newUnifi = null;

          try {
            oldUnifi = await unauthorizeClient(mac_address, oldSiteConfig);
          } catch (error) {
            logDiagnosticError("VALIDATE ACCESS ROAMING OLD SITE UNAUTHORIZE FAILED", error);
            oldUnifi = buildUnifiFailureResult(error, "unauthorize", mac_address);
          }

          await safeUpdateAccessSession(
            reusableActiveSession.id,
            {
              site_code,
              status: "active",
              paused_at: null,
              last_accounted_at: nowIso,
              last_seen_at: nowIso,
              seconds_consumed: secondsConsumed,
              minutes_consumed: Math.ceil(secondsConsumed / 60),
              unifi_connected: true,
              unifi_authorized: false,
            },
            { select: false }
          );

          await supabase
            .from("access_codes")
            .update({
              status: "active",
              last_site_code: site_code,
              last_connection_at: nowIso,
              minutes_remaining: remainingMinutes,
            })
            .eq("id", voucher.id);

          try {
            newUnifi = await authorizeClient(
              mac_address,
              remainingMinutes,
              unifiSiteConfig
            );
          } catch (error) {
            logDiagnosticError("VALIDATE ACCESS ROAMING NEW SITE AUTHORIZE FAILED", error);
            newUnifi = buildUnifiFailureResult(error, "authorize", mac_address, {
              cmd: "authorize-guest",
              mac: mac_address,
              minutes: remainingMinutes,
            });

            if (isUnifiRequired()) {
              return res.status(502).json({
                success: false,
                authorized: false,
                request_id: requestId,
                voucher_valid: true,
                network_authorized: false,
                roaming: true,
                error: userFacingUniFiError(error),
                error_source: "unifi",
                error_step: "unifi_roaming_authorize_client",
                server_build: SERVER_BUILD,
                code: voucher.code,
                site_code,
                previous_site_code: previousSiteCode,
                mac_address,
                minutes_remaining: remainingMinutes,
                diagnostic: diagnosticErrorPayload(error),
                unifi: newUnifi,
              });
            }
          }

          await safeUpdateAccessSession(
            reusableActiveSession.id,
            {
              unifi_authorized: Boolean(newUnifi?.success),
              unifi_connected: Boolean(newUnifi?.success),
              last_seen_at: nowIso,
            },
            { select: false }
          );

          console.log("SESSION ROAMING RESUMED ON NEW SITE", {
            request_id: requestId,
            session_id: reusableActiveSession.id,
            code: reusableActiveSession.code,
            mac_address,
            previous_site_code: previousSiteCode,
            site_code,
            previous_controller: oldSiteConfig.controller_name,
            new_controller: unifiSiteConfig.controller_name,
            minutes_remaining: remainingMinutes,
            old_unifi: oldUnifi,
            new_unifi: newUnifi,
          });

          return res.status(200).json({
            success: true,
            authorized: true,
            resumed: true,
            roaming: true,
            request_id: requestId,
            message: "Session reprise sur un nouveau site",
            session_id: reusableActiveSession.id,
            code: voucher.code,
            previous_site_code: previousSiteCode,
            site_code,
            mac_address,
            ip_address,
            minutes_remaining: remainingMinutes,
            redirect_url: "https://betvsolutions.com",
            server_build: SERVER_BUILD,
            old_unifi: oldUnifi,
            unifi: newUnifi,
          });
        }

        console.log("VALIDATE ACCESS ACTIVE SESSION REUSED", {
          request_id: requestId,
          session_id: reusableActiveSession.id,
          code: reusableActiveSession.code,
          mac_address,
          minutes_remaining: progress.minutes_remaining,
        });

        return res.status(200).json({
          success: true,
          authorized: true,
          already_active: true,
          request_id: requestId,
          message: "Session déjà active",
          session_id: reusableActiveSession.id,
          code: voucher.code,
          site_code,
          mac_address,
          ip_address,
          minutes_remaining: progress.minutes_remaining,
          redirect_url: "https://betvsolutions.com",
          server_build: SERVER_BUILD,
          unifi: {
            success: true,
            skipped: true,
            reason: "session_already_active",
            mac: mac_address,
          },
        });
      }

      return res.status(409).json({
        success: false,
        authorized: false,
        request_id: requestId,
        error: "Code déjà actif sur un autre appareil.",
        error_source: "voucher",
        error_step: validateStep,
        server_build: SERVER_BUILD,
        active_session_id: reusableActiveSession.id,
        minutes_remaining: progress.minutes_remaining,
      });
    }

    const updatePayload = {
      status: "active",
      last_site_code: site_code,
      last_connection_at: new Date().toISOString(),
      minutes_total:
        voucher.minutes_total ||
        voucher.minutes ||
        voucher.duration_minutes ||
        minutesRemaining,
      minutes_remaining: minutesRemaining,
      national_voucher: true,
      validation_mode: "central",
    };

    validateStep = "supabase_fetch_site";

    bvDebug("/validate-access SUPABASE FETCH SITE START", {
      request_id: requestId,
      site_code,
    });

    console.log("VALIDATE ACCESS SUPABASE: fetching site", {
      site_code,
    });

    const { data: site, error: siteError } = await supabase
      .from("sites")
      .select("*")
      .eq("site_code", site_code)
      .limit(1)
      .maybeSingle();

    if (siteError) {
      logDiagnosticError("VALIDATE ACCESS SUPABASE SITE LOOKUP ERROR", siteError);
    }

    bvDebug("/validate-access SUPABASE FETCH SITE RESULT", {
      request_id: requestId,
      site_found: Boolean(site),
      site_id: site?.id || null,
      error: siteError
        ? {
            code: siteError.code || null,
            message: siteError.message || null,
          }
        : null,
    });

    console.log("VALIDATE ACCESS SUPABASE: site lookup result", {
      site_found: Boolean(site),
      site_id: site ? site.id : null,
    });

    if (site) {
      updatePayload.last_site_id = site.id;

      if (!voucher.first_site_id) {
        updatePayload.first_site_id = site.id;
      }
    }

    validateStep = "supabase_insert_session";

    bvDebug("/validate-access SUPABASE INSERT SESSION START", {
      request_id: requestId,
      voucher_id: voucher.id,
      site_code,
      mac_address,
      minutes_authorized: minutesRemaining,
    });

    console.log("VALIDATE ACCESS SUPABASE: inserting session", {
      voucher_id: voucher.id,
      site_code,
      mac_address,
      minutes_authorized: minutesRemaining,
    });

    const { data: session, error: sessionError } = await supabase
      .from("access_sessions")
      .insert([
        {
          access_code_id: voucher.id,
          code: voucher.code,
          site_id: site ? site.id : null,
          site_code,
          customer_phone: voucher.customer_phone || null,
          device_id,
          mac_address,
          ip_address,
          minutes_authorized: minutesRemaining,
          status: "active",
        },
      ])
      .select()
      .single();

    if (sessionError) {
      logDiagnosticError("VALIDATE ACCESS SUPABASE SESSION INSERT ERROR", sessionError);
      throw sessionError;
    }

    console.log("VALIDATE ACCESS SUPABASE: session inserted", {
      session_id: session.id,
    });

    const sessionStartedIso = new Date().toISOString();
    const sessionMetadataUpdate = await safeUpdateAccessSession(
      session.id,
      {
        billing_mode: sessionTiming.billingMode,
        expires_at: sessionTiming.expiresAt,
        last_accounted_at: sessionStartedIso,
        last_seen_at: mac_address ? sessionStartedIso : null,
        seconds_consumed: 0,
        unifi_connected: Boolean(mac_address),
        unifi_authorized: false,
      },
      { select: "*", single: true }
    );

    if (sessionMetadataUpdate.error) throw sessionMetadataUpdate.error;

    const sessionWithTiming = sessionMetadataUpdate.data || session;

    console.log("VALIDATE ACCESS SUPABASE: session timing prepared", {
      session_id: session.id,
      billing_mode: sessionTiming.billingMode,
      expires_at: sessionTiming.expiresAt,
      optional_columns_applied: Boolean(sessionMetadataUpdate.data),
      optional_columns_missing: Boolean(sessionMetadataUpdate.missing_optional_columns),
    });

    bvDebug("/validate-access SUPABASE INSERT SESSION RESULT", {
      request_id: requestId,
      session_id: session.id,
    });

    validateStep = "supabase_update_voucher";

    bvDebug("/validate-access SUPABASE UPDATE VOUCHER START", {
      request_id: requestId,
      voucher_id: voucher.id,
      status: updatePayload.status,
      site_code,
    });

    console.log("VALIDATE ACCESS SUPABASE: updating voucher", {
      voucher_id: voucher.id,
      status: updatePayload.status,
      site_code,
    });

    const { data: updatedVoucher, error: updateError } = await supabase
      .from("access_codes")
      .update(updatePayload)
      .eq("id", voucher.id)
      .select()
      .single();

    if (updateError) {
      logDiagnosticError("VALIDATE ACCESS SUPABASE VOUCHER UPDATE ERROR", updateError);
      throw updateError;
    }

    console.log("VALIDATE ACCESS SUPABASE: voucher updated", {
      voucher_id: updatedVoucher.id,
      status: updatedVoucher.status,
    });

    bvDebug("/validate-access SUPABASE UPDATE VOUCHER RESULT", {
      request_id: requestId,
      voucher_id: updatedVoucher.id,
      status: updatedVoucher.status,
    });

    validateStep = "unifi_authorize_client";

    bvDebug("/validate-access AUTHORIZE CLIENT START", {
      request_id: requestId,
      mac_address,
      minutes_remaining: minutesRemaining,
      billing_mode: sessionTiming.billingMode,
      expires_at: sessionTiming.expiresAt,
      unifi_enabled: isUnifiEnabled(),
      unifi_required: isUnifiRequired(),
      unifi_site: getUnifiSiteName(unifiSiteConfig),
      controller_name: unifiSiteConfig.controller_name,
      unifi_host: getUnifiBaseUrl(unifiSiteConfig),
    });

    console.log("VALIDATE ACCESS UNIFI: authorizing client", {
      request_id: requestId,
      mac_address,
      minutes_remaining: minutesRemaining,
      authorize_minutes: sessionTiming.authorizeMinutes,
      billing_mode: sessionTiming.billingMode,
      expires_at: sessionTiming.expiresAt,
      unifi_site: getUnifiSiteName(unifiSiteConfig),
      controller_name: unifiSiteConfig.controller_name,
      unifi_host: getUnifiBaseUrl(unifiSiteConfig),
    });

    let unifiResult;

    try {
      unifiResult = await authorizeClient(
        mac_address,
        sessionTiming.authorizeMinutes,
        unifiSiteConfig
      );
    } catch (error) {
      logDiagnosticError("/validate-access UNIFI AUTHORIZE FAILED", error);

      unifiResult = buildUnifiFailureResult(error, "authorize", mac_address, {
        cmd: "authorize-guest",
        mac: mac_address,
        minutes: sessionTiming.authorizeMinutes,
      });

      if (isUnifiRequired()) {
        return res.status(502).json({
          success: false,
          authorized: false,
          request_id: requestId,
          voucher_valid: true,
          network_authorized: false,
          error: userFacingUniFiError(error),
          error_source: "unifi",
          error_step: validateStep,
          server_build: SERVER_BUILD,
          code: updatedVoucher.code,
          site_code,
          mac_address,
          minutes_remaining: minutesRemaining,
          diagnostic: diagnosticErrorPayload(error),
          unifi: unifiResult,
        });
      }
    }

    console.log("VALIDATE ACCESS UNIFI: authorize result", unifiResult);

    await safeUpdateAccessSession(
      session.id,
      {
        unifi_authorized: Boolean(unifiResult?.success),
        unifi_connected: Boolean(unifiResult?.success),
        last_seen_at: unifiResult?.success ? new Date().toISOString() : null,
      },
      { select: false }
    );

    bvDebug("/validate-access AUTHORIZE CLIENT RESULT", {
      request_id: requestId,
      unifi: unifiResult,
      unifi_required: isUnifiRequired(),
    });

    const responseQr = decorateVoucherQr(
      updatedVoucher,
      req,
      updatedVoucher.code || voucher.code || code
    );

    res.status(200).json({
      success: true,
      authorized: true,
      request_id: requestId,
      voucher_valid: true,
      network_authorized: Boolean(unifiResult?.success),
      authorization_pending: !unifiResult?.success,
      message: "Accès autorisé",
      server_build: SERVER_BUILD,
      session_id: session.id,
      code: updatedVoucher.code,
      plan_code: updatedVoucher.plan_code || voucher.plan_code || null,
      voucher_status: updatedVoucher.status || null,
      billing_mode: sessionTiming.billingMode,
      expires_at: sessionTiming.expiresAt,
      qr_code_url: responseQr.qr_code_url,
      portal_url: responseQr.portal_url,
      voucher: {
        id: updatedVoucher.id,
        code: updatedVoucher.code,
        plan_code: updatedVoucher.plan_code || voucher.plan_code || null,
        status: updatedVoucher.status,
        minutes_total:
          updatedVoucher.minutes_total ||
          updatedVoucher.minutes ||
          updatedVoucher.duration_minutes ||
          minutesRemaining,
        minutes_remaining: minutesRemaining,
        qr_code_url: responseQr.qr_code_url,
        portal_url: responseQr.portal_url,
      },
      site_code,
      mac_address,
      mac_source: macResolution.selected_source,
      mac_resolution: macResolution,
      ip_address,
      minutes_remaining: minutesRemaining,
      authorize_minutes: sessionTiming.authorizeMinutes,
      redirect_url: "https://betvsolutions.com",
      unifi: unifiResult,
    });
  } catch (error) {
    logDiagnosticError("/validate-access ERROR COMPLETE", error);
    const errorSource = errorSourceFromStep(validateStep);

    res.status(errorSource === "unifi" ? 502 : 500).json({
      success: false,
      authorized: false,
      request_id: requestId,
      error:
        errorSource === "unifi"
          ? userFacingUniFiError(error)
          : error.message,
      error_source: errorSource,
      error_step: validateStep,
      server_build: SERVER_BUILD,
      diagnostic: diagnosticErrorPayload(error),
    });
  }
});

function getSessionStartMs(session) {
  const startedValue = session?.started_at || session?.created_at;
  const startedMs = new Date(startedValue).getTime();
  return Number.isFinite(startedMs) ? startedMs : Date.now();
}

function getSessionElapsedMinutes(session, nowMs = Date.now(), mode = "ceil") {
  const startedMs = getSessionStartMs(session);
  const elapsedMs = Math.max(0, nowMs - startedMs);
  const rawMinutes = elapsedMs / 60000;

  if (mode === "floor") return Math.max(0, Math.floor(rawMinutes));
  return Math.max(1, Math.ceil(rawMinutes));
}

function getSessionAuthorizedMinutes(session) {
  return Math.max(0, Number(session?.minutes_authorized || 0));
}

async function syncActiveSessionProgress(session, nowMs = Date.now(), context = {}) {
  const authorizedMinutes = getSessionAuthorizedMinutes(session);
  const accessCodeId = session?.access_code_id;

  if (!authorizedMinutes || !accessCodeId) {
    console.log("SESSION PROGRESS SKIPPED", {
      session_id: session?.id || null,
      reason: "missing_authorized_minutes_or_access_code",
      minutes_authorized: authorizedMinutes,
      access_code_id: accessCodeId || null,
    });

    return {
      skipped: true,
      reason: "missing_authorized_minutes_or_access_code",
      session_id: session?.id || null,
    };
  }

  const { data: voucher, error: fetchVoucherError } = await supabase
    .from("access_codes")
    .select("*")
    .eq("id", accessCodeId)
    .single();

  if (fetchVoucherError || !voucher) {
    throw fetchVoucherError || new Error("Voucher lié introuvable");
  }

  const billingMode = getSessionBillingMode(session, voucher);
  const authorizedSeconds = getSessionAuthorizedSeconds(session, voucher);
  const consumedSeconds = getSessionConsumedSeconds(session, nowMs);
  const nowIso = new Date(nowMs).toISOString();
  const siteConfigCache = context.siteConfigCache || null;
  const snapshotCache = context.snapshotCache || null;
  const normalizedSessionSiteCode = normalizeSiteCode(
    session.site_code ||
      voucher.last_site_code ||
      voucher.sale_site_code ||
      voucher.site_code ||
      DEFAULT_SITE_CODE
  );
  let siteConfig = siteConfigCache?.get(normalizedSessionSiteCode);

  if (!siteConfig) {
    siteConfig = await getUnifiSiteConfig(normalizedSessionSiteCode);
    siteConfigCache?.set(normalizedSessionSiteCode, siteConfig);
  }

  if (billingMode === "fixed_window") {
    const expiresMs = parseDateMs(session.expires_at);
    const remainingWindowSeconds = expiresMs
      ? Math.max(0, Math.ceil((expiresMs - nowMs) / 1000))
      : Math.max(0, authorizedSeconds - consumedSeconds);
    const elapsedSeconds = Math.max(0, authorizedSeconds - remainingWindowSeconds);
    const remainingMinutes = Math.max(0, Math.ceil(remainingWindowSeconds / 60));

    await safeUpdateAccessSession(
      session.id,
      {
        seconds_consumed: elapsedSeconds,
        minutes_consumed: Math.ceil(elapsedSeconds / 60),
        last_accounted_at: nowIso,
      },
      { status: "active", select: false }
    );

    const { data: updatedVoucher, error: voucherError } = await supabase
      .from("access_codes")
      .update({
        minutes_remaining: remainingMinutes,
        status: remainingMinutes <= 0 ? "used" : "active",
        last_connection_at: nowIso,
      })
      .eq("id", accessCodeId)
      .select("id, code, status, minutes_remaining")
      .maybeSingle();

    if (voucherError) throw voucherError;

    console.log("PLAN NUIT FIXED WINDOW SYNCED", {
      session_id: session.id,
      voucher_id: accessCodeId,
      code: updatedVoucher?.code || session.code || null,
      expires_at: session.expires_at || null,
      minutes_remaining: remainingMinutes,
    });

    return {
      success: true,
      session_id: session.id,
      voucher_id: accessCodeId,
      code: updatedVoucher?.code || session.code || null,
      billing_mode: billingMode,
      elapsed_minutes: Math.ceil(elapsedSeconds / 60),
      minutes_remaining: remainingMinutes,
    };
  }

  if (!session.mac_address) {
    console.log("SESSION PROGRESS SKIPPED", {
      session_id: session.id,
      reason: "missing_mac_for_connected_usage",
      code: session.code || null,
    });

    return {
      skipped: true,
      reason: "missing_mac_for_connected_usage",
      session_id: session.id,
      minutes_remaining: Math.ceil(
        Math.max(0, authorizedSeconds - consumedSeconds) / 60
      ),
    };
  }

  const clientState = await getUniFiClientState(session.mac_address, siteConfig, {
    snapshotCache,
  });

  if (!clientState.state_available) {
    console.log("SESSION PROGRESS SKIPPED", {
      session_id: session.id,
      reason: "unifi_client_state_unavailable",
      code: session.code || null,
      mac_address: session.mac_address,
      client_state: clientState,
    });

    return {
      skipped: true,
      reason: "unifi_client_state_unavailable",
      session_id: session.id,
      minutes_remaining: Math.ceil(
        Math.max(0, authorizedSeconds - consumedSeconds) / 60
      ),
      client_state: clientState,
    };
  }

  const clientVisible =
    clientState.connected &&
    !clientState.stale &&
    clientState.authorized !== false;

  if (!clientVisible) {
    return pauseAccessSessionIfStale(session, voucher, clientState, nowMs, siteConfig);
  }

  const lastAccountedMs = parseDateMs(session.last_accounted_at) || nowMs;
  const rawDeltaSeconds = Math.max(
    0,
    Math.floor((nowMs - lastAccountedMs) / 1000)
  );
  const deltaSeconds = Math.min(rawDeltaSeconds, getMaxAccountingDeltaSeconds());
  const newConsumedSeconds = Math.min(
    authorizedSeconds,
    consumedSeconds + deltaSeconds
  );
  const remainingSeconds = Math.max(0, authorizedSeconds - newConsumedSeconds);
  const remainingMinutes = Math.max(0, Math.ceil(remainingSeconds / 60));
  const consumedMinutes = Math.ceil(newConsumedSeconds / 60);

  console.log("CLIENT VISIBLE: SESSION ACCOUNTING ACTIVE", {
    session_id: session.id,
    code: session.code || null,
    mac_address: session.mac_address,
    delta_seconds: deltaSeconds,
    seconds_consumed: newConsumedSeconds,
    minutes_remaining: remainingMinutes,
    client_state: {
      site_code: clientState.site_code,
      controller_name: clientState.controller_name,
      connected: clientState.connected,
      authorized: clientState.authorized,
      last_seen_at: clientState.last_seen_at,
      ap_mac: clientState.ap_mac,
    },
  });

  await safeUpdateAccessSession(
    session.id,
    {
      seconds_consumed: newConsumedSeconds,
      minutes_consumed: consumedMinutes,
      last_accounted_at: nowIso,
      last_seen_at: clientState.last_seen_at || nowIso,
      unifi_connected: true,
      unifi_authorized: clientState.authorized !== false,
    },
    { status: "active", select: false }
  );

  const { data: updatedVoucher, error: voucherError } = await supabase
    .from("access_codes")
    .update({
      minutes_remaining: remainingMinutes,
      status: remainingMinutes <= 0 ? "used" : "active",
      last_connection_at: nowIso,
    })
    .eq("id", accessCodeId)
    .select("id, code, status, minutes_remaining")
    .maybeSingle();

  if (voucherError) throw voucherError;

  console.log("MINUTES SAVED: SESSION PROGRESS SYNCED", {
    session_id: session.id,
    voucher_id: accessCodeId,
    code: updatedVoucher?.code || session.code || null,
    mac_address: session.mac_address || null,
    seconds_consumed: newConsumedSeconds,
    minutes_consumed: consumedMinutes,
    minutes_remaining: remainingMinutes,
    voucher_status: updatedVoucher?.status || null,
  });

  if (remainingSeconds <= 0) {
    const ended = await endAccessSession(session, {
      nowMs,
      secondsConsumed: authorizedSeconds,
      minutesConsumed: authorizedMinutes,
    });

    return {
      ...ended,
      expired: true,
      reason: "connected_usage_exhausted",
    };
  }

  return {
    success: true,
    session_id: session.id,
    voucher_id: accessCodeId,
    code: updatedVoucher?.code || session.code || null,
    billing_mode: billingMode,
    elapsed_minutes: consumedMinutes,
    minutes_remaining: remainingMinutes,
    client_state: clientState,
  };
}

async function pauseAccessSessionIfStale(
  session,
  voucher,
  clientState,
  nowMs = Date.now(),
  siteConfig = null
) {
  const graceMs = getConnectedUsageGraceMs();
  const nowIso = new Date(nowMs).toISOString();
  const authorizedSeconds = getSessionAuthorizedSeconds(session, voucher);
  const consumedSeconds = getSessionConsumedSeconds(session, nowMs);
  const remainingSeconds = Math.max(0, authorizedSeconds - consumedSeconds);
  const remainingMinutes = Math.max(0, Math.ceil(remainingSeconds / 60));
  const lastKnownSeenMs =
    parseDateMs(clientState.last_seen_at) ||
    parseDateMs(session.last_seen_at) ||
    parseDateMs(session.last_accounted_at) ||
    getSessionStartMs(session);
  const missingForMs = Math.max(0, nowMs - lastKnownSeenMs);

  console.log("CLIENT ABSENT OR NOT AUTHORIZED", {
    session_id: session.id,
    code: session.code || voucher.code || null,
    mac_address: session.mac_address,
    site_code: siteConfig?.site_code || session.site_code || null,
    controller_name: siteConfig?.controller_name || null,
    connected: clientState.connected,
    authorized: clientState.authorized,
    stale: clientState.stale,
    missing_for_seconds: Math.floor(missingForMs / 1000),
    grace_seconds: Math.floor(graceMs / 1000),
    minutes_remaining: remainingMinutes,
  });

  await safeUpdateAccessSession(
    session.id,
    {
      last_seen_at: clientState.last_seen_at || session.last_seen_at || null,
      unifi_connected: Boolean(clientState.connected && !clientState.stale),
      unifi_authorized: Boolean(clientState.authorized),
    },
    { status: "active", select: false }
  );

  if (missingForMs < graceMs) {
    return {
      success: true,
      waiting_grace: true,
      session_id: session.id,
      minutes_remaining: remainingMinutes,
      client_state: clientState,
    };
  }

  await safeUpdateAccessSession(
    session.id,
    {
      status: "paused",
      paused_at: nowIso,
      last_accounted_at: nowIso,
      seconds_consumed: consumedSeconds,
      minutes_consumed: Math.ceil(consumedSeconds / 60),
      unifi_connected: false,
      unifi_authorized: false,
    },
    { status: "active", select: false }
  );

  const { error: voucherError } = await supabase
    .from("access_codes")
    .update({
      minutes_remaining: remainingMinutes,
      status: remainingMinutes <= 0 ? "used" : "active",
      last_connection_at: nowIso,
    })
    .eq("id", voucher.id);

  if (voucherError) throw voucherError;

  let unifi = null;

  if (session.mac_address) {
    try {
      unifi = await unauthorizeClient(session.mac_address, siteConfig);
      console.log("UNAUTHORIZE EXECUTED: SESSION PAUSED", {
        session_id: session.id,
        mac_address: session.mac_address,
        site_code: siteConfig?.site_code || session.site_code || null,
        unifi,
      });
    } catch (error) {
      logDiagnosticError("UNAUTHORIZE FAILED WHILE PAUSING SESSION", error);
      unifi = buildUnifiFailureResult(error, "unauthorize", session.mac_address);
    }
  }

  console.log("SESSION PAUSED", {
    session_id: session.id,
    code: session.code || voucher.code || null,
    mac_address: session.mac_address,
    minutes_saved: remainingMinutes,
    seconds_consumed: consumedSeconds,
    reason: "client_not_seen_after_grace",
  });

  return {
    success: true,
    paused: true,
    session_id: session.id,
    minutes_remaining: remainingMinutes,
    unifi,
    client_state: clientState,
  };
}

async function endAccessSession(session, options = {}) {
  const nowMs = options.nowMs || Date.now();
  const nowIso = new Date(nowMs).toISOString();
  const accessCodeId = session?.access_code_id;

  if (!session?.id) {
    throw new Error("Session invalide");
  }

  if (session.status === "ended") {
    console.log("END SESSION SKIPPED: already ended", {
      session_id: session.id,
      code: session.code || null,
      mac_address: session.mac_address || null,
    });

    return {
      success: true,
      already_ended: true,
      session,
    };
  }

  if (!accessCodeId) {
    throw new Error("Session sans voucher lié");
  }

  const secondsConsumed =
    Number(options.secondsConsumed) >= 0
      ? Number(options.secondsConsumed)
      : Number(options.minutesConsumed) > 0
        ? Number(options.minutesConsumed) * 60
      : getSessionConsumedSeconds(session, nowMs);
  const minutesConsumed =
    Number(options.minutesConsumed) > 0
      ? Number(options.minutesConsumed)
      : Math.ceil(secondsConsumed / 60);

  const { data: voucher, error: voucherError } = await supabase
    .from("access_codes")
    .select("*")
    .eq("id", accessCodeId)
    .single();

  if (voucherError || !voucher) {
    return {
      success: false,
      status: 404,
      error: "Voucher lié introuvable",
      diagnostic: voucherError ? diagnosticErrorPayload(voucherError) : null,
    };
  }

  const authorizedMinutes =
    getSessionAuthorizedMinutes(session) ||
    Number(
      voucher.minutes_total ||
        voucher.minutes ||
        voucher.duration_minutes ||
        voucher.minutes_remaining ||
        0
    );

  const billingMode = getSessionBillingMode(session, voucher);
  const endSessionSiteCode = normalizeSiteCode(
    session.site_code ||
      voucher.last_site_code ||
      voucher.sale_site_code ||
      voucher.site_code ||
      DEFAULT_SITE_CODE
  );
  const siteConfig =
    options.siteConfig ||
    await getUnifiSiteConfig(endSessionSiteCode);
  const newRemaining =
    billingMode === "fixed_window"
      ? 0
      : Math.max(0, authorizedMinutes - minutesConsumed);
  const newStatus = newRemaining <= 0 ? "used" : "active";

  const { data: updatedSession, error: updateSessionError } =
    await safeUpdateAccessSession(
      session.id,
      {
        ended_at: nowIso,
        minutes_consumed: minutesConsumed,
        seconds_consumed: secondsConsumed,
        unifi_connected: false,
        unifi_authorized: false,
        status: "ended",
      },
      { select: "*", single: true }
    );

  if (updateSessionError) throw updateSessionError;

  const { data: updatedVoucher, error: updateVoucherError } = await supabase
    .from("access_codes")
    .update({
      minutes_remaining: newRemaining,
      status: newStatus,
      last_connection_at: nowIso,
    })
    .eq("id", voucher.id)
    .select()
    .single();

  if (updateVoucherError) throw updateVoucherError;

  let unifi = null;

  if (session.mac_address) {
    console.log("END SESSION UNIFI UNAUTHORIZE START", {
      session_id: session.id,
      code: voucher.code || session.code || null,
      mac_address: session.mac_address,
      site_code: siteConfig.site_code,
      controller_name: siteConfig.controller_name,
      billing_mode: billingMode,
      seconds_consumed: secondsConsumed,
      minutes_consumed: minutesConsumed,
      minutes_remaining: newRemaining,
    });

    try {
      unifi = await unauthorizeClient(session.mac_address, siteConfig);

      console.log("END SESSION UNIFI UNAUTHORIZE RESULT", {
        session_id: session.id,
        mac_address: session.mac_address,
        unifi,
      });
    } catch (error) {
      logDiagnosticError("END SESSION UNIFI UNAUTHORIZE FAILED", error);
      unifi = buildUnifiFailureResult(error, "unauthorize", session.mac_address);
    }
  } else {
    console.log("END SESSION UNIFI UNAUTHORIZE SKIPPED: no MAC", {
      session_id: session.id,
      code: voucher.code || session.code || null,
    });
  }

  console.log("END SESSION COMPLETE", {
    session_id: session.id,
    code: voucher.code || session.code || null,
    billing_mode: billingMode,
    seconds_consumed: secondsConsumed,
    minutes_consumed: minutesConsumed,
    minutes_remaining: newRemaining,
    voucher_status: newStatus,
  });

  return {
    success: true,
    message: "Session terminée",
    code: voucher.code,
    billing_mode: billingMode,
    seconds_consumed: secondsConsumed,
    minutes_consumed: minutesConsumed,
    minutes_remaining: newRemaining,
    voucher_status: newStatus,
    session: updatedSession,
    voucher: updatedVoucher,
    unifi,
  };
}

function isSessionExpired(session, nowMs = Date.now()) {
  const billingMode = getSessionBillingMode(session);

  if (billingMode === "fixed_window") {
    const expiresMs = parseDateMs(session.expires_at);
    return Boolean(expiresMs && nowMs >= expiresMs);
  }

  const authorizedSeconds = getSessionAuthorizedSeconds(session);
  if (!authorizedSeconds) return false;

  return getSessionConsumedSeconds(session, nowMs) >= authorizedSeconds;
}

function isSessionExpiryWorkerEnabled() {
  const configured =
    process.env.BV_SESSION_EXPIRY_WORKER_ENABLED ||
    process.env.SESSION_EXPIRY_WORKER_ENABLED;

  if (configured !== undefined) return parseBoolean(configured);
  return isUnifiEnabled();
}

async function fetchActiveAccessSessionsPage(from, to) {
  return supabase
    .from("access_sessions")
    .select("*")
    .eq("status", "active")
    .order("created_at", { ascending: true })
    .range(from, to);
}

let lastSessionWorkerMetrics = null;

async function processActiveAccessSessions() {
  const cycleStartMs = Date.now();
  const nowMs = Date.now();
  const siteConfigCache = new Map();
  const snapshotCache = new Map();
  const batchSize = getSessionWorkerBatchSize();
  const results = [];
  const siteMetrics = {};
  let activeSessionsProcessed = 0;
  let batches = 0;
  let from = 0;
  let keepGoing = true;

  while (keepGoing) {
    const to = from + batchSize - 1;
    const { data: sessions, error } = await fetchActiveAccessSessionsPage(from, to);

    if (error) throw error;

    batches += 1;
    keepGoing = (sessions || []).length === batchSize;
    from += batchSize;

    for (const session of sessions || []) {
      activeSessionsProcessed += 1;

      try {
        const sessionSiteCode = normalizeSiteCode(session.site_code || DEFAULT_SITE_CODE);
        let siteConfig = siteConfigCache.get(sessionSiteCode);

        if (!siteConfig) {
          siteConfig = await getUnifiSiteConfig(sessionSiteCode);
          siteConfigCache.set(sessionSiteCode, siteConfig);
        }

        if (!siteMetrics[sessionSiteCode]) {
          siteMetrics[sessionSiteCode] = {
            site_code: sessionSiteCode,
            controller_name: siteConfig.controller_name,
            active_sessions: 0,
            clients_visible: null,
            guests_visible: null,
            unifi_response_ms: null,
            errors: [],
          };
        }

        siteMetrics[sessionSiteCode].active_sessions += 1;

        if (isSessionExpired(session, nowMs)) {
          const authorizedSeconds = getSessionAuthorizedSeconds(session);
          const result = await endAccessSession(session, {
            nowMs,
            secondsConsumed: authorizedSeconds,
            minutesConsumed: getSessionAuthorizedMinutes(session),
            siteConfig,
          });

          console.log("SESSION PRESENCE WORKER: session expired", {
            session_id: session.id,
            site_code: sessionSiteCode,
            controller_name: siteConfig.controller_name,
            code: session.code,
            mac_address: session.mac_address,
            minutes_authorized: session.minutes_authorized,
            minutes_remaining: result.minutes_remaining,
            unifi: result.unifi,
          });

          results.push({ session_id: session.id, expired: true, result });
          continue;
        }

        const progress = await syncActiveSessionProgress(session, nowMs, {
          siteConfigCache,
          snapshotCache,
        });
        results.push({ session_id: session.id, expired: false, progress });
      } catch (error) {
        logDiagnosticError("SESSION PRESENCE WORKER SESSION ERROR", error);
        results.push({
          session_id: session.id,
          success: false,
          error: error.message,
        });
      }
    }
  }

  for (const snapshot of snapshotCache.values()) {
    const siteCode = normalizeSiteCode(snapshot.site_code || DEFAULT_SITE_CODE);

    if (!siteMetrics[siteCode]) {
      siteMetrics[siteCode] = {
        site_code: siteCode,
        controller_name: snapshot.controller_name || null,
        active_sessions: 0,
        clients_visible: null,
        guests_visible: null,
        unifi_response_ms: null,
        errors: [],
      };
    }

    siteMetrics[siteCode].clients_visible = snapshot.staRows?.length || 0;
    siteMetrics[siteCode].guests_visible = snapshot.guestRows?.length || 0;
    siteMetrics[siteCode].unifi_response_ms = Object.values(
      snapshot.response_times_ms || {}
    ).reduce((sum, value) => sum + Number(value || 0), 0);
    siteMetrics[siteCode].errors = snapshot.errors || [];
  }

  lastSessionWorkerMetrics = {
    server_build: SERVER_BUILD,
    started_at: new Date(cycleStartMs).toISOString(),
    finished_at: new Date().toISOString(),
    duration_ms: Date.now() - cycleStartMs,
    batch_size: batchSize,
    batches,
    active_sessions: activeSessionsProcessed,
    site_count: Object.keys(siteMetrics).length,
    total_clients_visible: Object.values(siteMetrics).reduce(
      (sum, site) => sum + Number(site.clients_visible || 0),
      0
    ),
    total_guests_visible: Object.values(siteMetrics).reduce(
      (sum, site) => sum + Number(site.guests_visible || 0),
      0
    ),
    sites: siteMetrics,
    system: getSystemCapacitySnapshot(),
  };

  lastSessionWorkerMetrics.warnings = buildCapacityWarnings(lastSessionWorkerMetrics);

  console.log("SESSION PRESENCE WORKER CAPACITY", {
    duration_ms: lastSessionWorkerMetrics.duration_ms,
    batches,
    active_sessions: activeSessionsProcessed,
    site_count: lastSessionWorkerMetrics.site_count,
    total_clients_visible: lastSessionWorkerMetrics.total_clients_visible,
    warnings: lastSessionWorkerMetrics.warnings,
  });

  return results;
}

function startSessionExpiryWorker() {
  if (!isSessionExpiryWorkerEnabled()) {
    console.log("SESSION PRESENCE WORKER disabled", {
      unifi_enabled: isUnifiEnabled(),
      configured:
        process.env.BV_SESSION_EXPIRY_WORKER_ENABLED ||
        process.env.SESSION_EXPIRY_WORKER_ENABLED ||
        null,
    });
    return;
  }

  const pollMs = getSessionPresencePollMs();

  console.log("SESSION PRESENCE WORKER enabled", {
    poll_ms: pollMs,
    grace_seconds: Math.floor(getConnectedUsageGraceMs() / 1000),
    unifi_enabled: isUnifiEnabled(),
    unifi_required: isUnifiRequired(),
  });

  setInterval(() => {
    processActiveAccessSessions().catch((error) => {
      logDiagnosticError("SESSION PRESENCE WORKER TICK FAILED", error);
    });
  }, pollMs).unref?.();
}

function isAgentPrivilegeSyncEnabled() {
  const value = String(process.env.BV_AGENT_PRIVILEGED_SYNC_ENABLED || "true")
    .trim()
    .toLowerCase();
  return value !== "false" && value !== "0" && value !== "off";
}

function getAgentPrivilegeSyncMs() {
  const configured = Number(
    process.env.BV_AGENT_PRIVILEGED_SYNC_MS ||
      process.env.AGENT_PRIVILEGED_SYNC_MS ||
      60000
  );

  return Math.max(30000, configured || 60000);
}

async function syncAgentPrivilegedAccess() {
  const { data: devices, error } = await supabase
    .from("agent_privileged_devices")
    .select("*")
    .eq("status", "active")
    .limit(500);

  if (error) {
    if (isMissingSupabaseTableError(error)) {
      console.log("AGENT PRIVILEGED ACCESS SYNC SKIPPED: table missing");
      return [];
    }

    throw error;
  }

  const activeDevices = devices || [];
  if (activeDevices.length === 0) return [];

  const userIds = [...new Set(activeDevices.map((device) => device.agent_user_id).filter(Boolean))];
  if (userIds.length === 0) return [];

  const { data: profiles, error: profileError } = await supabase
    .from("user_profiles")
    .select("id, role, active, agent_code")
    .in("id", userIds);

  if (profileError) throw profileError;

  const profilesById = new Map((profiles || []).map((profile) => [profile.id, profile]));
  const suspended = [];

  for (const device of activeDevices) {
    const profile = profilesById.get(device.agent_user_id);
    const invalidProfile =
      !profile ||
      profile.active === false ||
      String(profile.role || "") !== "agent" ||
      (profile.agent_code && profile.agent_code !== device.agent_code);

    if (!invalidProfile) continue;

    try {
      const result = await suspendPrivilegedDevice(
        device,
        null,
        "Agent inactif ou profil agent invalide"
      );
      suspended.push(result.device);
    } catch (error) {
      logDiagnosticError("AGENT PRIVILEGED ACCESS AUTO SUSPEND FAILED", error);
    }
  }

  if (suspended.length > 0) {
    console.log("AGENT PRIVILEGED ACCESS AUTO SUSPENDED", {
      count: suspended.length,
      devices: suspended.map((device) => ({
        agent_code: device.agent_code,
        site_code: device.site_code,
        mac_address: device.mac_address,
      })),
    });
  }

  return suspended;
}

function startAgentPrivilegedAccessWorker() {
  if (!isAgentPrivilegeSyncEnabled()) {
    console.log("AGENT PRIVILEGED ACCESS SYNC disabled");
    return;
  }

  const pollMs = getAgentPrivilegeSyncMs();

  console.log("AGENT PRIVILEGED ACCESS SYNC enabled", {
    poll_ms: pollMs,
    privileged_access_minutes: getAgentPrivilegedAccessMinutes(),
  });

  setInterval(() => {
    syncAgentPrivilegedAccess().catch((error) => {
      logDiagnosticError("AGENT PRIVILEGED ACCESS SYNC FAILED", error);
    });
  }, pollMs).unref?.();
}

app.post("/end-session", validateAccessRateLimiter, async (req, res) => {
  try {
    const session_id = req.body.session_id;
    const minutes_consumed_input = req.body.minutes_consumed;

    if (!session_id) {
      return res.status(400).json({
        success: false,
        error: "session_id obligatoire",
      });
    }

    const { data: session, error: sessionError } = await supabase
      .from("access_sessions")
      .select("*")
      .eq("id", session_id)
      .single();

    if (sessionError || !session) {
      return res.status(404).json({
        success: false,
        error: "Session introuvable",
      });
    }

    const result = await endAccessSession(session, {
      minutesConsumed: Number(minutes_consumed_input),
    });

    if (result.status) return res.status(result.status).json(result);
    res.status(200).json(result);
  } catch (error) {
    console.error("END SESSION ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.post("/webhook/shopify", saleRateLimiter, verifyShopifyWebhookSignature, async (req, res) => {
  try {
    console.log("🔥 SHOPIFY WEBHOOK RECEIVED");

    let order;

    if (Buffer.isBuffer(req.body)) {
      order = JSON.parse(req.body.toString("utf8"));
    } else {
      order = req.body;
    }

    const result = await createAccessCodeFromOrder(order, req);

    console.log("✅ NATIONAL B&V NUMERIC VOUCHER GENERATED:", result.code);

    res.status(200).json({
      success: true,
      message: "NATIONAL B&V numeric voucher generated",
      latest_page: "https://bv-access-api.onrender.com/code/latest",
      ...result,
    });
  } catch (error) {
    console.error("❌ SHOPIFY WEBHOOK ERROR:", error.message);

    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
});

app.get("/downloads/:filename", (req, res) => {
  const filename = path.basename(String(req.params.filename || ""));

  if (!PUBLIC_APK_FILES.has(filename)) {
    return res.status(404).json({
      success: false,
      error: "Fichier introuvable",
    });
  }

  const filePath = path.join(DOWNLOADS_DIR, filename);

  fs.stat(filePath, (error, stats) => {
    if (error || !stats.isFile()) {
      return res.status(404).json({
        success: false,
        error: "APK non disponible sur ce serveur",
      });
    }

    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${filename}"`
    );
    res.setHeader("Content-Length", stats.size);
    res.setHeader("Cache-Control", "public, max-age=3600");

    fs.createReadStream(filePath).pipe(res);
  });
});

app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: "Route not found",
    path: req.originalUrl,
  });
});

app.listen(PORT, () => {
  console.log(`BV Access API running on port ${PORT}`);
  startSessionExpiryWorker();
  startAgentPrivilegedAccessWorker();
});
